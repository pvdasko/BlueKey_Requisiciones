namespace Autorizaciones.Models.Cias
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CONMAESTRO")]
    public partial class CONMAESTRO
    {
        [Required]
        [StringLength(3)]
        public string Codigo_Cia { get; set; }

        [Required]
        [StringLength(100)]
        public string Razon_Social { get; set; }

        [Required]
        [StringLength(100)]
        public string Nombre_Hotel { get; set; }

        [StringLength(100)]
        public string Direccion { get; set; }

        [StringLength(100)]
        public string Colonia { get; set; }

        [StringLength(50)]
        public string Entidad_Federativa { get; set; }

        [StringLength(50)]
        public string Municipio_Delegacion { get; set; }

        [StringLength(10)]
        public string Codigo_Postal { get; set; }

        [Required]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Required]
        [StringLength(16)]
        public string Cuenta_Resultado { get; set; }

        [StringLength(12)]
        public string Fecha_Proceso { get; set; }

        [StringLength(16)]
        public string Cuenta_Proveedores { get; set; }

        [StringLength(16)]
        public string Cuenta_Clientes { get; set; }

        [StringLength(16)]
        public string Cuenta_Iva { get; set; }

        public double? Porcentaje_Iva { get; set; }

        public double? Impuesto_Hospedaje_ISHR { get; set; }

        public double? Factor_Servicio { get; set; }

        [StringLength(6)]
        public string Consecutivo_Factura { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tipo_Cambio { get; set; }

        [Required]
        [StringLength(50)]
        public string IP { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Local { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Remota { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Historico_Local { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Historico_Remota { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Consolidado_Local { get; set; }

        [Required]
        [StringLength(200)]
        public string Cadena_Coneccion_Consolidado_Remota { get; set; }

        [Key]
        [StringLength(50)]
        public string Nombre_Base { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombre_Base_Historico { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombre_Base_Consolidado { get; set; }

        [StringLength(50)]
        public string Nombre_Base_Front { get; set; }

        [StringLength(50)]
        public string Nombre_Base_Front_Historico { get; set; }

        [StringLength(200)]
        public string Cadena_Coneccion_Front_Local { get; set; }

        [StringLength(200)]
        public string Cadena_Coneccion_Front_Remota { get; set; }

        [StringLength(200)]
        public string Cadena_Coneccion_Mestro_Back_Local { get; set; }

        [StringLength(200)]
        public string Cadena_Coneccion_Mestro_Back_Remota { get; set; }

        [StringLength(200)]
        public string Nombre_Base_Manzanillo { get; set; }

        public short Consolida { get; set; }

        [StringLength(16)]
        public string CuentaSueldos { get; set; }

        [Required]
        [StringLength(100)]
        public string Division { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_Auditoria { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_Imagenes { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_Pgms { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_Reps { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_PgmsRemoto { get; set; }

        [Required]
        [StringLength(100)]
        public string Directorio_RepsRemoto { get; set; }

        [StringLength(200)]
        public string Nombre_Base_Tabaqueria { get; set; }

        [StringLength(200)]
        public string Nombre_Base_Ixtapa { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre10 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre15 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre10Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre15Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaRet { get; set; }

        [StringLength(50)]
        public string CtaISRRet { get; set; }

        public bool Poliza_ASI { get; set; }

        public bool ConsePoliza { get; set; }

        public bool ActualizandoInventario { get; set; }

        [StringLength(100)]
        public string RFC { get; set; }

        [StringLength(50)]
        public string CtaIvaRetEfec { get; set; }

        [StringLength(50)]
        public string CtaISRRetEfec { get; set; }

        public bool con_precios { get; set; }

        [Column(TypeName = "numeric")]
        public decimal zesi { get; set; }

        public bool Poliza_Opera { get; set; }

        [Required]
        [StringLength(100)]
        public string Ruta_Auditoria { get; set; }

        public int Segmento { get; set; }

        [Required]
        [StringLength(15)]
        public string TelefonoComp { get; set; }
    }
}
