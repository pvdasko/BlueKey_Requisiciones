namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("001COMRQL")]
    public partial class C001COMRQL
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001COMRQL()
        {
            C001COMCOTI = new HashSet<C001COMCOTI>();
        }

        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Lin { get; set; }

        public long Cod_Art { get; set; }

        [Required]
        [StringLength(200)]
        public string Desc_Art { get; set; }

        public double Cantidad { get; set; }

        [Required]
        [StringLength(10)]
        public string Cod_Med { get; set; }

        [StringLength(200)]
        public string Notas { get; set; }

        public bool Status_Cot { get; set; }

        //[Required]
        //[StringLength(50)]
        //public string Origen { get; set; }

        [NotMapped]
        [DataType(DataType.Currency)]
        public double TotalLinea
        {
            get
            {
                return costoLinea(this.Cod_Art, this.Cantidad);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMCOTI> C001COMCOTI { get; set; }

        public virtual C001COMRQG C001COMRQG { get; set; }

        public virtual C001INVMED C001INVMED { get; set; }


        public double costoLinea(long cod_art, double cantidad)
        {
            double total_costo=0;
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            decimal costo = db.C001INVEST 
                             .Where(x => x.Cod_Art == cod_art)
                             .Select (x => x.Cos_Prom )
                             .FirstOrDefault();

            total_costo = cantidad * Convert.ToDouble (costo) ;

           return total_costo;

        }
    }
}
