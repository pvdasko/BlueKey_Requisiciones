﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;

namespace Autorizaciones.Controllers
{
    public class AlmacenDetalleController : BaseController 
    {
        // GET: AlmacenDetalle
        public ActionResult Index(int id, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            try
            {
                var modelordenes = db.C001INVLIN.Where(x => x.Indice == id).FirstOrDefault();

                ViewBag.lblNoOrden = modelordenes.C001INVGEN.No_Req;
                ViewBag.lblDepartamento = modelordenes.C001INVGEN.C001INVDEP.Desc_Esp;
                ViewBag.lblNoMov = modelordenes.C001INVGEN.Ind_Mov;
                ViewBag.lblFecha = modelordenes.C001INVGEN.Fech_Mov.ToString("yyyy-MM-dd");
                ViewBag.lblComentarios = modelordenes.C001INVGEN.Notas;
               
            }
            catch (Exception ex)
            {                
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);       
                throw;
            }

            var viewModel = db.C001INVLIN.Where(x => x.Indice == id).ToList();
            LoadSessionObject();
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }
          
       
        [HttpPost]
        public ActionResult Index(List<C001INVLIN> orden , int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
              string ordenesAprobadas = "";
              try
              {
                  using (ModelBack db = new ModelBack(connectionStringName))
                  {
                      foreach (var i in orden) 
                      {
                        var ordqupd = db.C001INVLIN.Where(x => x.Indice == i.Indice && x.Linea == i.Linea).FirstOrDefault();
                        if (ordqupd != null)
                        {
                             if (ordqupd.Can != i.Can)
                             {
                                 ordqupd.Can = i.Can; 
                                 ordenesAprobadas = ordenesAprobadas + " " + i.Linea;
                             }
                         }


                      }
                      if (ModelState.IsValid)
                      {
                          db.SaveChanges();
                      }
                      else
                      {
                          Danger("Por favor ingrese un número válido");
                          return RedirectToAction("Index");
                         
                      }
                  }
                  if (ordenesAprobadas != "")
                  { 
                      ViewBag.Message = "Lineas actualizadas.";                 
                      String mensajeStr = "Se actualizaron las lineas: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b> ";
                      Success(string.Format(mensajeStr, userAut), true);
                  }
                  return RedirectToAction("Index");
              }
              catch (Exception ex)
              {
                  Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                  return RedirectToAction("Index");
                  throw;
              }
        }

        public ActionResult Delete(int id, int lin)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, int lin,  FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    var viewModel = db.C001INVLIN.Where(x => x.Indice == id && x.Linea == lin).FirstOrDefault();
                    db.C001INVLIN.Remove(viewModel);
                    db.SaveChanges();                                 
                }

                ViewBag.Message = "Linea borrada.";
                String mensajeStr = "Se borro la linea: <b>" + lin.ToString() + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("Index");     
                
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("Index");
                throw;
            }

        }   

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false
                                               && x.Cod_Dep != ""
                                               && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}