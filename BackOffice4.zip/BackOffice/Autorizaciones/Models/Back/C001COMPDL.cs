namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPDL")]
    public partial class C001COMPDL
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Ped { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Lin { get; set; }

        public long No_Art { get; set; }

        public double Cantidad { get; set; }

        [Column(TypeName = "money")]
        public decimal Precio { get; set; }

        [Column(TypeName = "money")]
        public decimal Descuento { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total { get; set; }

        public double Entregada_1 { get; set; }

        public double Entregada_2 { get; set; }

        public double Entregada_3 { get; set; }

        public double Entregada_4 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Falta { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_1 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_2 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_3 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal IEPS { get; set; }
    }
}
