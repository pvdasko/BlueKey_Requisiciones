namespace Autorizaciones.Models.Cias
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelCias : DbContext
    {
        public ModelCias()
            : base("name=ContextCias")
        {
        }

        public virtual DbSet<CONMAESTRO> CONMAESTRO { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Codigo_Cia)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Hotel)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Entidad_Federativa)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Municipio_Delegacion)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Codigo_Postal)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Resultado)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Fecha_Proceso)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Proveedores)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Clientes)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Iva)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Consecutivo_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.IP)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Local)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Remota)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Historico_Local)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Historico_Remota)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Consolidado_Local)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Consolidado_Remota)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Historico)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Consolidado)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Front)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Front_Historico)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Front_Local)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Front_Remota)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Mestro_Back_Local)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Coneccion_Mestro_Back_Remota)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Manzanillo)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CuentaSueldos)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Division)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_Auditoria)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_Imagenes)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_Pgms)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_Reps)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_PgmsRemoto)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_RepsRemoto)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Tabaqueria)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base_Ixtapa)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaAcre10)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaAcre15)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaAcre10Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaAcre15Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaRet)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaISRRet)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaIvaRetEfec)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.CtaISRRetEfec)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.zesi)
                .HasPrecision(18, 0);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Ruta_Auditoria)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.TelefonoComp)
                .IsUnicode(false);
        }
    }
}
