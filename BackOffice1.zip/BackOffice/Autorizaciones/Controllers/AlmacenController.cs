﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;

namespace Autorizaciones.Controllers
{
    public class AlmacenController : Controller
    {
        // GET: Almacen
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "NoReq_desc" : "";
            ViewBag.DepartamentoParm = String.IsNullOrEmpty(sortOrder) ? "Departamento" : "Departamento_desc";
            ViewBag.NotasParm = String.IsNullOrEmpty(sortOrder) ? "Notas" : "Notas_desc";            
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001INVGEN //db.Ordenes.OrderBy(x => x.NoOrden).ToList();
                            //join d in db.C001INVDEP on r.Cod_Dep equals d.Cod_Dep
                            //join t in db.C001INVTIPOS on r.Tipo_Mov equals t.Cod_Tip
                            where r.Tipo_Mov == "SAL" && r.Stat_Aut == false 
                            select r;

            if (!String.IsNullOrEmpty(searchString))
            {
                //int orden;
                //if (int.TryParse(searchString, out  orden))
                //{
                //    viewModel = viewModel.Where(x => x.No_Req == orden);

                //}
                //else
                //{
                    viewModel = viewModel.Where(x => x.No_Req.Contains (searchString)
                                              || x.C001INVDEP.Desc_Esp.Contains(searchString)
                                              || x.Notas.Contains(searchString)
                                              && x.Tipo_Mov =="SAL");

                //}

            }

            switch (sortOrder)
            {
                case "NoReq_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Req);
                    break;               
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp );
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Notas":
                    viewModel = viewModel.OrderBy(s => s.Notas);
                    break;
                case "Notas_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Notas);
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fech_Mov);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fech_Mov);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Req);
                    break;
            }

            LoadSessionObject();

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }
    }
}