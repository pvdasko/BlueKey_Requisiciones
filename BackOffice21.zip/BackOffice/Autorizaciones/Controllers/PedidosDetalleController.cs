﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class PedidosDetalleController : BaseController
    {
        public ActionResult PedidosDet(int id)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            try
            {
                var modelordenes = db.C001COMPDG.Where(x => x.No_Ped == id).FirstOrDefault();

                ViewBag.lblPedido = modelordenes.No_Ped;
                ViewBag.lblDepartamento = modelordenes.Departamento;
                ViewBag.lblProveedor = modelordenes.Proveedor;
                ViewBag.lblFecha = modelordenes.Fecha_Ped.ToString("yyyy-MM-dd");
                ViewBag.lblCondiciones = modelordenes.Condiciones;
                ViewBag.lblComentarios = modelordenes.Notas;
                ViewBag.lblRequisicion = modelordenes.Requisicion;
                ViewBag.lblFechaEntrega = modelordenes.Fecha_Entrega.ToString("yyyy-MM-dd");
                ViewBag.lblComentariosC = modelordenes.Notas_1;
                ViewBag.lblComentariosG = modelordenes.Notas_2;
                ViewBag.lblTipoPedido = modelordenes.Operacion;
               
                ViewBag.lblFirmas = modelordenes.Firmas;

                List<SelectListItem> tiempoEntrega = new List<SelectListItem>();
                tiempoEntrega.Add(new SelectListItem { Text = "--Selecciona Tiempo--", Value = "" });
                tiempoEntrega.Add(new SelectListItem { Text = "Inmediato", Value = "Inmediato" });
                tiempoEntrega.Add(new SelectListItem { Text = "8 dias", Value = "8 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "15 dias", Value = "15 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "30 dias", Value = "30 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "45 dias", Value = "45 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "60 dias", Value = "60 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "90 dias", Value = "90 dias" });
                tiempoEntrega.Add(new SelectListItem { Text = "120 dias", Value = "120 dias" });
                ViewBag.lblTiempoEntrega = tiempoEntrega;

            }
            catch (Exception ex)
            {

                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
                throw;
            }
            

            var viewModel = db.C001COMPDL.Where(x => x.No_Ped == id).ToList();
            LoadSessionObject();
            return View(viewModel);
        }


        public ActionResult GuardarHeader(int id, string parComentarios, string parCondiciones,  string parComentariosC, string parComentariosG )
        {
            return View();
        }

        [HttpPost]
        public ActionResult GuardarHeader(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    var viewModel = db.C001COMPDG.Where(x => x.No_Ped == id).FirstOrDefault();
                    
                    db.SaveChanges();
                }
                 ViewBag.Message = "Registro guadardo.";
                String mensajeStr = "Se guardaron los datos del pedido: <b>" + id.ToString() + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqComprasDet");
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public ActionResult Delete(int id, int lin)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, int lin, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    var viewModel = db.C001COMPDL.Where(x => x.No_Ped == id && x.No_Lin == lin).FirstOrDefault();
                    db.C001COMPDL.Remove(viewModel);
                    db.SaveChanges();
                }

                ViewBag.Message = "Linea borrada.";
                String mensajeStr = "Se borro la linea: <b>" + lin.ToString() + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqComprasDet");

            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqComprasDet");
                throw;
            }

        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false
                                               && x.Cod_Dep != ""
                                               && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;

            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}