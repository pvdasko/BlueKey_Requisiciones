namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TESORERIA_CONCILIA
    {
        [Key]
        [Column(Order = 0)]
        public DateTime Fecha_Concilia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 2)]
        public double Indice { get; set; }

        [Required]
        [StringLength(2)]
        public string Tipo_Poliza { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime Fecha_Aplica { get; set; }

        [Required]
        [StringLength(20)]
        public string Referencia { get; set; }

        [Required]
        [StringLength(250)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono { get; set; }

        public bool Conciliado { get; set; }
    }
}
