namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMDESC")]
    public partial class C001NOMDESC
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Campo { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }
    }
}
