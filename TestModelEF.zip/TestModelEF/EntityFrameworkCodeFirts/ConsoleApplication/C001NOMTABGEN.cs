namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMTABGEN")]
    public partial class C001NOMTABGEN
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Tabla { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        public double Alimentos { get; set; }

        public double Vales { get; set; }
    }
}
