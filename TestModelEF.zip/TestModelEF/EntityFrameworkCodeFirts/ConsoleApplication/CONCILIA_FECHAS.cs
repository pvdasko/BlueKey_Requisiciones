namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONCILIA_FECHAS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha { get; set; }

        public bool Conciliada { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }
    }
}
