namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CXCCasaCartera")]
    public partial class CXCCasaCartera
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Ope { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Indice { get; set; }

        [Required]
        [StringLength(10)]
        public string Cod_Cliente { get; set; }

        [Required]
        [StringLength(20)]
        public string Docto { get; set; }

        [StringLength(250)]
        public string Nombre { get; set; }

        public DateTime? Fecha { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        public bool Casa { get; set; }

        public int NumeroCasa { get; set; }
    }
}
