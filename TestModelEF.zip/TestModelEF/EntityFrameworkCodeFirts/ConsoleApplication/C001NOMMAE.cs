namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMMAE")]
    public partial class C001NOMMAE
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        [Required]
        [StringLength(150)]
        public string RazonSocial { get; set; }

        [Required]
        [StringLength(100)]
        public string Direccion { get; set; }

        [Required]
        [StringLength(100)]
        public string Colonia { get; set; }

        [Required]
        [StringLength(50)]
        public string Entidad { get; set; }

        [Required]
        [StringLength(50)]
        public string Municipio { get; set; }

        [Required]
        [StringLength(10)]
        public string CP { get; set; }

        [Required]
        [StringLength(20)]
        public string RFC { get; set; }

        [Required]
        [StringLength(20)]
        public string ImssPatronal { get; set; }

        [Required]
        [StringLength(20)]
        public string Infonavit { get; set; }

        [Required]
        [StringLength(4)]
        public string ClaveMunicipio { get; set; }

        [Required]
        [StringLength(2)]
        public string ClaveEntidad { get; set; }

        [Required]
        [StringLength(10)]
        public string OficinaHacienda { get; set; }

        [Required]
        [StringLength(30)]
        public string Telefono { get; set; }

        [Required]
        [StringLength(150)]
        public string Representante { get; set; }

        [Required]
        [StringLength(20)]
        public string RFCRep { get; set; }

        [Column(TypeName = "money")]
        public decimal SMDF { get; set; }

        [Column(TypeName = "money")]
        public decimal Factor { get; set; }

        [Column(TypeName = "money")]
        public decimal PorcSind { get; set; }

        [Column(TypeName = "money")]
        public decimal SeguroVida { get; set; }

        [Column(TypeName = "money")]
        public decimal FondoSeguro { get; set; }

        [Column(TypeName = "money")]
        public decimal PorcAlimentos { get; set; }

        public double DiasContrato { get; set; }

        [Required]
        [StringLength(16)]
        public string CuentaSueldos { get; set; }

        public bool NominaEventual { get; set; }

        public bool NominaProceso { get; set; }

        [Column(TypeName = "money")]
        public decimal TopeComedor { get; set; }

        public double DiasCalculo { get; set; }

        [StringLength(16)]
        public string CuentaCargo { get; set; }

        [Column(TypeName = "money")]
        public decimal AlimImporte { get; set; }
    }
}
