namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONCEPTOREPS
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        public int? FondoEmpleado { get; set; }

        public int? FondoEmpresa { get; set; }

        public int Vales { get; set; }
    }
}
