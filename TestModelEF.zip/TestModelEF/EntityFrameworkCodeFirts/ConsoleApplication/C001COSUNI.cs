namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSUNI")]
    public partial class C001COSUNI
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001COSUNI()
        {
            C001COSCONV = new HashSet<C001COSCONV>();
            C001COSCONV1 = new HashSet<C001COSCONV>();
            C001COSRCG = new HashSet<C001COSRCG>();
        }

        [Key]
        [StringLength(2)]
        public string Codigo_Unidad { get; set; }

        [Required]
        [StringLength(50)]
        public string Nom_UniEsp { get; set; }

        [StringLength(50)]
        public string Nom_UniIng { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COSCONV> C001COSCONV { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COSCONV> C001COSCONV1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COSRCG> C001COSRCG { get; set; }
    }
}
