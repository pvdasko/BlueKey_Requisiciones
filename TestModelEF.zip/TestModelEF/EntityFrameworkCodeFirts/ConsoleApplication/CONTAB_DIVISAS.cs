namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONTAB_DIVISAS
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CONTAB_DIVISAS()
        {
            CONTAB_TIPO_CAMBIO = new HashSet<CONTAB_TIPO_CAMBIO>();
        }

        [Key]
        [StringLength(3)]
        public string Codigo_Divisa { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CONTAB_TIPO_CAMBIO> CONTAB_TIPO_CAMBIO { get; set; }
    }
}
