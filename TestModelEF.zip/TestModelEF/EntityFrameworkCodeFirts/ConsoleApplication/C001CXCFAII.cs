namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCFAII")]
    public partial class C001CXCFAII
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(6)]
        public string Codigo_Cliente { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Factura { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string No_Linea { get; set; }

        [StringLength(10)]
        public string No_Cupon { get; set; }

        [StringLength(2)]
        public string Codigo_Serv { get; set; }

        [StringLength(50)]
        public string Descripcion { get; set; }

        [Column(TypeName = "money")]
        public decimal? Importe { get; set; }

        [StringLength(50)]
        public string Libre_1 { get; set; }

        [StringLength(50)]
        public string Libre_2 { get; set; }

        [StringLength(50)]
        public string Libre_3 { get; set; }
    }
}
