namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("COMPARATIVOTEMP")]
    public partial class COMPARATIVOTEMP
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Evento { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string No_Req { get; set; }

        [Key]
        [Column(Order = 2)]
        public double Cod_Art { get; set; }

        [Required]
        [StringLength(250)]
        public string Desc_Art { get; set; }

        [Required]
        [StringLength(50)]
        public string Cod_Med { get; set; }

        public double Cantidad { get; set; }
    }
}
