namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_GEN
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AF_GEN()
        {
            AF_LIN = new HashSet<AF_LIN>();
        }

        [Key]
        public long Ind_Mov { get; set; }

        [Required]
        [StringLength(10)]
        public string No_Req { get; set; }

        [Required]
        [StringLength(3)]
        public string Tipo_Mov { get; set; }

        public DateTime Fech_Mov { get; set; }

        public DateTime Fech_Sis { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [StringLength(200)]
        public string Notas { get; set; }

        public double Total_Fac { get; set; }

        public double Iva_Fac { get; set; }

        [Required]
        [StringLength(3)]
        public string Cod_Ope { get; set; }

        public bool Stat_Mov { get; set; }

        [StringLength(3)]
        public string Ope_Aut { get; set; }

        public bool Stat_Aut { get; set; }

        public bool Entrada_Directa { get; set; }

        public long No_Pedido { get; set; }

        [Required]
        [StringLength(10)]
        public string Referencia { get; set; }

        public bool Aplicado { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Aplica { get; set; }

        public DateTime? Hora_Captura { get; set; }

        public DateTime? Hora_Autoriza { get; set; }

        public DateTime? Hora_Surte { get; set; }

        public bool Dolares { get; set; }

        public DateTime? Fecha_Factura { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }

        public virtual C001INVDEP C001INVDEP { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_LIN> AF_LIN { get; set; }
    }
}
