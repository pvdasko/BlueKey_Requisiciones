namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001FOLIOSPASO")]
    public partial class C001FOLIOSPASO
    {
        [Key]
        [StringLength(20)]
        public string FOLIO { get; set; }

        [StringLength(80)]
        public string APELLIDO { get; set; }

        [StringLength(80)]
        public string NOMBRE { get; set; }

        public DateTime? LLEGADA { get; set; }

        public short? NOCHES { get; set; }

        public DateTime? SALIDA { get; set; }

        public short? CUARTOS { get; set; }

        [Column("CVE TIPO CUARTO")]
        [StringLength(20)]
        public string CVE_TIPO_CUARTO { get; set; }

        public short? ADULTOS { get; set; }

        public short? NINOS { get; set; }

        [Column(TypeName = "money")]
        public decimal? TARIFA { get; set; }

        [StringLength(250)]
        public string DIRECCION { get; set; }

        [StringLength(20)]
        public string CIUDAD { get; set; }

        [Column("CVE EMPRESA")]
        [StringLength(20)]
        public string CVE_EMPRESA { get; set; }

        [Column("PROC RVA")]
        [StringLength(20)]
        public string PROC_RVA { get; set; }

        [StringLength(20)]
        public string GRUPO { get; set; }

        [StringLength(20)]
        public string AGENCIA { get; set; }

        [StringLength(20)]
        public string PLAN { get; set; }

        [Column("F PAGO")]
        [StringLength(20)]
        public string F_PAGO { get; set; }

        [Column("NO TARJETA")]
        [StringLength(100)]
        public string NO_TARJETA { get; set; }

        [Column("L CREDITO", TypeName = "money")]
        public decimal? L_CREDITO { get; set; }

        [Column("CVE SRC")]
        [StringLength(10)]
        public string CVE_SRC { get; set; }

        [Column("CVE SRC VENTAS")]
        [StringLength(10)]
        public string CVE_SRC_VENTAS { get; set; }

        [Column("CVE CRO")]
        [StringLength(10)]
        public string CVE_CRO { get; set; }

        [Column("CVE VIP")]
        [StringLength(10)]
        public string CVE_VIP { get; set; }

        [Column("CVE GARANTIA")]
        [StringLength(10)]
        public string CVE_GARANTIA { get; set; }

        [Column("FECHA LIMITE")]
        [StringLength(10)]
        public string FECHA_LIMITE { get; set; }

        [Column("CVE CTE FRECUENTE")]
        [StringLength(20)]
        public string CVE_CTE_FRECUENTE { get; set; }

        [Column("FOLIO MAESTRA")]
        [StringLength(20)]
        public string FOLIO_MAESTRA { get; set; }

        [StringLength(50)]
        public string SW { get; set; }

        [StringLength(50)]
        public string EMAIL { get; set; }

        [StringLength(80)]
        public string CONTACTO { get; set; }

        [Column("CVE CONTRATO TC")]
        [StringLength(100)]
        public string CVE_CONTRATO_TC { get; set; }

        [Column("HORA ENT")]
        public DateTime? HORA_ENT { get; set; }

        [Column("HORA SAL")]
        public DateTime? HORA_SAL { get; set; }

        [Column("CVE CUARTO")]
        [StringLength(20)]
        public string CVE_CUARTO { get; set; }

        [StringLength(250)]
        public string NOTAS { get; set; }

        [Column("FECHA RVA")]
        public DateTime? FECHA_RVA { get; set; }

        [Column(TypeName = "money")]
        public decimal? DEPOSITO { get; set; }

        [Column(TypeName = "money")]
        public decimal? SALDO { get; set; }

        [StringLength(2)]
        public string ESTATUS { get; set; }

        public short? MENORES { get; set; }

        public short? JUNIORS { get; set; }

        [Column("TARIFA RACK", TypeName = "money")]
        public decimal? TARIFA_RACK { get; set; }

        [Column("LLEGADA ORIGINAL")]
        [StringLength(10)]
        public string LLEGADA_ORIGINAL { get; set; }

        [Column("SALIDA ORIGINAL")]
        [StringLength(10)]
        public string SALIDA_ORIGINAL { get; set; }

        [StringLength(20)]
        public string CXC { get; set; }

        [StringLength(20)]
        public string BANDA { get; set; }

        [StringLength(20)]
        public string CUPON { get; set; }

        [Column("GALA 100")]
        [StringLength(50)]
        public string GALA_100 { get; set; }

        [Column("TARIFA CENTRAL", TypeName = "money")]
        public decimal? TARIFA_CENTRAL { get; set; }

        [Column("TARIFA TOUR OPERADOR", TypeName = "money")]
        public decimal? TARIFA_TOUR_OPERADOR { get; set; }

        [Column("ARCHIVO FIRMA")]
        [StringLength(30)]
        public string ARCHIVO_FIRMA { get; set; }

        [Column("FECHA RVA ORIGINAL")]
        public DateTime? FECHA_RVA_ORIGINAL { get; set; }

        [Column("TOTAL ESTANCIA", TypeName = "money")]
        public decimal? TOTAL_ESTANCIA { get; set; }

        [StringLength(50)]
        public string MEDIO { get; set; }

        [StringLength(10)]
        public string COMISION { get; set; }

        [StringLength(2)]
        public string ENVIADA { get; set; }

        [Column("AFECTA ALLOTMENT GALA")]
        [StringLength(2)]
        public string AFECTA_ALLOTMENT_GALA { get; set; }

        [Column("FECHA MANIFIESTO")]
        public DateTime? FECHA_MANIFIESTO { get; set; }

        [Column("CALCULO TARIFA")]
        [StringLength(2)]
        public string CALCULO_TARIFA { get; set; }

        [Column("CAMPO 61")]
        [StringLength(2)]
        public string CAMPO_61 { get; set; }

        [Column("CAMPO 62")]
        [StringLength(2)]
        public string CAMPO_62 { get; set; }

        [Column("CAMPO 63")]
        [StringLength(2)]
        public string CAMPO_63 { get; set; }

        [Column("CAMPO 64")]
        [StringLength(2)]
        public string CAMPO_64 { get; set; }

        [Column("CAMPO 65")]
        [StringLength(2)]
        public string CAMPO_65 { get; set; }

        [Column("CAMPO 66")]
        [StringLength(2)]
        public string CAMPO_66 { get; set; }

        [Column("CAMPO 67")]
        [StringLength(2)]
        public string CAMPO_67 { get; set; }

        [Column("CAMPO 68")]
        [StringLength(2)]
        public string CAMPO_68 { get; set; }

        [Column("CAMPO 69")]
        [StringLength(2)]
        public string CAMPO_69 { get; set; }

        [Column("CAMPO 70")]
        [StringLength(2)]
        public string CAMPO_70 { get; set; }

        [Column("CAMPO 71")]
        [StringLength(2)]
        public string CAMPO_71 { get; set; }

        [Column("CAMPO 72")]
        [StringLength(2)]
        public string CAMPO_72 { get; set; }

        [Column("CAMPO 73")]
        [StringLength(2)]
        public string CAMPO_73 { get; set; }

        [Column("CAMPO 74")]
        [StringLength(2)]
        public string CAMPO_74 { get; set; }

        [Column("CAMPO 75")]
        [StringLength(2)]
        public string CAMPO_75 { get; set; }

        [Column("CAMPO 76")]
        [StringLength(2)]
        public string CAMPO_76 { get; set; }

        [Column("CAMPO 77")]
        [StringLength(2)]
        public string CAMPO_77 { get; set; }

        [Column("CAMPO 78")]
        [StringLength(2)]
        public string CAMPO_78 { get; set; }

        [Column("CAMPO 79")]
        [StringLength(2)]
        public string CAMPO_79 { get; set; }

        [Column("CAMPO 80")]
        [StringLength(2)]
        public string CAMPO_80 { get; set; }

        public long? CONSECUTIVO { get; set; }

        [StringLength(15)]
        public string COMPROBANTE { get; set; }
    }
}
