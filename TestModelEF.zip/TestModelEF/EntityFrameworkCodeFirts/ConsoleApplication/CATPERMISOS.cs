namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CATPERMISOS
    {
        [Key]
        [StringLength(50)]
        public string CodPermiso { get; set; }

        [StringLength(150)]
        public string Descripcion { get; set; }

        [StringLength(50)]
        public string Concepto { get; set; }
    }
}
