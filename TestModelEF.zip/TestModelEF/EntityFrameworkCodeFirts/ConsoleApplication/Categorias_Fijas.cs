namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Categorias_Fijas
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Codigo { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        public int Nivel_1 { get; set; }

        public int Nivel_2 { get; set; }

        public int Nivel_3 { get; set; }

        [Required]
        [StringLength(19)]
        public string Cuenta { get; set; }
    }
}
