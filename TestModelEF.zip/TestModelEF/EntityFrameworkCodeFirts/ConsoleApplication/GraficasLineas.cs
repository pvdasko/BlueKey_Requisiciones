namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class GraficasLineas
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Grafica { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(16)]
        public string CuentaInicial { get; set; }

        [Required]
        [StringLength(16)]
        public string CuentaFinal { get; set; }
    }
}
