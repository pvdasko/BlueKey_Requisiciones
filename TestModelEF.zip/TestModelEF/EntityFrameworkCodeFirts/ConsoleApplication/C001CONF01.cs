namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONF01")]
    public partial class C001CONF01
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CONF01()
        {
            C001CONF02 = new HashSet<C001CONF02>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Rubro { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Secuencia { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Esp { get; set; }

        [StringLength(100)]
        public string Desc_Ing { get; set; }

        [Required]
        [StringLength(1)]
        public string Cod { get; set; }

        [StringLength(7)]
        public string Calculo_Porcentaje { get; set; }

        public bool Ingreso { get; set; }

        [StringLength(150)]
        public string Operacion { get; set; }

        public int Decimales { get; set; }

        public bool Negritas { get; set; }

        public bool Porcentaje { get; set; }

        [StringLength(100)]
        public string Base { get; set; }

        public bool NoAplica { get; set; }

        public int Segmento { get; set; }

        public virtual C001CONEST C001CONEST { get; set; }

        public virtual C001CONEST14 C001CONEST14 { get; set; }

        public virtual C001CONEST15 C001CONEST15 { get; set; }

        public virtual C001CONEST16 C001CONEST16 { get; set; }

        public virtual C001CONEST17 C001CONEST17 { get; set; }

        public virtual C001CONESTA C001CONESTA { get; set; }

        public virtual C001CONESTA14 C001CONESTA14 { get; set; }

        public virtual C001CONESTA15 C001CONESTA15 { get; set; }

        public virtual C001CONESTA16 C001CONESTA16 { get; set; }

        public virtual C001CONESTA17 C001CONESTA17 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONF02> C001CONF02 { get; set; }
    }
}
