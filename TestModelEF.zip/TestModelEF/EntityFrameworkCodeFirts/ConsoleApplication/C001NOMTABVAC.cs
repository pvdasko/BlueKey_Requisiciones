namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMTABVAC")]
    public partial class C001NOMTABVAC
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Tabla { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Antiguedad { get; set; }

        public double DiasVacaciones { get; set; }

        public double PorcentajePrima { get; set; }

        public double DiasAguinaldo { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Factor { get; set; }
    }
}
