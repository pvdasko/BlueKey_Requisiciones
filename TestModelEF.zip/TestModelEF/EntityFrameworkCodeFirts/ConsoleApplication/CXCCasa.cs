namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CXCCasa")]
    public partial class CXCCasa
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Ope { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Indice { get; set; }

        [Required]
        [StringLength(10)]
        public string Cod_Cliente { get; set; }

        [Required]
        [StringLength(20)]
        public string Docto { get; set; }

        [Required]
        [StringLength(250)]
        public string Nombre { get; set; }

        [Required]
        [StringLength(20)]
        public string Fecha { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        public bool Casa { get; set; }

        public bool Casado { get; set; }
    }
}
