namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMENQ")]
    public partial class C001NOMENQ
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(1)]
        public string Tipo { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(1)]
        public string TipoNomina { get; set; }

        public double Veces { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Importe { get; set; }

        [Column(TypeName = "money")]
        public decimal Gravable { get; set; }

        [Column(TypeName = "money")]
        public decimal Exento { get; set; }

        public bool Calculo { get; set; }

        public DateTime? Fecha { get; set; }

        public DateTime? Fecha_Captura { get; set; }

        public bool Reloj { get; set; }
    }
}
