namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPENSIONES")]
    public partial class C001NOMPENSIONES
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Required]
        [StringLength(2)]
        public string Porcentaje { get; set; }
    }
}
