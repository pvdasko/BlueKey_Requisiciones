namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("REPORTE")]
    public partial class REPORTE
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(10)]
        public string Linea { get; set; }

        [Column("Campo 1")]
        [Required]
        [StringLength(500)]
        public string Campo_1 { get; set; }

        [Column("Campo 2")]
        [Required]
        [StringLength(500)]
        public string Campo_2 { get; set; }

        [Column("Campo 3")]
        [Required]
        [StringLength(500)]
        public string Campo_3 { get; set; }

        [Column("Campo 4")]
        [Required]
        [StringLength(500)]
        public string Campo_4 { get; set; }

        [Column("Campo 5")]
        [Required]
        [StringLength(500)]
        public string Campo_5 { get; set; }

        [Column("Campo 6")]
        [Required]
        [StringLength(500)]
        public string Campo_6 { get; set; }

        [Column("Campo 7")]
        [Required]
        [StringLength(250)]
        public string Campo_7 { get; set; }

        [Column("Campo 8")]
        [Required]
        [StringLength(250)]
        public string Campo_8 { get; set; }

        [Column("Campo 9")]
        [Required]
        [StringLength(250)]
        public string Campo_9 { get; set; }

        [Column("Campo 10")]
        [Required]
        [StringLength(250)]
        public string Campo_10 { get; set; }

        [Column("Campo 11")]
        [Required]
        [StringLength(250)]
        public string Campo_11 { get; set; }

        [Column("Campo 12")]
        [Required]
        [StringLength(250)]
        public string Campo_12 { get; set; }

        [Column("Campo 13")]
        [Required]
        [StringLength(250)]
        public string Campo_13 { get; set; }

        [Column("Campo 14")]
        [Required]
        [StringLength(250)]
        public string Campo_14 { get; set; }

        [Column("Campo 15")]
        [Required]
        [StringLength(250)]
        public string Campo_15 { get; set; }

        [Column("Campo 16")]
        [Required]
        [StringLength(250)]
        public string Campo_16 { get; set; }

        [Column("Campo 17")]
        [Required]
        [StringLength(250)]
        public string Campo_17 { get; set; }

        [Column("Campo 18")]
        [Required]
        [StringLength(250)]
        public string Campo_18 { get; set; }

        [Column("Campo 19")]
        [Required]
        [StringLength(250)]
        public string Campo_19 { get; set; }

        [Column("Campo 20")]
        [Required]
        [StringLength(250)]
        public string Campo_20 { get; set; }

        [Column("Campo 21")]
        [Required]
        [StringLength(250)]
        public string Campo_21 { get; set; }

        [Column("Campo 22")]
        [Required]
        [StringLength(250)]
        public string Campo_22 { get; set; }

        [Column("Campo 23")]
        [Required]
        [StringLength(250)]
        public string Campo_23 { get; set; }

        [Column("Campo 24")]
        [Required]
        [StringLength(250)]
        public string Campo_24 { get; set; }

        [Column("Campo 25")]
        [Required]
        [StringLength(250)]
        public string Campo_25 { get; set; }

        [Column("Campo 26")]
        [Required]
        [StringLength(250)]
        public string Campo_26 { get; set; }

        [Column("Campo 27")]
        [Required]
        [StringLength(250)]
        public string Campo_27 { get; set; }

        [Column("Campo 28")]
        [Required]
        [StringLength(250)]
        public string Campo_28 { get; set; }

        [Column("Campo 29")]
        [Required]
        [StringLength(250)]
        public string Campo_29 { get; set; }

        [Column("Campo 30")]
        [Required]
        [StringLength(250)]
        public string Campo_30 { get; set; }

        [Column("Campo 31")]
        [Required]
        [StringLength(250)]
        public string Campo_31 { get; set; }

        [Column("Campo 32")]
        [Required]
        [StringLength(250)]
        public string Campo_32 { get; set; }

        [Column("Campo 33")]
        [Required]
        [StringLength(250)]
        public string Campo_33 { get; set; }

        [Column("Campo 34")]
        [Required]
        [StringLength(250)]
        public string Campo_34 { get; set; }

        [Column("Campo 35")]
        [Required]
        [StringLength(250)]
        public string Campo_35 { get; set; }

        [Column("Campo 36")]
        [Required]
        [StringLength(250)]
        public string Campo_36 { get; set; }

        [Column("Campo 37")]
        [Required]
        [StringLength(250)]
        public string Campo_37 { get; set; }

        [Column("Campo 38")]
        [Required]
        [StringLength(250)]
        public string Campo_38 { get; set; }

        [Column("Campo 39")]
        [Required]
        [StringLength(250)]
        public string Campo_39 { get; set; }

        [Column("Campo 40")]
        [Required]
        [StringLength(250)]
        public string Campo_40 { get; set; }

        [Column("Campo 41")]
        [StringLength(250)]
        public string Campo_41 { get; set; }

        [Column("Campo 42")]
        [StringLength(250)]
        public string Campo_42 { get; set; }

        [Column("Campo 43")]
        [StringLength(250)]
        public string Campo_43 { get; set; }

        [Column("Campo 44")]
        [StringLength(250)]
        public string Campo_44 { get; set; }

        [Column("Campo 45")]
        [StringLength(250)]
        public string Campo_45 { get; set; }

        [Column("Campo 46")]
        [StringLength(250)]
        public string Campo_46 { get; set; }

        [Column("Campo 47")]
        [StringLength(250)]
        public string Campo_47 { get; set; }

        [Column("Campo 48")]
        [StringLength(250)]
        public string Campo_48 { get; set; }

        [Column("Campo 49")]
        [StringLength(250)]
        public string Campo_49 { get; set; }

        [Column("Campo 50")]
        [StringLength(250)]
        public string Campo_50 { get; set; }

        [Column("Campo 51")]
        [StringLength(250)]
        public string Campo_51 { get; set; }

        [Column("Campo 52")]
        [StringLength(250)]
        public string Campo_52 { get; set; }

        [Column("Campo 53")]
        [StringLength(250)]
        public string Campo_53 { get; set; }

        [Column("Campo 54")]
        [StringLength(250)]
        public string Campo_54 { get; set; }

        [Column("Campo 55")]
        [StringLength(250)]
        public string Campo_55 { get; set; }

        [Column("Campo 56")]
        [StringLength(250)]
        public string Campo_56 { get; set; }

        [Column("Campo 57")]
        [StringLength(250)]
        public string Campo_57 { get; set; }

        [Column("Campo 58")]
        [StringLength(250)]
        public string Campo_58 { get; set; }

        [Column("Campo 59")]
        [StringLength(250)]
        public string Campo_59 { get; set; }

        [Column("Campo 60")]
        [StringLength(250)]
        public string Campo_60 { get; set; }

        [Column("Campo 61")]
        [StringLength(250)]
        public string Campo_61 { get; set; }

        [Column("Campo 62")]
        [StringLength(250)]
        public string Campo_62 { get; set; }

        [Column("Campo 63")]
        [StringLength(250)]
        public string Campo_63 { get; set; }

        [Column("Campo 64")]
        [StringLength(250)]
        public string Campo_64 { get; set; }

        [Column("Campo 65")]
        [StringLength(250)]
        public string Campo_65 { get; set; }

        [Column("Campo 66")]
        [StringLength(250)]
        public string Campo_66 { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string Ope { get; set; }

        [Key]
        [Column("Reporte", Order = 2)]
        [StringLength(50)]
        public string Reporte1 { get; set; }
    }
}
