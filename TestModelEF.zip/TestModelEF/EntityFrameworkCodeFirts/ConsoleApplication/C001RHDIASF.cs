namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001RHDIASF")]
    public partial class C001RHDIASF
    {
        [Key]
        [Column(TypeName = "date")]
        public DateTime Fecha { get; set; }
    }
}
