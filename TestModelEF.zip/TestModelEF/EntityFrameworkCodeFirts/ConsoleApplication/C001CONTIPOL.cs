namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONTIPOL")]
    public partial class C001CONTIPOL
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CONTIPOL()
        {
            C001CONCOG = new HashSet<C001CONCOG>();
            C001CONCOGCXP = new HashSet<C001CONCOGCXP>();
            C001CONCOGTEMP = new HashSet<C001CONCOGTEMP>();
            C001CXPBAN = new HashSet<C001CXPBAN>();
        }

        [Key]
        [StringLength(2)]
        public string Tipo_Poliza { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        [Required]
        [StringLength(1)]
        public string TipoAnterior { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo_SAT { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONCOG> C001CONCOG { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONCOGCXP> C001CONCOGCXP { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONCOGTEMP> C001CONCOGTEMP { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CXPBAN> C001CXPBAN { get; set; }
    }
}
