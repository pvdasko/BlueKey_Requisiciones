namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TESORERIA_TABLA
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TESORERIA_TABLA()
        {
            CategoriasMovtos = new HashSet<CategoriasMovtos>();
            TESORERIA_LINEAS = new HashSet<TESORERIA_LINEAS>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        public double Indice { get; set; }

        [Required]
        [StringLength(2)]
        public string Tipo_Poliza { get; set; }

        public DateTime? Fecha { get; set; }

        public double? Cliente { get; set; }

        [Required]
        [StringLength(250)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono { get; set; }

        [Required]
        [StringLength(250)]
        public string Categoria { get; set; }

        [Required]
        [StringLength(250)]
        public string ConceptoGral { get; set; }

        public DateTime? Fecha_Aplica { get; set; }

        public bool Contabilizado { get; set; }

        [StringLength(19)]
        public string Cuenta { get; set; }

        [StringLength(10)]
        public string Referencia { get; set; }

        [StringLength(8)]
        public string Poliza { get; set; }

        [StringLength(10)]
        public string Proveedor { get; set; }

        public bool Conciliado { get; set; }

        public bool Guardado { get; set; }

        [Required]
        [StringLength(5)]
        public string Usuario { get; set; }

        [Column(TypeName = "money")]
        public decimal TipoCambio { get; set; }

        public bool Desconocido { get; set; }

        [Column(TypeName = "money")]
        public decimal CargoIETU { get; set; }

        [Column(TypeName = "money")]
        public decimal AbonoIETU { get; set; }

        public bool AplicaIETU { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteIva { get; set; }

        [Required]
        [StringLength(250)]
        public string Comentarios { get; set; }

        [Required]
        [StringLength(250)]
        public string CategoriaIETU { get; set; }

        [Column(TypeName = "money")]
        public decimal PorcIva { get; set; }

        [Column(TypeName = "money")]
        public decimal PorcISR { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteISR { get; set; }

        public bool AplicaRet { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteRet { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CategoriasMovtos> CategoriasMovtos { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TESORERIA_LINEAS> TESORERIA_LINEAS { get; set; }
    }
}
