namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCOGTEMP")]
    public partial class C001CONCOGTEMP
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Tipo_PolG { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(8)]
        public string Num_PolG { get; set; }

        public DateTime Fecha_PolG { get; set; }

        [Required]
        [StringLength(300)]
        public string Concepto_PolG { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tot_Cargos { get; set; }

        [Column(TypeName = "money")]
        public decimal Tot_Abonos { get; set; }

        public bool Status { get; set; }

        [StringLength(10)]
        public string Libre_2 { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Cap { get; set; }

        public bool Genera { get; set; }

        public bool Traspasada { get; set; }

        [Required]
        [StringLength(8)]
        public string NumeroExporta { get; set; }

        public bool Poliza_Dolares { get; set; }

        public virtual C001CONTIPOL C001CONTIPOL { get; set; }
    }
}
