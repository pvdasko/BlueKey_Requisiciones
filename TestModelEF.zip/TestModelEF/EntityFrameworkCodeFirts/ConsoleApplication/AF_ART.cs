namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_ART
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AF_ART()
        {
            AF_LIN = new HashSet<AF_LIN>();
        }

        [Key]
        public long Cod_Art { get; set; }

        [Required]
        [StringLength(50)]
        public string Cod_Barras { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Esp { get; set; }

        [StringLength(100)]
        public string Desc_Ing { get; set; }

        [Required]
        [StringLength(4)]
        public string Alm { get; set; }

        [Required]
        [StringLength(4)]
        public string Sub_Alm { get; set; }

        public double IVA { get; set; }

        [StringLength(50)]
        public string Notas { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_1 { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_2 { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Maximo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Minimo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Reorden { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Ent { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Sal { get; set; }

        [Required]
        [StringLength(3)]
        public string Conver { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }

        public virtual C001CXPCAT C001CXPCAT1 { get; set; }

        public virtual AF_MED AF_MED { get; set; }

        public virtual AF_MED AF_MED1 { get; set; }

        public virtual AF_SUB AF_SUB { get; set; }

        public virtual AF_EST AF_EST { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_LIN> AF_LIN { get; set; }
    }
}
