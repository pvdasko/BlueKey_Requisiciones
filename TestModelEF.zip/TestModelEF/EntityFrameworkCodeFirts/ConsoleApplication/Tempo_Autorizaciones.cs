namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Tempo_Autorizaciones
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Usuario { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Indice { get; set; }

        [Required]
        [StringLength(50)]
        public string No_Req { get; set; }

        [Required]
        [StringLength(250)]
        public string Departamento { get; set; }

        [Required]
        [StringLength(350)]
        public string Notas { get; set; }

        public DateTime? Fecha { get; set; }

        public DateTime? Hora { get; set; }

        public DateTime? Hora_Aut { get; set; }

        [Required]
        [StringLength(3)]
        public string Operador { get; set; }

        public bool Autoriza { get; set; }

        [Required]
        [StringLength(3)]
        public string OpeAut { get; set; }

        [Column(TypeName = "money")]
        public decimal Total { get; set; }
    }
}
