namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CON_FACLIN
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Indice { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public long Cod_Art { get; set; }

        public double Can { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Costo { get; set; }

        [Column(TypeName = "money")]
        public decimal Total { get; set; }

        [StringLength(16)]
        public string Cta_Con { get; set; }

        [Column(TypeName = "money")]
        public decimal Iva { get; set; }

        [Required]
        [StringLength(100)]
        public string Concepto { get; set; }

        public virtual CON_FACGEN CON_FACGEN { get; set; }
    }
}
