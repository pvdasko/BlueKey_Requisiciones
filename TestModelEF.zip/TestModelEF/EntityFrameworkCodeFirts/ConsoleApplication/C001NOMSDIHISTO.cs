namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMSDIHISTO")]
    public partial class C001NOMSDIHISTO
    {
        [Key]
        [Column(Order = 0)]
        public DateTime FechaCambio { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        public double Dias { get; set; }

        [Column(TypeName = "money")]
        public decimal SD { get; set; }

        [Column(TypeName = "money")]
        public decimal SDI { get; set; }

        [Column(TypeName = "money")]
        public decimal Variable { get; set; }

        [Column(TypeName = "money")]
        public decimal Promedio { get; set; }

        [Column(TypeName = "money")]
        public decimal NSDI { get; set; }

        public DateTime? Alta { get; set; }
    }
}
