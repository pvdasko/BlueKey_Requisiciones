namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONTAB_TIPO_CAMBIO
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Codigo_Divisa { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha { get; set; }

        [Column(TypeName = "money")]
        public decimal Tipo_Cambio { get; set; }

        public virtual CONTAB_DIVISAS CONTAB_DIVISAS { get; set; }
    }
}
