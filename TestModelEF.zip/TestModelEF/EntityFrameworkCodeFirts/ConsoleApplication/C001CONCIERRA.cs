namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCIERRA")]
    public partial class C001CONCIERRA
    {
        [Key]
        [StringLength(4)]
        public string Periodo { get; set; }

        public bool Cerrado { get; set; }
    }
}
