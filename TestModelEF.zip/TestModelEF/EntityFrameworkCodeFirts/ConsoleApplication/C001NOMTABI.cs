namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMTABI")]
    public partial class C001NOMTABI
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(1)]
        public string Tipo { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(1)]
        public string Tabla { get; set; }

        [Key]
        [Column(Order = 2)]
        public double Lim_Sup { get; set; }

        public double Lim_Inf { get; set; }

        public double Importe { get; set; }

        public double Porcentaje { get; set; }
    }
}
