namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSTRANSTEMP")]
    public partial class C001COSTRANSTEMP
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string USUARIO { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string DEP_ORI { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string DEP_DES { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long ART { get; set; }

        [Required]
        [StringLength(100)]
        public string NOMBRE { get; set; }

        public double CANTIDAD { get; set; }

        [Required]
        [StringLength(10)]
        public string UNIDAD { get; set; }

        [Column(TypeName = "money")]
        public decimal COSTO { get; set; }

        public DateTime FechaReg { get; set; }
    }
}
