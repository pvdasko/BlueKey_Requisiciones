namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NomExpBitacora")]
    public partial class NomExpBitacora
    {
        [Key]
        [Column(Order = 0)]
        public long Indice { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Empleado { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime FechaReal { get; set; }

        [Required]
        [StringLength(500)]
        public string DatoNuevo { get; set; }

        [Required]
        [StringLength(500)]
        public string DatoAnterior { get; set; }

        [Required]
        [StringLength(6)]
        public string Usuario { get; set; }
    }
}
