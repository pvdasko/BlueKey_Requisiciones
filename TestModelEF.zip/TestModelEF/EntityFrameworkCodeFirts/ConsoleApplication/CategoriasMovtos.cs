namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CategoriasMovtos
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        public double Indice { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public int Nivel_1 { get; set; }

        public int Nivel_2 { get; set; }

        public int Nivel_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        [StringLength(19)]
        public string Cuenta { get; set; }

        public virtual Categorias Categorias { get; set; }

        public virtual TESORERIA_TABLA TESORERIA_TABLA { get; set; }
    }
}
