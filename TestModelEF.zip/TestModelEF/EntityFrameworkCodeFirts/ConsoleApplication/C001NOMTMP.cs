namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMTMP")]
    public partial class C001NOMTMP
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        public int DiasPagar { get; set; }

        public short Antiguedad { get; set; }

        public DateTime Alta { get; set; }

        public DateTime Baja { get; set; }

        public int DiasResto { get; set; }
    }
}
