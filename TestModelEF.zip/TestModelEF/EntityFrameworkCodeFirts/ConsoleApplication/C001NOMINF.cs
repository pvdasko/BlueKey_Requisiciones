namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMINF")]
    public partial class C001NOMINF
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Column(TypeName = "money")]
        public decimal Porcentaje { get; set; }

        [Column(TypeName = "money")]
        public decimal Prestamo { get; set; }

        [Column(TypeName = "money")]
        public decimal Retencion { get; set; }

        [Column(TypeName = "money")]
        public decimal Saldo { get; set; }

        public bool Mantto { get; set; }
    }
}
