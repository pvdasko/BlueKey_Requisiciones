namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCTIP")]
    public partial class C001CXCTIP
    {
        [Key]
        [StringLength(2)]
        public string Codigo_Tipo { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombre_Tipo { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [Required]
        [StringLength(50)]
        public string Nombre_Ingles { get; set; }

        [Required]
        [StringLength(20)]
        public string Cta_Contable { get; set; }

        public bool Dolares { get; set; }
    }
}
