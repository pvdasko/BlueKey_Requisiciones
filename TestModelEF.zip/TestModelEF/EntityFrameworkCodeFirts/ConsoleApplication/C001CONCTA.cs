namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCTA")]
    public partial class C001CONCTA
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CONCTA()
        {
            C001CONCOL = new HashSet<C001CONCOL>();
            C001INVDEPCTAS = new HashSet<C001INVDEPCTAS>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo_Cuenta { get; set; }

        [Required]
        [StringLength(2)]
        public string Clasificacion { get; set; }

        [Required]
        [StringLength(2)]
        public string Subclasificacion { get; set; }

        [StringLength(100)]
        public string Descripcion { get; set; }

        [StringLength(100)]
        public string Descripcion_2 { get; set; }

        public bool Flujo_Efectivo { get; set; }

        public bool Afectable { get; set; }

        [StringLength(16)]
        public string Complementaria { get; set; }

        public bool Cta_Modulo { get; set; }

        [StringLength(10)]
        public string Libre_1 { get; set; }

        [StringLength(10)]
        public string Libre_2 { get; set; }

        [Required]
        [StringLength(300)]
        public string Comentarios { get; set; }

        public bool Especial { get; set; }

        public int Segmento { get; set; }

        public bool Cuenta_Dolares { get; set; }

        [StringLength(1)]
        public string TipoAD { get; set; }

        public bool Cta_Anticipo { get; set; }

        [StringLength(3)]
        public string Codigo_Divisa { get; set; }

        public bool Cta_CXC { get; set; }

        public bool No_Deducible { get; set; }

        [Required]
        [StringLength(2)]
        public string AgrupadorSAT { get; set; }

        [Required]
        [StringLength(5)]
        public string SubAgrupadorSAT { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONCOL> C001CONCOL { get; set; }

        public virtual C001CONPRE14 C001CONPRE14 { get; set; }

        public virtual C001CONPRE15 C001CONPRE15 { get; set; }

        public virtual C001CONPRE16 C001CONPRE16 { get; set; }

        public virtual C001CONPRE17 C001CONPRE17 { get; set; }

        public virtual C001CONSAL14 C001CONSAL14 { get; set; }

        public virtual C001CONSAL15 C001CONSAL15 { get; set; }

        public virtual C001CONSAL16 C001CONSAL16 { get; set; }

        public virtual C001CONSAL17 C001CONSAL17 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVDEPCTAS> C001INVDEPCTAS { get; set; }
    }
}
