namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONF03")]
    public partial class C001CONF03
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Rubro { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Secuencia { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal APres_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal AMes_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal ASal_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PMes_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PSal_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PPres_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAPres_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PAMes_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal PASal_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal Sal_0 { get; set; }
    }
}
