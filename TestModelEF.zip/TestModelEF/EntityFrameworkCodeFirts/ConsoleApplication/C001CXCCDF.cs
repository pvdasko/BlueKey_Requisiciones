namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCCDF")]
    public partial class C001CXCCDF
    {
        [Key]
        [StringLength(4)]
        public string Codigo_Cargo { get; set; }

        [Required]
        [StringLength(10)]
        public string Tipo_Cargo { get; set; }

        [Required]
        [StringLength(100)]
        public string Nombre_Codigo { get; set; }

        [StringLength(100)]
        public string Nombre_Ingles { get; set; }

        public bool? Folio { get; set; }

        public bool? Iva { get; set; }

        public bool? Ish { get; set; }

        [StringLength(16)]
        public string Cuenta { get; set; }
    }
}
