namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPARAM")]
    public partial class C001NOMPARAM
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        public int Sueldo { get; set; }

        public int Ispt { get; set; }

        public int Imss { get; set; }

        public int Credito { get; set; }

        public int Fonacot { get; set; }

        public int Infonavit { get; set; }

        public int FondoAhorro { get; set; }

        public int ImpMarginal { get; set; }

        public int ImssPatronal { get; set; }

        public int CuotaSindical { get; set; }

        public int SeguroVida { get; set; }

        public int FondoSeguro { get; set; }

        public int Alimentos { get; set; }
    }
}
