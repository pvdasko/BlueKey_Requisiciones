namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("QueryTemporal")]
    public partial class QueryTemporal
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(5)]
        public string Usuario { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string Query { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Lineas { get; set; }

        [StringLength(150)]
        public string Tempo_01 { get; set; }

        [StringLength(150)]
        public string Tempo_02 { get; set; }

        [StringLength(150)]
        public string Tempo_03 { get; set; }

        [StringLength(150)]
        public string Tempo_04 { get; set; }

        [StringLength(150)]
        public string Tempo_05 { get; set; }

        [StringLength(150)]
        public string Tempo_06 { get; set; }

        [StringLength(150)]
        public string Tempo_07 { get; set; }

        [StringLength(150)]
        public string Tempo_08 { get; set; }

        [StringLength(150)]
        public string Tempo_09 { get; set; }

        [StringLength(150)]
        public string Tempo_10 { get; set; }

        [StringLength(150)]
        public string Tempo_11 { get; set; }

        [StringLength(150)]
        public string Tempo_12 { get; set; }

        [StringLength(150)]
        public string Tempo_13 { get; set; }

        [StringLength(150)]
        public string Tempo_14 { get; set; }

        [StringLength(150)]
        public string Tempo_15 { get; set; }

        [StringLength(150)]
        public string Tempo_16 { get; set; }

        [StringLength(150)]
        public string Tempo_17 { get; set; }

        [StringLength(150)]
        public string Tempo_18 { get; set; }

        [StringLength(150)]
        public string Tempo_19 { get; set; }

        [StringLength(150)]
        public string Tempo_20 { get; set; }
    }
}
