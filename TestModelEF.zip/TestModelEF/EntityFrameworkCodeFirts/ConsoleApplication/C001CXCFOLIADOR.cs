namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCFOLIADOR")]
    public partial class C001CXCFOLIADOR
    {
        [StringLength(3)]
        public string Id { get; set; }

        public long Folio_Factura { get; set; }

        public long Folio_Paso { get; set; }

        public long Billing { get; set; }
    }
}
