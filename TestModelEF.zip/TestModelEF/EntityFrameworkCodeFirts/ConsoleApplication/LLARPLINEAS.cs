namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class LLARPLINEAS
    {
        [Key]
        [StringLength(10)]
        public string Opcion { get; set; }

        [Required]
        [StringLength(30)]
        public string Nombre_de_Opcion { get; set; }

        [StringLength(10)]
        public string Password { get; set; }

        [StringLength(2)]
        public string Terminal { get; set; }
    }
}
