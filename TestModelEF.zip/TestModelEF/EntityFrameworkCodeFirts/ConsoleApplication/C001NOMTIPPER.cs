namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMTIPPER")]
    public partial class C001NOMTIPPER
    {
        [Key]
        [StringLength(1)]
        public string Tipo_Periodo { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }
    }
}
