namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ARPMENUS
    {
        [Key]
        [StringLength(6)]
        public string No_de_Menu { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion_Espanol { get; set; }

        [StringLength(50)]
        public string Descripcion_Ingles { get; set; }

        [StringLength(10)]
        public string Password { get; set; }

        [StringLength(2)]
        public string Terminal { get; set; }

        public bool Visible { get; set; }

        [StringLength(100)]
        public string Nombre_programa { get; set; }

        [StringLength(50)]
        public string Maestro { get; set; }
    }
}
