namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCPARAM")]
    public partial class C001CXCPARAM
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        [Column(TypeName = "money")]
        public decimal AlimAdulto { get; set; }

        [Column(TypeName = "money")]
        public decimal AlimMenor { get; set; }

        [Column(TypeName = "money")]
        public decimal PropMesero { get; set; }

        [Column(TypeName = "money")]
        public decimal PropCamarista { get; set; }
    }
}
