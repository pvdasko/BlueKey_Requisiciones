namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPERVAC")]
    public partial class C001NOMPERVAC
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha_Ini { get; set; }

        public DateTime Fecha_Fin { get; set; }

        public int Dias { get; set; }

        public DateTime Fecha_Cap { get; set; }
    }
}
