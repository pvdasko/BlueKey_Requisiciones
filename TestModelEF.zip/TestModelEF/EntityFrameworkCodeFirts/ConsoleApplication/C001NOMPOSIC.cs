namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPOSIC")]
    public partial class C001NOMPOSIC
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001NOMPOSIC()
        {
            C001RHEMP = new HashSet<C001RHEMP>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Num_Pos { get; set; }

        [Required]
        [StringLength(80)]
        public string Nom_Pos { get; set; }

        [Column(TypeName = "money")]
        public decimal? Sdo_Dia { get; set; }

        [Column(TypeName = "money")]
        public decimal? Fac_Sdo { get; set; }

        [StringLength(2)]
        public string Nivel { get; set; }

        public bool Vales { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001RHEMP> C001RHEMP { get; set; }
    }
}
