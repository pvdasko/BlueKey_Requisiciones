namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TEMPPOLIZAS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Depto { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        public double Veces { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        public double Tipo { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }
    }
}
