namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPTUDATOS")]
    public partial class C001NOMPTUDATOS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Column(TypeName = "money")]
        public decimal Repartir { get; set; }

        public double DiasMin { get; set; }

        public int NoConc { get; set; }

        public int ConceptoAnual { get; set; }

        public int ConceptoGarantia { get; set; }

        [Column(TypeName = "money")]
        public decimal Garantia { get; set; }

        [Column(TypeName = "money")]
        public decimal TopeSueldo { get; set; }

        [Column(TypeName = "money")]
        public decimal MayorSindicalizado { get; set; }
    }
}
