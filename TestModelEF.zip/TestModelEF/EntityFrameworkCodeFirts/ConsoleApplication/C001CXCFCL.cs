namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCFCL")]
    public partial class C001CXCFCL
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string No_Factura { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Linea { get; set; }

        [Required]
        [StringLength(4)]
        public string Tipo_Mov { get; set; }

        [StringLength(12)]
        public string Cupon { get; set; }

        [StringLength(10)]
        public string Folio { get; set; }

        public DateTime? Entrada { get; set; }

        public short? Noches { get; set; }

        [StringLength(6)]
        public string Tipo_Cuarto { get; set; }

        [StringLength(10)]
        public string PPlan { get; set; }

        public short? Adultos { get; set; }

        public short? MenPagando { get; set; }

        public short? MenGratis { get; set; }

        public short? Juniors { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tarifa { get; set; }

        [Required]
        [StringLength(250)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Total { get; set; }
    }
}
