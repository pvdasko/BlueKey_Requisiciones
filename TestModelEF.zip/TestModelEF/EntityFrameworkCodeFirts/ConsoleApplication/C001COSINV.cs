namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSINV")]
    public partial class C001COSINV
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Depto { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        public double Exis_Dia { get; set; }

        public double Exis_Mes { get; set; }

        public double Exis_Per { get; set; }

        public double Ent_Dia { get; set; }

        public double Ent_Mes { get; set; }

        public double Ent_Per { get; set; }

        public double Sal_Dia { get; set; }

        public double Sal_Mes { get; set; }

        public double Sal_Per { get; set; }

        public double Devalm_Dia { get; set; }

        public double Devalm_Mes { get; set; }

        public double Devalm_Per { get; set; }

        public double Ajus_Dia { get; set; }

        public double Ajus_Med { get; set; }

        public double Ajus_Per { get; set; }

        public double Tras_Dia { get; set; }

        public double Tras_Mes { get; set; }

        public double Tras_Per { get; set; }

        [Required]
        [StringLength(2)]
        public string Unidad { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Dia { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Mes { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Per { get; set; }

        public DateTime? Fecha_UE { get; set; }

        public DateTime? Fecha_US { get; set; }

        public DateTime? Fecha_UAJ { get; set; }

        public DateTime? Fecha_UDA { get; set; }

        public double Ajus_Mes { get; set; }

        public double? Inv_Act { get; set; }
    }
}
