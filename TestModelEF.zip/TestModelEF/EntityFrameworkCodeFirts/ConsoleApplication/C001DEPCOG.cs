namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001DEPCOG")]
    public partial class C001DEPCOG
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Tipo_PolG { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(8)]
        public string Num_PolG { get; set; }

        public DateTime Fecha_PolG { get; set; }

        [Required]
        [StringLength(100)]
        public string Concepto_PolG { get; set; }

        public bool Status { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Cap { get; set; }
    }
}
