namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCONCAUT")]
    public partial class C001NOMCONCAUT
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        public bool PorImporte { get; set; }

        public bool PorPorcentaje { get; set; }

        public bool PorcSMDF { get; set; }

        public bool PorcSueldo { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteSindicato { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteConfianza { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteEjecutivo { get; set; }

        public double PorcSindicato { get; set; }

        public double PorcConfianza { get; set; }

        public double PorcEjecutivo { get; set; }

        public bool BaseDiasTrabajados { get; set; }

        public bool Suspendido { get; set; }

        public bool NoAplicaSinDias { get; set; }

        public bool PrimeraQuin { get; set; }

        public bool SegundaQuin { get; set; }

        public bool AmbasQuin { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteSindicato1 { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteConfianza1 { get; set; }

        [Column(TypeName = "money")]
        public decimal ImporteEjecutivo1 { get; set; }

        public bool PorcSMR { get; set; }

        public bool AplicaSM { get; set; }

        public bool PorcSDI { get; set; }
    }
}
