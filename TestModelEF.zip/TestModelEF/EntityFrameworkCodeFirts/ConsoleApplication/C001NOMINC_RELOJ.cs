namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMINC_RELOJ")]
    public partial class C001NOMINC_RELOJ
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Concepto { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string Fecha { get; set; }

        [Required]
        [StringLength(250)]
        public string Incidencia { get; set; }

        public bool Ok { get; set; }

        public bool Traspasado { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }
    }
}
