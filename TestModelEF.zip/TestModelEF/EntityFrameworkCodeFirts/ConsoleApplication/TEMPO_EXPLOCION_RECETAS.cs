namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TEMPO_EXPLOCION_RECETAS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Usuario { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string Consecutivo { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(40)]
        public string Receta { get; set; }

        [Required]
        [StringLength(100)]
        public string NomReceta { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Linea { get; set; }

        [Required]
        [StringLength(40)]
        public string Articulo { get; set; }

        [Required]
        [StringLength(40)]
        public string SubReceta { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        public double Cantidad { get; set; }

        [Required]
        [StringLength(10)]
        public string Unidad { get; set; }

        [Required]
        [StringLength(50)]
        public string NomUnidad { get; set; }

        [Column(TypeName = "money")]
        public decimal Costo { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(20)]
        public string Folio { get; set; }
    }
}
