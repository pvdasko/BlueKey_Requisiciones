namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCOLTEMP")]
    public partial class C001CONCOLTEMP
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Tipo_PolL { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(8)]
        public string Num_PolL { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }

        public DateTime Fecha_PolL { get; set; }

        [Required]
        [StringLength(50)]
        public string Concepto_PolL { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono { get; set; }

        [StringLength(3)]
        public string Cia_Con { get; set; }

        [StringLength(3)]
        public string Cia_Cap { get; set; }

        [StringLength(10)]
        public string Documento { get; set; }

        [StringLength(10)]
        public string Referencia { get; set; }

        public long Caza { get; set; }

        public DateTime Fecha_Cap { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Cap { get; set; }

        [StringLength(6)]
        public string Cod_Cxc { get; set; }

        [StringLength(6)]
        public string Cod_Mov { get; set; }

        [StringLength(2)]
        public string Flujo { get; set; }

        [Column(TypeName = "money")]
        public decimal? Iva { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo_Dolares { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono_Dolares { get; set; }

        public int Segmento { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        public DateTime? Fecha_Aplica { get; set; }

        [StringLength(4)]
        public string Cod_Depto { get; set; }

        public bool Casado { get; set; }

        public bool EnTesoreria { get; set; }

        [Required]
        [StringLength(250)]
        public string ConceptoBanco { get; set; }

        [Required]
        [StringLength(4)]
        public string Periodo_Conciliado { get; set; }
    }
}
