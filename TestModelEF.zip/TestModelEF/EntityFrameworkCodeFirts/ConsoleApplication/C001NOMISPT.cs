namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMISPT")]
    public partial class C001NOMISPT
    {
        [Key]
        [StringLength(3)]
        public string Conse { get; set; }

        [StringLength(80)]
        public string Descripcion { get; set; }
    }
}
