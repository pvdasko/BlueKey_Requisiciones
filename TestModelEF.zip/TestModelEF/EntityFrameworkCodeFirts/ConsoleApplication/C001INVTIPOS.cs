namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVTIPOS")]
    public partial class C001INVTIPOS
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVTIPOS()
        {
            C001INVGEN = new HashSet<C001INVGEN>();
            CON_FACGEN = new HashSet<CON_FACGEN>();
        }

        [Key]
        [StringLength(3)]
        public string Cod_Tip { get; set; }

        [Required]
        [StringLength(50)]
        public string Desc_Tip { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVGEN> C001INVGEN { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CON_FACGEN> CON_FACGEN { get; set; }
    }
}
