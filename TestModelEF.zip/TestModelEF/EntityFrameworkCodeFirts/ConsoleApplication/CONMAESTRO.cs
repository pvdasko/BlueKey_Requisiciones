namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CONMAESTRO")]
    public partial class CONMAESTRO
    {
        [Key]
        [StringLength(3)]
        public string Codigo_Cia { get; set; }

        [Required]
        [StringLength(100)]
        public string Razon_Social { get; set; }

        [StringLength(100)]
        public string Direccion { get; set; }

        [StringLength(100)]
        public string Colonia { get; set; }

        [StringLength(50)]
        public string Entidad_Federativa { get; set; }

        [StringLength(50)]
        public string Municipio_Delegacion { get; set; }

        [StringLength(10)]
        public string Codigo_Postal { get; set; }

        [Required]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Required]
        [StringLength(16)]
        public string Cuenta_Resultado { get; set; }

        [StringLength(12)]
        public string Fecha_Proceso { get; set; }

        [StringLength(50)]
        public string Nombre_Base { get; set; }

        [StringLength(50)]
        public string Directorio_Trabajo { get; set; }

        [StringLength(200)]
        public string Cadena_Conn { get; set; }

        [StringLength(16)]
        public string Cuenta_Proveedores { get; set; }

        [StringLength(16)]
        public string Cuenta_Clientes { get; set; }

        [StringLength(16)]
        public string Cuenta_Iva { get; set; }

        public double? Impuesto_Hospedaje_ISHR { get; set; }

        public double? Factor_Servicio { get; set; }

        [StringLength(6)]
        public string Consecutivo_Factura { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tipo_Cambio { get; set; }
    }
}
