namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSRCL")]
    public partial class C001COSRCL
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Cod_Receta { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Linea { get; set; }

        public long? Cod_Art { get; set; }

        [StringLength(50)]
        public string Cod_Subrec { get; set; }

        [Required]
        [StringLength(2)]
        public string Uni_Med { get; set; }

        public double Cantidad { get; set; }
    }
}
