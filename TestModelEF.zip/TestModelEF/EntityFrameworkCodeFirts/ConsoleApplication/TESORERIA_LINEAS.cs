namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TESORERIA_LINEAS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        public double Indice { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        [Required]
        [StringLength(19)]
        public string Cuenta { get; set; }

        [StringLength(250)]
        public string Descripcion { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        public virtual TESORERIA_TABLA TESORERIA_TABLA { get; set; }
    }
}
