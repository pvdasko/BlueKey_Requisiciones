namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCFAI")]
    public partial class C001CXCFAI
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(6)]
        public string Factura { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Codigo_Cliente { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(6)]
        public string Folio { get; set; }

        [StringLength(80)]
        public string Nombre { get; set; }

        public DateTime? Fecha_Ent { get; set; }

        public DateTime? Fecha_Sal { get; set; }

        public DateTime? Fecha_Fac { get; set; }

        [StringLength(25)]
        public string libre_1 { get; set; }

        [StringLength(16)]
        public string Cta_Con { get; set; }

        [StringLength(8)]
        public string Fecha_Cap { get; set; }

        [StringLength(25)]
        public string Ope_Cap { get; set; }

        [StringLength(25)]
        public string Cantidad { get; set; }

        [StringLength(25)]
        public string Cantidad_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Iva { get; set; }

        [Column(TypeName = "money")]
        public decimal? Dolar { get; set; }
    }
}
