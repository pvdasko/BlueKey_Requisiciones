namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVREC_TEMPO")]
    public partial class C001INVREC_TEMPO
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Ped { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public long Cod_Art { get; set; }

        public double Cantidad_Solicitada { get; set; }

        public double Cantidad_Entregada { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Cantidad_Faltante { get; set; }

        public double Cantidad_Entrante { get; set; }

        [Column(TypeName = "money")]
        public decimal Costo { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total { get; set; }
    }
}
