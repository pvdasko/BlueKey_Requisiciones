namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMINTEGRADOS")]
    public partial class C001NOMINTEGRADOS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha { get; set; }

        [Column(TypeName = "money")]
        public decimal Sueldo { get; set; }

        [Column(TypeName = "money")]
        public decimal Aguinaldo { get; set; }

        [Column(TypeName = "money")]
        public decimal Prima { get; set; }

        [Column(TypeName = "money")]
        public decimal Despensa { get; set; }

        [Column(TypeName = "money")]
        public decimal Comedor { get; set; }

        [Column(TypeName = "money")]
        public decimal Variables { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? SueldoIntegrado { get; set; }
    }
}
