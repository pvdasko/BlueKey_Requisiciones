namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMVAR")]
    public partial class C001NOMVAR
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Variable { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        [Required]
        [StringLength(20)]
        public string Abreviatura { get; set; }
    }
}
