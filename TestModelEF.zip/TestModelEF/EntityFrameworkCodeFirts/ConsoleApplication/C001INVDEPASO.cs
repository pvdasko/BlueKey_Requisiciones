namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVDEPASO")]
    public partial class C001INVDEPASO
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string Desc_Esp { get; set; }

        [StringLength(50)]
        public string Desc_Ing { get; set; }

        [StringLength(19)]
        public string Cta_Mayor { get; set; }

        [StringLength(4)]
        public string Cta_Nivel { get; set; }

        [Key]
        [Column(Order = 2)]
        public bool Inventario { get; set; }

        [StringLength(50)]
        public string BD { get; set; }
    }
}
