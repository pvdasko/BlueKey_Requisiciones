namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCTA")]
    public partial class C001CXPCTA
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }
    }
}
