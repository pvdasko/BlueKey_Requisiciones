namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class PARAMETROS
    {
        [Key]
        [StringLength(4)]
        public string Parametro { get; set; }

        [StringLength(100)]
        public string Descripcion { get; set; }

        [Required]
        [StringLength(20)]
        public string Valor { get; set; }
    }
}
