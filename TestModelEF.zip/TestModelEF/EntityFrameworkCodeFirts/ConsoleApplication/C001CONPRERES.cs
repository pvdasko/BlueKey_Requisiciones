namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONPRERES")]
    public partial class C001CONPRERES
    {
        [Key]
        public long Consecutivo { get; set; }

        [Required]
        [StringLength(2)]
        public string Periodo { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime Hora { get; set; }

        [Required]
        [StringLength(3)]
        public string Oper { get; set; }

        public bool Especial { get; set; }

        public double Porc_1 { get; set; }

        public double Porc_2 { get; set; }

        public double Porc_3 { get; set; }

        public double Porc_4 { get; set; }

        public double Porc_5 { get; set; }

        public double Porc_6 { get; set; }

        public double Porc_7 { get; set; }

        public double Porc_8 { get; set; }

        public double Porc_9 { get; set; }

        public double Porc_10 { get; set; }

        public double Porc_11 { get; set; }

        public double Porc_12 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_1 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_2 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_3 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_4 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_5 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_6 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_7 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_8 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_9 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_10 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_11 { get; set; }

        [Required]
        [StringLength(300)]
        public string Notas_12 { get; set; }

        public bool R_1 { get; set; }

        public bool R_2 { get; set; }

        public bool R_3 { get; set; }

        public bool R_4 { get; set; }

        public bool R_5 { get; set; }

        public bool R_6 { get; set; }

        public bool R_7 { get; set; }

        public bool R_8 { get; set; }

        public bool R_9 { get; set; }

        public bool R_10 { get; set; }

        public bool R_11 { get; set; }

        public bool R_12 { get; set; }

        public bool P_1 { get; set; }

        public bool P_2 { get; set; }

        public bool P_3 { get; set; }

        public bool P_4 { get; set; }

        public bool P_5 { get; set; }

        public bool P_6 { get; set; }

        public bool P_7 { get; set; }

        public bool P_8 { get; set; }

        public bool P_9 { get; set; }

        public bool P_10 { get; set; }

        public bool P_11 { get; set; }

        public bool P_12 { get; set; }
    }
}
