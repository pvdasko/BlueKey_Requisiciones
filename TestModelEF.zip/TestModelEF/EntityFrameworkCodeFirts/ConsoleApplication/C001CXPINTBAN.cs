namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPINTBAN")]
    public partial class C001CXPINTBAN
    {
        [Key]
        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(20)]
        public string CtaBanco { get; set; }

        [StringLength(50)]
        public string Clabe { get; set; }

        [StringLength(10)]
        public string IdEstado { get; set; }

        [StringLength(10)]
        public string IdCiudad { get; set; }

        [StringLength(10)]
        public string IdBanco { get; set; }

        [StringLength(10)]
        public string Plaza { get; set; }

        [StringLength(20)]
        public string Sucursal { get; set; }

        [StringLength(10)]
        public string IdProv { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }
    }
}
