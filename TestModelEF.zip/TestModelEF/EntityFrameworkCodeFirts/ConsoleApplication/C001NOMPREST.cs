namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPREST")]
    public partial class C001NOMPREST
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string Referencia { get; set; }

        [Required]
        [StringLength(4)]
        public string PeriodoInicio { get; set; }

        [Column(TypeName = "money")]
        public decimal Prestamo { get; set; }

        public bool PorPorcentaje { get; set; }

        public bool PorMonto { get; set; }

        public bool PorVecesSMDF { get; set; }

        public double Porcentaje { get; set; }

        [Column(TypeName = "money")]
        public decimal Monto { get; set; }

        public double VecesSMDF { get; set; }

        [Column(TypeName = "money")]
        public decimal Descontado { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Saldo { get; set; }

        public bool Cancelado { get; set; }

        public bool Suspendido { get; set; }

        public bool AmbasQuin { get; set; }

        public bool PrimeraQuin { get; set; }

        public bool SegundaQuin { get; set; }

        public virtual C001NOMCON C001NOMCON { get; set; }

        public virtual C001RHEMP C001RHEMP { get; set; }
    }
}
