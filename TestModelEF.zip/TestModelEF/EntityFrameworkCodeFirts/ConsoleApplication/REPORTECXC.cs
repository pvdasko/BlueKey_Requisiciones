namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("REPORTECXC")]
    public partial class REPORTECXC
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(10)]
        public string Linea { get; set; }

        [Column("Campo 1")]
        [Required]
        [StringLength(250)]
        public string Campo_1 { get; set; }

        [Column("Campo 2")]
        [Required]
        [StringLength(250)]
        public string Campo_2 { get; set; }

        [Column("Campo 3")]
        [Required]
        [StringLength(250)]
        public string Campo_3 { get; set; }

        [Column("Campo 4")]
        [Required]
        [StringLength(250)]
        public string Campo_4 { get; set; }

        [Column("Campo 5")]
        [Required]
        [StringLength(250)]
        public string Campo_5 { get; set; }

        [Column("Campo 6")]
        [Required]
        [StringLength(250)]
        public string Campo_6 { get; set; }

        [Column("Campo 7")]
        [Required]
        [StringLength(250)]
        public string Campo_7 { get; set; }

        [Column("Campo 8")]
        [Required]
        [StringLength(250)]
        public string Campo_8 { get; set; }

        [Column("Campo 9")]
        [Required]
        [StringLength(250)]
        public string Campo_9 { get; set; }

        [Column("Campo 10")]
        [Required]
        [StringLength(250)]
        public string Campo_10 { get; set; }

        [Column("Campo 11")]
        [Required]
        [StringLength(250)]
        public string Campo_11 { get; set; }

        [Column("Campo 12")]
        [Required]
        [StringLength(250)]
        public string Campo_12 { get; set; }

        [Column("Campo 13")]
        [Required]
        [StringLength(250)]
        public string Campo_13 { get; set; }

        [Column("Campo 14")]
        [Required]
        [StringLength(250)]
        public string Campo_14 { get; set; }

        [Column("Campo 15")]
        [Required]
        [StringLength(250)]
        public string Campo_15 { get; set; }

        [Column("Campo 16")]
        [Required]
        [StringLength(250)]
        public string Campo_16 { get; set; }

        [Column("Campo 17")]
        [Required]
        [StringLength(250)]
        public string Campo_17 { get; set; }

        [Column("Campo 18")]
        [Required]
        [StringLength(250)]
        public string Campo_18 { get; set; }

        [Column("Campo 19")]
        [Required]
        [StringLength(250)]
        public string Campo_19 { get; set; }

        [Column("Campo 20")]
        [Required]
        [StringLength(250)]
        public string Campo_20 { get; set; }

        [Column("Campo 21")]
        [Required]
        [StringLength(250)]
        public string Campo_21 { get; set; }

        [Column("Campo 22")]
        [Required]
        [StringLength(250)]
        public string Campo_22 { get; set; }

        [Column("Campo 23")]
        [Required]
        [StringLength(250)]
        public string Campo_23 { get; set; }

        [Column("Campo 24")]
        [Required]
        [StringLength(250)]
        public string Campo_24 { get; set; }

        [Column("Campo 25")]
        [Required]
        [StringLength(250)]
        public string Campo_25 { get; set; }

        [Column("Campo 26")]
        [Required]
        [StringLength(250)]
        public string Campo_26 { get; set; }

        [Column("Campo 27")]
        [Required]
        [StringLength(250)]
        public string Campo_27 { get; set; }

        [Column("Campo 28")]
        [Required]
        [StringLength(250)]
        public string Campo_28 { get; set; }

        [Column("Campo 29")]
        [Required]
        [StringLength(250)]
        public string Campo_29 { get; set; }

        [Column("Campo 30")]
        [Required]
        [StringLength(250)]
        public string Campo_30 { get; set; }

        [Column("Campo 31")]
        [Required]
        [StringLength(250)]
        public string Campo_31 { get; set; }

        [Column("Campo 32")]
        [Required]
        [StringLength(250)]
        public string Campo_32 { get; set; }

        [Column("Campo 33")]
        [Required]
        [StringLength(250)]
        public string Campo_33 { get; set; }

        [Column("Campo 34")]
        [Required]
        [StringLength(250)]
        public string Campo_34 { get; set; }

        [Column("Campo 35")]
        [Required]
        [StringLength(250)]
        public string Campo_35 { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string Ope { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string Reporte { get; set; }
    }
}
