namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMCOTI")]
    public partial class C001COMCOTI
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Requisicion { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Linea { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(6)]
        public string CodProv { get; set; }

        [Column(TypeName = "money")]
        public decimal Precio { get; set; }

        public double PorDesc { get; set; }

        public bool Selec { get; set; }

        public virtual C001COMRQL C001COMRQL { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }
    }
}
