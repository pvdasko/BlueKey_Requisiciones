namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCASA")]
    public partial class C001CONCASA
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        public long No_Casa { get; set; }
    }
}
