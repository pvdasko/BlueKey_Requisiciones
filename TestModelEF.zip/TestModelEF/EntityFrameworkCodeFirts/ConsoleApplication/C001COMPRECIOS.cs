namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPRECIOS")]
    public partial class C001COMPRECIOS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Codigo_Articulo { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Codigo_Prov { get; set; }

        [Column(TypeName = "money")]
        public decimal Precio_1 { get; set; }

        public DateTime Fecha_1 { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_1 { get; set; }

        public bool Vigente { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_2 { get; set; }

        public DateTime? Fecha_2 { get; set; }

        [StringLength(3)]
        public string Ope_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_3 { get; set; }

        public DateTime? Fecha_3 { get; set; }

        [StringLength(3)]
        public string Ope_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_4 { get; set; }

        public DateTime? Fecha_4 { get; set; }

        [StringLength(3)]
        public string Ope_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_5 { get; set; }

        public DateTime? Fecha_5 { get; set; }

        [StringLength(3)]
        public string Ope_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_6 { get; set; }

        public DateTime? Fecha_6 { get; set; }

        [StringLength(3)]
        public string Ope_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_7 { get; set; }

        public DateTime? Fecha_7 { get; set; }

        [StringLength(3)]
        public string Ope_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_8 { get; set; }

        public DateTime? Fecha_8 { get; set; }

        [StringLength(3)]
        public string Ope_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_9 { get; set; }

        public DateTime? Fecha_9 { get; set; }

        [StringLength(3)]
        public string Ope_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_10 { get; set; }

        public DateTime? Fecha_10 { get; set; }

        [StringLength(3)]
        public string Ope_10 { get; set; }

        public long No_Req { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }

        public virtual C001INVART C001INVART { get; set; }
    }
}
