namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMHORA")]
    public partial class C001NOMHORA
    {
        [Key]
        [StringLength(3)]
        public string Numero_Horario { get; set; }

        [Required]
        [StringLength(10)]
        public string Hra_Entrada { get; set; }

        [Required]
        [StringLength(10)]
        public string Hra_S_Comida { get; set; }

        [Required]
        [StringLength(10)]
        public string Hra_E_Comida { get; set; }

        [Required]
        [StringLength(10)]
        public string Hra_Salida { get; set; }
    }
}
