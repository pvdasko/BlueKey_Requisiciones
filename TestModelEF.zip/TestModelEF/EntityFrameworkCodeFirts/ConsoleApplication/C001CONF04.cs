namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONF04")]
    public partial class C001CONF04
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime Hora { get; set; }
    }
}
