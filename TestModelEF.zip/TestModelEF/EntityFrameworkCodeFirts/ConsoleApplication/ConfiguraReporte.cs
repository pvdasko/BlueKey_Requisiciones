namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ConfiguraReporte")]
    public partial class ConfiguraReporte
    {
        [Key]
        [StringLength(50)]
        public string Reporte { get; set; }

        [Required]
        [StringLength(50)]
        public string TipoLetra { get; set; }

        [Required]
        [StringLength(50)]
        public string Tamano { get; set; }
    }
}
