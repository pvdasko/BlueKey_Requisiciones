namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001DEPVISLLEG")]
    public partial class C001DEPVISLLEG
    {
        [Key]
        [StringLength(50)]
        public string Comprobante { get; set; }

        [Required]
        [StringLength(20)]
        public string Folio { get; set; }

        public DateTime Fecha_ori { get; set; }

        [Required]
        [StringLength(4)]
        public string Codigo { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargos { get; set; }

        [Column(TypeName = "money")]
        public decimal Abonos { get; set; }

        [Required]
        [StringLength(100)]
        public string Apellido { get; set; }

        [Required]
        [StringLength(100)]
        public string Nombre { get; set; }

        public DateTime LLEGADA { get; set; }

        public int Noches { get; set; }

        public DateTime SALIDA { get; set; }

        [Required]
        [StringLength(20)]
        public string Agencia { get; set; }

        [Required]
        [StringLength(6)]
        public string CodCxc { get; set; }

        public bool Ok { get; set; }

        public bool EnCartera { get; set; }

        [Required]
        [StringLength(20)]
        public string Cupon { get; set; }

        [Required]
        [StringLength(4)]
        public string Tipo { get; set; }

        [Column(TypeName = "money")]
        public decimal Tarifa { get; set; }

        [Column(TypeName = "money")]
        public decimal Estancia { get; set; }

        [Required]
        [StringLength(2)]
        public string Divisa { get; set; }
    }
}
