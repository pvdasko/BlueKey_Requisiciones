namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCPAGFAC")]
    public partial class C001CXCPAGFAC
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Usuario { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Cod_Cliente { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string Docto { get; set; }

        [StringLength(2)]
        public string Codigo_Cargo { get; set; }

        [StringLength(20)]
        public string Referencia { get; set; }

        [StringLength(1)]
        public string Cargo_Abono { get; set; }

        [StringLength(50)]
        public string Descripcion { get; set; }

        [StringLength(50)]
        public string Cta_Contable { get; set; }

        public DateTime? Fecha_Doc { get; set; }

        public DateTime? Fecha_Mov { get; set; }

        [StringLength(15)]
        public string Importe { get; set; }

        [StringLength(25)]
        public string Libre_1 { get; set; }

        [StringLength(6)]
        public string Movto { get; set; }

        [StringLength(15)]
        public string TipoCam { get; set; }

        [StringLength(25)]
        public string Libre_4 { get; set; }
    }
}
