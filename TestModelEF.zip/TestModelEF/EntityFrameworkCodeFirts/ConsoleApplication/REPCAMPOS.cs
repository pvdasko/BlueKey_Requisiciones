namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class REPCAMPOS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(20)]
        public string Reporte { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string Campo { get; set; }

        public double Currentx { get; set; }

        [Required]
        [StringLength(50)]
        public string Titulo { get; set; }

        [Required]
        [StringLength(50)]
        public string Mascara { get; set; }

        [Column("Texto Mascara")]
        [Required]
        [StringLength(50)]
        public string Texto_Mascara { get; set; }

        [Required]
        [StringLength(1)]
        public string Justifica { get; set; }

        [Required]
        [StringLength(50)]
        public string Font { get; set; }

        [Required]
        [StringLength(50)]
        public string Tamano { get; set; }

        [Required]
        [StringLength(50)]
        public string Rayap1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Rayap2 { get; set; }

        [Column("Campo Principal")]
        public double Campo_Principal { get; set; }

        [Required]
        [StringLength(50)]
        public string Conversion { get; set; }

        public double Totaliza { get; set; }

        [Column("Ancho DBGrid")]
        public double Ancho_DBGrid { get; set; }
    }
}
