namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCASA")]
    public partial class C001CXPCASA
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string Tipo_PolL { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(8)]
        public string Num_PolL { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        [Required]
        [StringLength(19)]
        public string Cuenta_Prov { get; set; }

        [Required]
        [StringLength(10)]
        public string Factura { get; set; }

        [StringLength(10)]
        public string Referencia { get; set; }

        public DateTime Fecha { get; set; }

        [StringLength(50)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono { get; set; }

        public bool Casar { get; set; }

        public bool NoAplica { get; set; }
    }
}
