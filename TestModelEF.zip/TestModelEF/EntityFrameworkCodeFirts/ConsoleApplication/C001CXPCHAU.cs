namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCHAU")]
    public partial class C001CXPCHAU
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string Consec { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(6)]
        public string Provedor { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(6)]
        public string Factura { get; set; }

        [Required]
        [StringLength(1)]
        public string Abono { get; set; }

        public DateTime? Fecha { get; set; }

        [StringLength(50)]
        public string Notas { get; set; }

        [StringLength(10)]
        public string Libre { get; set; }

        [StringLength(20)]
        public string Importe { get; set; }
    }
}
