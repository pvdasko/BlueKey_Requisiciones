namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCIA")]
    public partial class C001NOMCIA
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001NOMCIA()
        {
            C001RHEMP = new HashSet<C001RHEMP>();
        }

        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        [Required]
        [StringLength(50)]
        public string NombreCia { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001RHEMP> C001RHEMP { get; set; }
    }
}
