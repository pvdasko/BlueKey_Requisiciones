namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMREGISTRO")]
    public partial class C001COMREGISTRO
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Pedido { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string Origen { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(50)]
        public string Desc_Art { get; set; }

        [Key]
        [Column(Order = 6)]
        public double Cantidad { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(50)]
        public string Cod_Med { get; set; }

        [Key]
        [Column(Order = 8, TypeName = "money")]
        public decimal Precio { get; set; }
    }
}
