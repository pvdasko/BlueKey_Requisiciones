namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_FECH
    {
        [Key]
        public DateTime Fecha { get; set; }

        public bool? Cerrado { get; set; }
    }
}
