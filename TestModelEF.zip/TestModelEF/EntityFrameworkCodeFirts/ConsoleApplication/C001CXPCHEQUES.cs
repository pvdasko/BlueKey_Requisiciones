namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCHEQUES")]
    public partial class C001CXPCHEQUES
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string No_Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string No_Cheque { get; set; }

        public DateTime Fecha { get; set; }

        [StringLength(10)]
        public string Cod_Prov { get; set; }

        [StringLength(100)]
        public string Beneficiario { get; set; }

        [Required]
        [StringLength(300)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        public bool AbonoEnCuenta { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo_Cheque { get; set; }

        public bool Impreso { get; set; }

        public bool Cancelado { get; set; }

        public bool Conciliado { get; set; }

        [Required]
        [StringLength(4)]
        public string Periodo { get; set; }

        [StringLength(3)]
        public string Ope_Captura { get; set; }

        [StringLength(3)]
        public string Ope_Cancela { get; set; }

        [StringLength(50)]
        public string Motivo_Cancel { get; set; }

        public bool Afectado { get; set; }

        public bool ConciliaOK { get; set; }

        public bool SubeTesoreria { get; set; }

        public DateTime? FechaConcilia { get; set; }

        [Column(TypeName = "money")]
        public decimal ImpuestoPagado { get; set; }

        public DateTime? Fecha_Trans { get; set; }

        [StringLength(50)]
        public string CuentaProv { get; set; }

        public double Indice { get; set; }

        public bool Seleccionar { get; set; }
    }
}
