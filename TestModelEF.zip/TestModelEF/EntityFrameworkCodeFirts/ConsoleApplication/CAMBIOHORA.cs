namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CAMBIOHORA")]
    public partial class CAMBIOHORA
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string No_Emp { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string Fecha_Ini { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string Fecha_Fin { get; set; }

        [StringLength(3)]
        public string Horario_Ant { get; set; }

        [StringLength(3)]
        public string Horario_New { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(1)]
        public string Tipo_Hor { get; set; }

        public bool? Status { get; set; }
    }
}
