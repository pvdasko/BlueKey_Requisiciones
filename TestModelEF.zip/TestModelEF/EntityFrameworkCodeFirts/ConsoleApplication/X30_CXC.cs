namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class X30_CXC
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(10)]
        public string Agencia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string Consecutivo { get; set; }

        [StringLength(10)]
        public string Fecha { get; set; }

        [StringLength(10)]
        public string Hora { get; set; }

        [StringLength(10)]
        public string Codigo { get; set; }

        [StringLength(20)]
        public string Comprobante { get; set; }

        [StringLength(100)]
        public string Nombre { get; set; }

        [Column(TypeName = "money")]
        public decimal? Cargos { get; set; }

        [StringLength(10)]
        public string Operador { get; set; }

        [StringLength(1)]
        public string Estatus { get; set; }

        [StringLength(10)]
        public string Folio_Huesped { get; set; }

        [StringLength(10)]
        public string Cve_Tpo_Cuarto { get; set; }

        public int? Adultos { get; set; }

        public int? Ninos { get; set; }

        public int? Menores { get; set; }

        public int? Juniors { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tarifa_por_noche { get; set; }

        public int? Noches { get; set; }

        [StringLength(10)]
        public string Plan { get; set; }

        [StringLength(250)]
        public string Notas { get; set; }

        [StringLength(10)]
        public string Fecha_Salida { get; set; }

        public int? Cuartos { get; set; }

        [StringLength(10)]
        public string Fecha_Ref { get; set; }

        [StringLength(2)]
        public string Estatus_Ref { get; set; }

        public bool? Pasa { get; set; }
    }
}
