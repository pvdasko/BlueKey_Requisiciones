namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPSAL")]
    public partial class C001CXPSAL
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(6)]
        public string Provedor { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Factura { get; set; }

        public DateTime? Factura_Fec { get; set; }

        public DateTime? Factura_Vence { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldio_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Pago { get; set; }
    }
}
