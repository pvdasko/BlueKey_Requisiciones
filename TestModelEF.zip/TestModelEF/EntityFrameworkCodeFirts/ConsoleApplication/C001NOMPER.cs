namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPER")]
    public partial class C001NOMPER
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(1)]
        public string Tipo_Per { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(1)]
        public string TipoNomina { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string No_Per { get; set; }

        public double Dias_Conf { get; set; }

        public double Dias_Sind { get; set; }

        public double Dias_Even { get; set; }

        [Required]
        [StringLength(1)]
        public string Tabla_Ispt { get; set; }

        [Column(TypeName = "money")]
        public decimal Salario_Minimo_Region { get; set; }

        public bool Periodo_Corte { get; set; }

        public DateTime Fecha_Inicial { get; set; }

        public DateTime Fecha_Final { get; set; }

        public bool Periodo_Actualizado { get; set; }

        public DateTime? Corte_Inicial { get; set; }

        public DateTime? Corte_Final { get; set; }

        public int Dias_Inf { get; set; }

        public int Per_Inf { get; set; }

        public int DiasInf { get; set; }
    }
}
