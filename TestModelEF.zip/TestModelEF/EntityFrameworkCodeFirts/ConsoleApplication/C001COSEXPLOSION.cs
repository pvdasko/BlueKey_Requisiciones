namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSEXPLOSION")]
    public partial class C001COSEXPLOSION
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long EXPLOSION { get; set; }

        [Required]
        [StringLength(250)]
        public string NOMBRE { get; set; }
    }
}
