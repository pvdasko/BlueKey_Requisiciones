namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CuentasVarias
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre10 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre15 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre10Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre15Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaRet { get; set; }

        [StringLength(50)]
        public string CtaISRRet { get; set; }

        [StringLength(50)]
        public string CtaIvaRetEfec { get; set; }

        [StringLength(50)]
        public string CtaISRRetEfec { get; set; }

        [StringLength(50)]
        public string CtaUtilidad { get; set; }

        [StringLength(50)]
        public string CtaPerdida { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre11 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre16 { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre11Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre16Efec { get; set; }

        [StringLength(50)]
        public string CtaIvaAcre21IEPS { get; set; }
    }
}
