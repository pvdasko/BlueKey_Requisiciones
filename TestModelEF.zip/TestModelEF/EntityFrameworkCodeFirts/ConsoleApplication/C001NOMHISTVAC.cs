namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMHISTVAC")]
    public partial class C001NOMHISTVAC
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Ejercicio { get; set; }

        public double Enero { get; set; }

        public double Febrero { get; set; }

        public double Marzo { get; set; }

        public double Abril { get; set; }

        public double Mayo { get; set; }

        public double Junio { get; set; }

        public double Julio { get; set; }

        public double Agosto { get; set; }

        public double Septiembre { get; set; }

        public double Octubre { get; set; }

        public double Noviembre { get; set; }

        public double Diciembre { get; set; }

        public double Corresponden { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Tomados { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Diferencia { get; set; }

        public double Pendientes { get; set; }
    }
}
