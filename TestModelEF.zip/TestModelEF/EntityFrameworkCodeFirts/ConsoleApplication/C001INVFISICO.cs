namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVFISICO")]
    public partial class C001INVFISICO
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        public double? Inv_Fisico { get; set; }

        [Column(TypeName = "money")]
        public decimal? Costo_Promedio { get; set; }

        [Required]
        [StringLength(3)]
        public string Iniciales { get; set; }

        public DateTime Fecha_Captura { get; set; }
    }
}
