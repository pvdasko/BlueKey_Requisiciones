namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCONTRATOS")]
    public partial class C001NOMCONTRATOS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string NoEmpleado { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha_Inicial { get; set; }

        [Key]
        [Column(Order = 2)]
        public DateTime ContratoInicial { get; set; }

        [Key]
        [Column(Order = 3)]
        public DateTime ContratoFinal { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Duracion { get; set; }

        public bool StatusContrato { get; set; }

        public bool cx { get; set; }

        [Required]
        [StringLength(2)]
        public string TipoContrato { get; set; }

        [Required]
        [StringLength(50)]
        public string NombreContrato { get; set; }
    }
}
