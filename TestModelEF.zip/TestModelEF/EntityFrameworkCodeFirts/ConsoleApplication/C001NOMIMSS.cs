namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMIMSS")]
    public partial class C001NOMIMSS
    {
        [Key]
        [StringLength(4)]
        public string Rama { get; set; }

        public double PorEmp { get; set; }

        public double PorPat { get; set; }

        public double Tope { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }
    }
}
