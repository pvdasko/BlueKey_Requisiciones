namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMESC")]
    public partial class C001NOMESC
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        public short Escolaridad { get; set; }

        [Required]
        [StringLength(50)]
        public string Escuela1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Escuela2 { get; set; }

        [Required]
        [StringLength(50)]
        public string Escuela3 { get; set; }

        [Required]
        [StringLength(50)]
        public string Escuela4 { get; set; }

        [Required]
        [StringLength(50)]
        public string Escuela5 { get; set; }

        [Required]
        [StringLength(50)]
        public string Carrera1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Carrera2 { get; set; }

        [Required]
        [StringLength(50)]
        public string Carrera3 { get; set; }

        [Required]
        [StringLength(50)]
        public string Carrera4 { get; set; }

        public bool Cert1 { get; set; }

        public bool Cert2 { get; set; }

        public bool Cert3 { get; set; }

        public bool Cert4 { get; set; }

        public bool Cert5 { get; set; }

        [Required]
        [StringLength(5)]
        public string Per1 { get; set; }

        [Required]
        [StringLength(5)]
        public string Per2 { get; set; }

        [Required]
        [StringLength(5)]
        public string Per3 { get; set; }

        [Required]
        [StringLength(5)]
        public string Per4 { get; set; }

        [Required]
        [StringLength(5)]
        public string Per5 { get; set; }

        [Required]
        [StringLength(10)]
        public string Hablado { get; set; }

        [Required]
        [StringLength(10)]
        public string Leido { get; set; }

        [Required]
        [StringLength(10)]
        public string Escrito { get; set; }

        [Required]
        [StringLength(10)]
        public string Excel { get; set; }

        [Required]
        [StringLength(10)]
        public string Word { get; set; }

        [Required]
        [StringLength(10)]
        public string Internet { get; set; }

        [Required]
        [StringLength(200)]
        public string OtroSoftware { get; set; }

        public bool NoEstudia { get; set; }

        public bool SiEstudia { get; set; }

        [Required]
        [StringLength(50)]
        public string Especialidad { get; set; }

        [Required]
        [StringLength(50)]
        public string Horario { get; set; }
    }
}
