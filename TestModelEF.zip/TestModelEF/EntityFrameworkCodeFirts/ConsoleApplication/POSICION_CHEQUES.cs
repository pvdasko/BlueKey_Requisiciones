namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class POSICION_CHEQUES
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string No_Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Campo { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        [Required]
        [StringLength(100)]
        public string Font { get; set; }

        public double Tamano { get; set; }

        [Required]
        [StringLength(250)]
        public string Texto { get; set; }
    }
}
