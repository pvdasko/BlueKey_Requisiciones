namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_ALM
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AF_ALM()
        {
            AF_SUB = new HashSet<AF_SUB>();
        }

        [Key]
        [StringLength(4)]
        public string Codigo_Almacen { get; set; }

        [Required]
        [StringLength(40)]
        public string Descripcion_Espanol { get; set; }

        [StringLength(40)]
        public string Descripcion_Ingles { get; set; }

        [StringLength(19)]
        public string Cta_Contable { get; set; }

        [StringLength(50)]
        public string Libre { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_SUB> AF_SUB { get; set; }
    }
}
