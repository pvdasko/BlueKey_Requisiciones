namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class SubCod_Agrupador
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string CodigoSAT { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string SubCodigoSAT { get; set; }

        [Required]
        [StringLength(250)]
        public string DescripcionSAT2 { get; set; }
    }
}
