namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSMOVS")]
    public partial class C001COSMOVS
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long IND { get; set; }

        [Required]
        [StringLength(4)]
        public string Depto { get; set; }

        [Required]
        [StringLength(3)]
        public string Mov { get; set; }

        public long Cod_Art { get; set; }

        public double Cantidad { get; set; }

        [Column(TypeName = "money")]
        public decimal Costo { get; set; }

        [StringLength(4)]
        public string Unidad { get; set; }

        [Required]
        [StringLength(4)]
        public string Ope { get; set; }

        public DateTime Fecha { get; set; }
    }
}
