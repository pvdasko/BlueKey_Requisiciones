namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONTCM")]
    public partial class C001CONTCM
    {
        [Key]
        [StringLength(2)]
        public string Periodo { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Pres_12 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Prom_12 { get; set; }
    }
}
