namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Cod_Agrupador
    {
        [Key]
        [StringLength(2)]
        public string CodigoSAT { get; set; }

        [Required]
        [StringLength(250)]
        public string DescripcionSAT { get; set; }
    }
}
