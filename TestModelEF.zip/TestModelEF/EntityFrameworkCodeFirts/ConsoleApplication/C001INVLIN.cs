namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVLIN")]
    public partial class C001INVLIN
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Indice { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public long Cod_Art { get; set; }

        public double Can { get; set; }

        public decimal Costo { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total { get; set; }

        [StringLength(16)]
        public string Cta_Con { get; set; }

        [Column(TypeName = "money")]
        public decimal Iva { get; set; }

        [Required]
        [StringLength(100)]
        public string Concepto { get; set; }

        public virtual C001INVART C001INVART { get; set; }

        public virtual C001INVGEN C001INVGEN { get; set; }
    }
}
