namespace ConsoleApplication
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class BackModel : DbContext
    {
        public BackModel()
            : base("name=ContextBack")
        {
        }

        public virtual DbSet<C001COMCOTI> C001COMCOTI { get; set; }
        public virtual DbSet<C001COMPDG> C001COMPDG { get; set; }
        public virtual DbSet<C001COMPDL> C001COMPDL { get; set; }
        public virtual DbSet<C001COMPDL_DET> C001COMPDL_DET { get; set; }
        public virtual DbSet<C001COMPRECIOS> C001COMPRECIOS { get; set; }
        public virtual DbSet<C001COMPRI> C001COMPRI { get; set; }
        public virtual DbSet<C001COMPRQG> C001COMPRQG { get; set; }
        public virtual DbSet<C001COMPRQL> C001COMPRQL { get; set; }
        public virtual DbSet<C001COMRQG> C001COMRQG { get; set; }
        public virtual DbSet<C001COMRQL> C001COMRQL { get; set; }
        public virtual DbSet<C001COMSORT> C001COMSORT { get; set; }
        public virtual DbSet<C001COMTIP> C001COMTIP { get; set; }
        public virtual DbSet<C001CONCASA> C001CONCASA { get; set; }
        public virtual DbSet<C001CONCIERRA> C001CONCIERRA { get; set; }
        public virtual DbSet<C001CONCLA> C001CONCLA { get; set; }
        public virtual DbSet<C001CONCOG> C001CONCOG { get; set; }
        public virtual DbSet<C001CONCOGCXP> C001CONCOGCXP { get; set; }
        public virtual DbSet<C001CONCOGTEMP> C001CONCOGTEMP { get; set; }
        public virtual DbSet<C001CONCOL> C001CONCOL { get; set; }
        public virtual DbSet<C001CONCOLCXP> C001CONCOLCXP { get; set; }
        public virtual DbSet<C001CONCOLTEMP> C001CONCOLTEMP { get; set; }
        public virtual DbSet<C001CONCTA> C001CONCTA { get; set; }
        public virtual DbSet<C001CONCTOS> C001CONCTOS { get; set; }
        public virtual DbSet<C001CONEST> C001CONEST { get; set; }
        public virtual DbSet<C001CONEST14> C001CONEST14 { get; set; }
        public virtual DbSet<C001CONEST15> C001CONEST15 { get; set; }
        public virtual DbSet<C001CONEST16> C001CONEST16 { get; set; }
        public virtual DbSet<C001CONEST17> C001CONEST17 { get; set; }
        public virtual DbSet<C001CONESTA> C001CONESTA { get; set; }
        public virtual DbSet<C001CONESTA14> C001CONESTA14 { get; set; }
        public virtual DbSet<C001CONESTA15> C001CONESTA15 { get; set; }
        public virtual DbSet<C001CONESTA16> C001CONESTA16 { get; set; }
        public virtual DbSet<C001CONESTA17> C001CONESTA17 { get; set; }
        public virtual DbSet<C001CONF01> C001CONF01 { get; set; }
        public virtual DbSet<C001CONF02> C001CONF02 { get; set; }
        public virtual DbSet<C001CONF03> C001CONF03 { get; set; }
        public virtual DbSet<C001CONF04> C001CONF04 { get; set; }
        public virtual DbSet<C001CONFLUJO> C001CONFLUJO { get; set; }
        public virtual DbSet<C001CONFPER14> C001CONFPER14 { get; set; }
        public virtual DbSet<C001CONP01> C001CONP01 { get; set; }
        public virtual DbSet<C001CONP02> C001CONP02 { get; set; }
        public virtual DbSet<C001CONP03> C001CONP03 { get; set; }
        public virtual DbSet<C001CONP04> C001CONP04 { get; set; }
        public virtual DbSet<C001CONPRE14> C001CONPRE14 { get; set; }
        public virtual DbSet<C001CONPRE15> C001CONPRE15 { get; set; }
        public virtual DbSet<C001CONPRE16> C001CONPRE16 { get; set; }
        public virtual DbSet<C001CONPRE17> C001CONPRE17 { get; set; }
        public virtual DbSet<C001CONPRERES> C001CONPRERES { get; set; }
        public virtual DbSet<C001CONSAL14> C001CONSAL14 { get; set; }
        public virtual DbSet<C001CONSAL15> C001CONSAL15 { get; set; }
        public virtual DbSet<C001CONSAL16> C001CONSAL16 { get; set; }
        public virtual DbSet<C001CONSAL17> C001CONSAL17 { get; set; }
        public virtual DbSet<C001CONSEG> C001CONSEG { get; set; }
        public virtual DbSet<C001CONSELEC> C001CONSELEC { get; set; }
        public virtual DbSet<C001CONSUB> C001CONSUB { get; set; }
        public virtual DbSet<C001CONTC> C001CONTC { get; set; }
        public virtual DbSet<C001CONTCM> C001CONTCM { get; set; }
        public virtual DbSet<C001CONTIPOL> C001CONTIPOL { get; set; }
        public virtual DbSet<C001COSART> C001COSART { get; set; }
        public virtual DbSet<C001COSCLA> C001COSCLA { get; set; }
        public virtual DbSet<C001COSCONV> C001COSCONV { get; set; }
        public virtual DbSet<C001COSEXPLOSION> C001COSEXPLOSION { get; set; }
        public virtual DbSet<C001COSEXPLOSIONDET> C001COSEXPLOSIONDET { get; set; }
        public virtual DbSet<C001COSGRUP> C001COSGRUP { get; set; }
        public virtual DbSet<C001COSINV> C001COSINV { get; set; }
        public virtual DbSet<C001COSINVFIS> C001COSINVFIS { get; set; }
        public virtual DbSet<C001COSMOVS> C001COSMOVS { get; set; }
        public virtual DbSet<C001COSRCG> C001COSRCG { get; set; }
        public virtual DbSet<C001COSRCL> C001COSRCL { get; set; }
        public virtual DbSet<C001COSRECINST> C001COSRECINST { get; set; }
        public virtual DbSet<C001COSTRANS> C001COSTRANS { get; set; }
        public virtual DbSet<C001COSTRANSLIN> C001COSTRANSLIN { get; set; }
        public virtual DbSet<C001COSTRANSTEMP> C001COSTRANSTEMP { get; set; }
        public virtual DbSet<C001COSUNI> C001COSUNI { get; set; }
        public virtual DbSet<C001CXCCAR> C001CXCCAR { get; set; }
        public virtual DbSet<C001CXCCART> C001CXCCART { get; set; }
        public virtual DbSet<C001CXCCART_HISTO> C001CXCCART_HISTO { get; set; }
        public virtual DbSet<C001CXCCAT> C001CXCCAT { get; set; }
        public virtual DbSet<C001CXCCDF> C001CXCCDF { get; set; }
        public virtual DbSet<C001CXCCOB> C001CXCCOB { get; set; }
        public virtual DbSet<C001CXCCTASDEP> C001CXCCTASDEP { get; set; }
        public virtual DbSet<C001CXCDEPOS> C001CXCDEPOS { get; set; }
        public virtual DbSet<C001CXCFAI> C001CXCFAI { get; set; }
        public virtual DbSet<C001CXCFAIG> C001CXCFAIG { get; set; }
        public virtual DbSet<C001CXCFAII> C001CXCFAII { get; set; }
        public virtual DbSet<C001CXCFAIL> C001CXCFAIL { get; set; }
        public virtual DbSet<C001CXCFCG> C001CXCFCG { get; set; }
        public virtual DbSet<C001CXCFCL> C001CXCFCL { get; set; }
        public virtual DbSet<C001CXCFOLIADOR> C001CXCFOLIADOR { get; set; }
        public virtual DbSet<C001CXCPAGFAC> C001CXCPAGFAC { get; set; }
        public virtual DbSet<C001CXCPAGOS> C001CXCPAGOS { get; set; }
        public virtual DbSet<C001CXCPARAM> C001CXCPARAM { get; set; }
        public virtual DbSet<C001CXCPREVIA> C001CXCPREVIA { get; set; }
        public virtual DbSet<C001CXCSALIDAS> C001CXCSALIDAS { get; set; }
        public virtual DbSet<C001CXCTEMPO> C001CXCTEMPO { get; set; }
        public virtual DbSet<C001CXCTIP> C001CXCTIP { get; set; }
        public virtual DbSet<C001CXCVISDEP> C001CXCVISDEP { get; set; }
        public virtual DbSet<C001CXCVISLLEG> C001CXCVISLLEG { get; set; }
        public virtual DbSet<C001CXPBAN> C001CXPBAN { get; set; }
        public virtual DbSet<C001CXPCAR> C001CXPCAR { get; set; }
        public virtual DbSet<C001CXPCASA> C001CXPCASA { get; set; }
        public virtual DbSet<C001CXPCASA_ANT> C001CXPCASA_ANT { get; set; }
        public virtual DbSet<C001CXPCAT> C001CXPCAT { get; set; }
        public virtual DbSet<C001CXPCHAU> C001CXPCHAU { get; set; }
        public virtual DbSet<C001CXPCHEQUES> C001CXPCHEQUES { get; set; }
        public virtual DbSet<C001CXPCHMA> C001CXPCHMA { get; set; }
        public virtual DbSet<C001CXPCOD> C001CXPCOD { get; set; }
        public virtual DbSet<C001CXPCTAS> C001CXPCTAS { get; set; }
        public virtual DbSet<C001CXPFACMAN> C001CXPFACMAN { get; set; }
        public virtual DbSet<C001CXPFORCH> C001CXPFORCH { get; set; }
        public virtual DbSet<C001CXPHPEDO> C001CXPHPEDO { get; set; }
        public virtual DbSet<C001CXPINTBAN> C001CXPINTBAN { get; set; }
        public virtual DbSet<C001CXPPAGOS> C001CXPPAGOS { get; set; }
        public virtual DbSet<C001CXPSAL> C001CXPSAL { get; set; }
        public virtual DbSet<C001CXPTIP> C001CXPTIP { get; set; }
        public virtual DbSet<C001DEPCART> C001DEPCART { get; set; }
        public virtual DbSet<C001DEPCOG> C001DEPCOG { get; set; }
        public virtual DbSet<C001DEPCOL> C001DEPCOL { get; set; }
        public virtual DbSet<C001DEPCTASDEP> C001DEPCTASDEP { get; set; }
        public virtual DbSet<C001DEPVISLLEG> C001DEPVISLLEG { get; set; }
        public virtual DbSet<C001DEPVISTA> C001DEPVISTA { get; set; }
        public virtual DbSet<C001FOLIOSPASO> C001FOLIOSPASO { get; set; }
        public virtual DbSet<C001INVALM> C001INVALM { get; set; }
        public virtual DbSet<C001INVART> C001INVART { get; set; }
        public virtual DbSet<C001INVDEP> C001INVDEP { get; set; }
        public virtual DbSet<C001INVDEPCTAS> C001INVDEPCTAS { get; set; }
        public virtual DbSet<C001INVEST> C001INVEST { get; set; }
        public virtual DbSet<C001INVFABR> C001INVFABR { get; set; }
        public virtual DbSet<C001INVFECH> C001INVFECH { get; set; }
        public virtual DbSet<C001INVFISICO> C001INVFISICO { get; set; }
        public virtual DbSet<C001INVGEN> C001INVGEN { get; set; }
        public virtual DbSet<C001INVHISCOS> C001INVHISCOS { get; set; }
        public virtual DbSet<C001INVHISTORICO> C001INVHISTORICO { get; set; }
        public virtual DbSet<C001INVLIN> C001INVLIN { get; set; }
        public virtual DbSet<C001INVMED> C001INVMED { get; set; }
        public virtual DbSet<C001INVPER> C001INVPER { get; set; }
        public virtual DbSet<C001INVREC_TEMPO> C001INVREC_TEMPO { get; set; }
        public virtual DbSet<C001INVSUB> C001INVSUB { get; set; }
        public virtual DbSet<C001INVTIPOS> C001INVTIPOS { get; set; }
        public virtual DbSet<C001NOM_NO_ALIM> C001NOM_NO_ALIM { get; set; }
        public virtual DbSet<C001NOMAREAS> C001NOMAREAS { get; set; }
        public virtual DbSet<C001NOMBAJAS> C001NOMBAJAS { get; set; }
        public virtual DbSet<C001NOMBAJMOT> C001NOMBAJMOT { get; set; }
        public virtual DbSet<C001NOMCAM> C001NOMCAM { get; set; }
        public virtual DbSet<C001NOMCAMBIOS> C001NOMCAMBIOS { get; set; }
        public virtual DbSet<C001NOMCIA> C001NOMCIA { get; set; }
        public virtual DbSet<C001NOMCON> C001NOMCON { get; set; }
        public virtual DbSet<C001NOMCONCAUT> C001NOMCONCAUT { get; set; }
        public virtual DbSet<C001NOMCONT> C001NOMCONT { get; set; }
        public virtual DbSet<C001NOMCONTRATOS> C001NOMCONTRATOS { get; set; }
        public virtual DbSet<C001NOMDEPTOS> C001NOMDEPTOS { get; set; }
        public virtual DbSet<C001NOMDESC> C001NOMDESC { get; set; }
        public virtual DbSet<C001NOMDOCS> C001NOMDOCS { get; set; }
        public virtual DbSet<C001NOMENQ> C001NOMENQ { get; set; }
        public virtual DbSet<C001NOMESC> C001NOMESC { get; set; }
        public virtual DbSet<C001NOMHISTVAC> C001NOMHISTVAC { get; set; }
        public virtual DbSet<C001NOMHORA> C001NOMHORA { get; set; }
        public virtual DbSet<C001NOMIMSS> C001NOMIMSS { get; set; }
        public virtual DbSet<C001NOMINC> C001NOMINC { get; set; }
        public virtual DbSet<C001NOMINC_RELOJ> C001NOMINC_RELOJ { get; set; }
        public virtual DbSet<C001NOMINF> C001NOMINF { get; set; }
        public virtual DbSet<C001NOMINTEGRADOS> C001NOMINTEGRADOS { get; set; }
        public virtual DbSet<C001NOMISPT> C001NOMISPT { get; set; }
        public virtual DbSet<C001NOMMAE> C001NOMMAE { get; set; }
        public virtual DbSet<C001NOMPARAM> C001NOMPARAM { get; set; }
        public virtual DbSet<C001NOMPARM> C001NOMPARM { get; set; }
        public virtual DbSet<C001NOMPENSIONES> C001NOMPENSIONES { get; set; }
        public virtual DbSet<C001NOMPER> C001NOMPER { get; set; }
        public virtual DbSet<C001NOMPERVAC> C001NOMPERVAC { get; set; }
        public virtual DbSet<C001NOMPOSIC> C001NOMPOSIC { get; set; }
        public virtual DbSet<C001NOMPREST> C001NOMPREST { get; set; }
        public virtual DbSet<C001NOMPTUDATOS> C001NOMPTUDATOS { get; set; }
        public virtual DbSet<C001NOMSDIHISTO> C001NOMSDIHISTO { get; set; }
        public virtual DbSet<C001NOMSUAMOV> C001NOMSUAMOV { get; set; }
        public virtual DbSet<C001NOMTABGEN> C001NOMTABGEN { get; set; }
        public virtual DbSet<C001NOMTABI> C001NOMTABI { get; set; }
        public virtual DbSet<C001NOMTABLIN> C001NOMTABLIN { get; set; }
        public virtual DbSet<C001NOMTABVAC> C001NOMTABVAC { get; set; }
        public virtual DbSet<C001NOMTIPCONT> C001NOMTIPCONT { get; set; }
        public virtual DbSet<C001NOMTIPEMP> C001NOMTIPEMP { get; set; }
        public virtual DbSet<C001NOMTIPFAL> C001NOMTIPFAL { get; set; }
        public virtual DbSet<C001NOMTIPNOM> C001NOMTIPNOM { get; set; }
        public virtual DbSet<C001NOMTIPPER> C001NOMTIPPER { get; set; }
        public virtual DbSet<C001NOMTMP> C001NOMTMP { get; set; }
        public virtual DbSet<C001NOMVAR> C001NOMVAR { get; set; }
        public virtual DbSet<C001PRECART> C001PRECART { get; set; }
        public virtual DbSet<C001PRECTASDEP> C001PRECTASDEP { get; set; }
        public virtual DbSet<C001PREVISLLEG> C001PREVISLLEG { get; set; }
        public virtual DbSet<C001PREVISTA> C001PREVISTA { get; set; }
        public virtual DbSet<C001RHCHECA> C001RHCHECA { get; set; }
        public virtual DbSet<C001RHCOMP> C001RHCOMP { get; set; }
        public virtual DbSet<C001RHDIASF> C001RHDIASF { get; set; }
        public virtual DbSet<C001RHEMP> C001RHEMP { get; set; }
        public virtual DbSet<C001RHEMPHISTO> C001RHEMPHISTO { get; set; }
        public virtual DbSet<AF_ALM> AF_ALM { get; set; }
        public virtual DbSet<AF_ART> AF_ART { get; set; }
        public virtual DbSet<AF_EST> AF_EST { get; set; }
        public virtual DbSet<AF_GEN> AF_GEN { get; set; }
        public virtual DbSet<AF_LIN> AF_LIN { get; set; }
        public virtual DbSet<AF_MED> AF_MED { get; set; }
        public virtual DbSet<AF_SUB> AF_SUB { get; set; }
        public virtual DbSet<AF_TIPOS> AF_TIPOS { get; set; }
        public virtual DbSet<ARPMENUS> ARPMENUS { get; set; }
        public virtual DbSet<Bitacora> Bitacora { get; set; }
        public virtual DbSet<CAMBIOHORA> CAMBIOHORA { get; set; }
        public virtual DbSet<CAPPERM> CAPPERM { get; set; }
        public virtual DbSet<Categorias> Categorias { get; set; }
        public virtual DbSet<Categorias_Fijas> Categorias_Fijas { get; set; }
        public virtual DbSet<CategoriasMovtos> CategoriasMovtos { get; set; }
        public virtual DbSet<CATPERMISOS> CATPERMISOS { get; set; }
        public virtual DbSet<CHECK_BOOK> CHECK_BOOK { get; set; }
        public virtual DbSet<Cod_Agrupador> Cod_Agrupador { get; set; }
        public virtual DbSet<COMPARATIVOTEMP> COMPARATIVOTEMP { get; set; }
        public virtual DbSet<CON_FACGEN> CON_FACGEN { get; set; }
        public virtual DbSet<CON_FACLIN> CON_FACLIN { get; set; }
        public virtual DbSet<CON_SERV> CON_SERV { get; set; }
        public virtual DbSet<CONCEPTOREPS> CONCEPTOREPS { get; set; }
        public virtual DbSet<CONCILIA_FECHAS> CONCILIA_FECHAS { get; set; }
        public virtual DbSet<CONCILIACION_ULTIMA> CONCILIACION_ULTIMA { get; set; }
        public virtual DbSet<ConfiguraReporte> ConfiguraReporte { get; set; }
        public virtual DbSet<CONMAESTRO> CONMAESTRO { get; set; }
        public virtual DbSet<CONTAB_DIVISAS> CONTAB_DIVISAS { get; set; }
        public virtual DbSet<CONTAB_TIPO_CAMBIO> CONTAB_TIPO_CAMBIO { get; set; }
        public virtual DbSet<ConversionCtas> ConversionCtas { get; set; }
        public virtual DbSet<CuentasVarias> CuentasVarias { get; set; }
        public virtual DbSet<CXCCasa> CXCCasa { get; set; }
        public virtual DbSet<CXCCasaCartera> CXCCasaCartera { get; set; }
        public virtual DbSet<CXCCONSE> CXCCONSE { get; set; }
        public virtual DbSet<dtproperties> dtproperties { get; set; }
        public virtual DbSet<GraficasGeneral> GraficasGeneral { get; set; }
        public virtual DbSet<GraficasLineas> GraficasLineas { get; set; }
        public virtual DbSet<Inc_Control> Inc_Control { get; set; }
        public virtual DbSet<Inc_Ramas> Inc_Ramas { get; set; }
        public virtual DbSet<Inc_Retardos> Inc_Retardos { get; set; }
        public virtual DbSet<Inc_Secuelas> Inc_Secuelas { get; set; }
        public virtual DbSet<Inc_Tipos> Inc_Tipos { get; set; }
        public virtual DbSet<LLARPLINEAS> LLARPLINEAS { get; set; }
        public virtual DbSet<LLARPMENUS> LLARPMENUS { get; set; }
        public virtual DbSet<NOM_JEFE_DEPTO> NOM_JEFE_DEPTO { get; set; }
        public virtual DbSet<NomExpBitacora> NomExpBitacora { get; set; }
        public virtual DbSet<NomExpediente> NomExpediente { get; set; }
        public virtual DbSet<PARAMETROS> PARAMETROS { get; set; }
        public virtual DbSet<PARAMETROS_BACK> PARAMETROS_BACK { get; set; }
        public virtual DbSet<PERFILES> PERFILES { get; set; }
        public virtual DbSet<POSICION_CHEQUES> POSICION_CHEQUES { get; set; }
        public virtual DbSet<POSICION_FACTURAS> POSICION_FACTURAS { get; set; }
        public virtual DbSet<POSICION_RECIBOS> POSICION_RECIBOS { get; set; }
        public virtual DbSet<POSICIONES> POSICIONES { get; set; }
        public virtual DbSet<QueryTemporal> QueryTemporal { get; set; }
        public virtual DbSet<RelacionCodigoCliente> RelacionCodigoCliente { get; set; }
        public virtual DbSet<RELOJHORARIOS> RELOJHORARIOS { get; set; }
        public virtual DbSet<REPCAMPOS> REPCAMPOS { get; set; }
        public virtual DbSet<REPGENERALES> REPGENERALES { get; set; }
        public virtual DbSet<REPORTE> REPORTE { get; set; }
        public virtual DbSet<Reporte_Diot> Reporte_Diot { get; set; }
        public virtual DbSet<REPORTECXC> REPORTECXC { get; set; }
        public virtual DbSet<REPTITULOS> REPTITULOS { get; set; }
        public virtual DbSet<SORTCOTI> SORTCOTI { get; set; }
        public virtual DbSet<SubCod_Agrupador> SubCod_Agrupador { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<TEMPAUX> TEMPAUX { get; set; }
        public virtual DbSet<Tempo_Autorizaciones> Tempo_Autorizaciones { get; set; }
        public virtual DbSet<TEMPO_EXPLOCION_RECETAS> TEMPO_EXPLOCION_RECETAS { get; set; }
        public virtual DbSet<TEMPPOLIZAS> TEMPPOLIZAS { get; set; }
        public virtual DbSet<TERMINAL> TERMINAL { get; set; }
        public virtual DbSet<TESORERIA_CONCILIA> TESORERIA_CONCILIA { get; set; }
        public virtual DbSet<TESORERIA_FECHAS> TESORERIA_FECHAS { get; set; }
        public virtual DbSet<TESORERIA_LINEAS> TESORERIA_LINEAS { get; set; }
        public virtual DbSet<TESORERIA_TABLA> TESORERIA_TABLA { get; set; }
        public virtual DbSet<USUARIOS> USUARIOS { get; set; }
        public virtual DbSet<X30_CXC> X30_CXC { get; set; }
        public virtual DbSet<C001COMREGISTRO> C001COMREGISTRO { get; set; }
        public virtual DbSet<C001COSACT> C001COSACT { get; set; }
        public virtual DbSet<C001CXCEDO> C001CXCEDO { get; set; }
        public virtual DbSet<C001CXCEDODEP> C001CXCEDODEP { get; set; }
        public virtual DbSet<C001CXPCTA> C001CXPCTA { get; set; }
        public virtual DbSet<C001CXPCURR> C001CXPCURR { get; set; }
        public virtual DbSet<C001DEPESTADO> C001DEPESTADO { get; set; }
        public virtual DbSet<C001INVDEPASO> C001INVDEPASO { get; set; }
        public virtual DbSet<C001NOMSELEC> C001NOMSELEC { get; set; }
        public virtual DbSet<C001NOMVARSEL> C001NOMVARSEL { get; set; }
        public virtual DbSet<C001PREESTADO> C001PREESTADO { get; set; }
        public virtual DbSet<ACTUALIZASEVILLA> ACTUALIZASEVILLA { get; set; }
        public virtual DbSet<AF_FECH> AF_FECH { get; set; }
        public virtual DbSet<InterfaseCxcFront> InterfaseCxcFront { get; set; }
        public virtual DbSet<NUEVA> NUEVA { get; set; }
        public virtual DbSet<RelacionCodigoProv> RelacionCodigoProv { get; set; }
        public virtual DbSet<SaldoConciliaciones> SaldoConciliaciones { get; set; }
        public virtual DbSet<TEMPORAL_EARLY_BIRD> TEMPORAL_EARLY_BIRD { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<C001COMCOTI>()
                .Property(e => e.CodProv)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMCOTI>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Genera)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Autoriza)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Autoriza2)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Imprime)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Condiciones)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_JefeAlmacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_JefeCompras)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Contralor)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Gerente)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Tiempo_Entrega)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Director)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.Descuento)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDL_DET>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Codigo_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_5)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_6)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_7)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_8)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_9)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Precio_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRECIOS>()
                .Property(e => e.Ope_10)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Tip_Prio)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .HasMany(e => e.C001COMRQG)
                .WithRequired(e => e.C001COMPRI)
                .HasForeignKey(e => e.Cod_Prio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Tip_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Cod_Prio)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Notas_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Notas_Auto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Ope_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQG>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQL>()
                .Property(e => e.Desc_Art)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQL>()
                .Property(e => e.Cod_Med)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRQL>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Tip_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Cod_Prio)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Notas_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Notas_Auto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Ope_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .HasMany(e => e.C001COMRQL)
                .WithRequired(e => e.C001COMRQG)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Desc_Art)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Cod_Med)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .HasMany(e => e.C001COMCOTI)
                .WithRequired(e => e.C001COMRQL)
                .HasForeignKey(e => new { e.No_Requisicion, e.No_Linea })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMSORT>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMSORT>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .Property(e => e.DescTip_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .Property(e => e.DescTip_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .HasMany(e => e.C001COMRQG)
                .WithRequired(e => e.C001COMTIP)
                .HasForeignKey(e => e.Tip_Req)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONCASA>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCIERRA>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCLA>()
                .Property(e => e.Tipo_Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCLA>()
                .Property(e => e.Clasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCLA>()
                .Property(e => e.Descripcion_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCLA>()
                .Property(e => e.Descripcion_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCLA>()
                .HasMany(e => e.C001CONSUB)
                .WithRequired(e => e.C001CONCLA)
                .HasForeignKey(e => new { e.Tipo_Cuenta, e.Clasificacion })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Tipo_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Num_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Concepto_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Tot_Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Tot_Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .Property(e => e.NumeroExporta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOG>()
                .HasMany(e => e.C001CONCOL)
                .WithRequired(e => e.C001CONCOG)
                .HasForeignKey(e => new { e.Cia, e.Periodo, e.Tipo_PolL, e.Num_PolL })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Tipo_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Num_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Concepto_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Tot_Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Tot_Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGCXP>()
                .Property(e => e.NumeroExporta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Tipo_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Num_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Concepto_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Tot_Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Tot_Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOGTEMP>()
                .Property(e => e.NumeroExporta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Concepto_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cia_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cia_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cod_Cxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cod_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Flujo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cargo_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Abono_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOL>()
                .Property(e => e.ConceptoBanco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Concepto_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cia_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cia_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cod_Cxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cod_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Flujo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cargo_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Abono_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLCXP>()
                .Property(e => e.ConceptoBanco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Concepto_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cia_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cia_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cod_Cxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cod_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Flujo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cargo_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Abono_Dolares)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCOLTEMP>()
                .Property(e => e.ConceptoBanco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Tipo_Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Clasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Subclasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Descripcion_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Complementaria)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.TipoAD)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Codigo_Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.AgrupadorSAT)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.SubAgrupadorSAT)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .HasMany(e => e.C001CONCOL)
                .WithRequired(e => e.C001CONCTA)
                .HasForeignKey(e => new { e.Cuenta_1, e.Cuenta_2, e.Cuenta_3, e.Cuenta_4 })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONPRE14)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONPRE15)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONPRE16)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONPRE17)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONSAL14)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONSAL15)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONSAL16)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasOptional(e => e.C001CONSAL17)
                .WithRequired(e => e.C001CONCTA);

            modelBuilder.Entity<C001CONCTA>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001CONCTA)
                .HasForeignKey(e => new { e.Cuenta_1, e.Cuenta_2, e.Cuenta_3, e.Cuenta_4 })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONCTOS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST14>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST14>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST15>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST15>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST16>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST16>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST17>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONEST17>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA14>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA14>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA15>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA15>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA16>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA16>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA17>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONESTA17>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Cod)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Calculo_Porcentaje)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Operacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .Property(e => e.Base)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONEST)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONEST14)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONEST15)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONEST16)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONEST17)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONESTA)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONESTA14)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONESTA15)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONESTA16)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasOptional(e => e.C001CONESTA17)
                .WithRequired(e => e.C001CONF01);

            modelBuilder.Entity<C001CONF01>()
                .HasMany(e => e.C001CONF02)
                .WithRequired(e => e.C001CONF01)
                .HasForeignKey(e => new { e.Rubro, e.Secuencia })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONF02>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF02>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF02>()
                .Property(e => e.Cuenta_Inicial)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF02>()
                .Property(e => e.Cuenta_Final)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Pres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.APres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.AMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.ASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PSal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PAMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.PASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF03>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONF04>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFLUJO>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFLUJO>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFLUJO>()
                .Property(e => e.Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFLUJO>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.Pres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.APres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.AMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.ASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PSal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PAMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONFPER14>()
                .Property(e => e.PASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Cod)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Calculo_Porcentaje)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .Property(e => e.Operacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP01>()
                .HasMany(e => e.C001CONP02)
                .WithRequired(e => e.C001CONP01)
                .HasForeignKey(e => new { e.Rubro, e.Secuencia })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONP02>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP02>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP02>()
                .Property(e => e.Cuenta_Inicial)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP02>()
                .Property(e => e.Cuenta_Final)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP02>()
                .Property(e => e.Comando)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.Pres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.APres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.AMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.ASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PSal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAPres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PAMes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP03>()
                .Property(e => e.PASal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONP04>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE14>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE15>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE16>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRE17>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Oper)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_5)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_6)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_7)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_8)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_9)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_10)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_11)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONPRERES>()
                .Property(e => e.Notas_12)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Car_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Abo_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL14>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Car_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Abo_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL15>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Car_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Abo_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL16>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_0)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Car_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Abo_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSAL17>()
                .Property(e => e.Sal_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONSEG>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSELEC>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSELEC>()
                .Property(e => e.BaseDatos)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSUB>()
                .Property(e => e.Tipo_Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSUB>()
                .Property(e => e.Clasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSUB>()
                .Property(e => e.Subclasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSUB>()
                .Property(e => e.Descripcion_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONSUB>()
                .Property(e => e.Descripcion_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTC>()
                .Property(e => e.TipoCambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Mes_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Pres_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_3)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_4)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_5)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_6)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_7)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_8)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_9)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_10)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_11)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTCM>()
                .Property(e => e.Prom_12)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CONTIPOL>()
                .Property(e => e.Tipo_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .Property(e => e.TipoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .Property(e => e.Tipo_SAT)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .HasMany(e => e.C001CONCOG)
                .WithRequired(e => e.C001CONTIPOL)
                .HasForeignKey(e => e.Tipo_PolG)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .HasMany(e => e.C001CONCOGCXP)
                .WithRequired(e => e.C001CONTIPOL)
                .HasForeignKey(e => e.Tipo_PolG)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .HasMany(e => e.C001CONCOGTEMP)
                .WithRequired(e => e.C001CONTIPOL)
                .HasForeignKey(e => e.Tipo_PolG)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CONTIPOL>()
                .HasMany(e => e.C001CXPBAN)
                .WithRequired(e => e.C001CONTIPOL)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COSART>()
                .Property(e => e.Costo_Prom)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSART>()
                .Property(e => e.Unidad_Medida)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSART>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSCLA>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSCLA>()
                .HasOptional(e => e.C001COSCLA1)
                .WithRequired(e => e.C001COSCLA2);

            modelBuilder.Entity<C001COSCONV>()
                .Property(e => e.Uni_Pricipal)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSCONV>()
                .Property(e => e.Uni_Conv)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSGRUP>()
                .Property(e => e.Desc_Grupo)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINV>()
                .Property(e => e.Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINV>()
                .Property(e => e.Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINV>()
                .Property(e => e.Cos_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSINV>()
                .Property(e => e.Cos_Mes)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSINV>()
                .Property(e => e.Cos_Per)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSINVFIS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINVFIS>()
                .Property(e => e.Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINVFIS>()
                .Property(e => e.Codigo_Articulo)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINVFIS>()
                .Property(e => e.Unidad_Medida)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSINVFIS>()
                .Property(e => e.Iniciales)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSMOVS>()
                .Property(e => e.Costo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Codigo_Receta)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Nom_RecEsp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Nom_RecIng)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Precio_Venta)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Cla)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCG>()
                .Property(e => e.Grup)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCL>()
                .Property(e => e.Cod_Receta)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCL>()
                .Property(e => e.Cod_Subrec)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSRCL>()
                .Property(e => e.Uni_Med)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANS>()
                .Property(e => e.TIPO_MOV)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANS>()
                .Property(e => e.DEPTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANS>()
                .Property(e => e.NOTAS)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANS>()
                .Property(e => e.OPERADOR)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSLIN>()
                .Property(e => e.TIPO_MOV)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSLIN>()
                .Property(e => e.CANTIDAD)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001COSTRANSLIN>()
                .Property(e => e.UNIDAD)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSLIN>()
                .Property(e => e.COSTO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSTRANSLIN>()
                .Property(e => e.TOTAL)
                .HasPrecision(38, 10);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.USUARIO)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.DEP_ORI)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.DEP_DES)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.NOMBRE)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.UNIDAD)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSTRANSTEMP>()
                .Property(e => e.COSTO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COSUNI>()
                .Property(e => e.Codigo_Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSUNI>()
                .Property(e => e.Nom_UniEsp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSUNI>()
                .Property(e => e.Nom_UniIng)
                .IsUnicode(false);

            modelBuilder.Entity<C001COSUNI>()
                .HasMany(e => e.C001COSCONV)
                .WithRequired(e => e.C001COSUNI)
                .HasForeignKey(e => e.Uni_Pricipal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COSUNI>()
                .HasMany(e => e.C001COSCONV1)
                .WithRequired(e => e.C001COSUNI1)
                .HasForeignKey(e => e.Uni_Conv)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COSUNI>()
                .HasMany(e => e.C001COSRCG)
                .WithRequired(e => e.C001COSUNI)
                .HasForeignKey(e => e.Unidad)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXCCAR>()
                .Property(e => e.Numero_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAR>()
                .Property(e => e.Tipo_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAR>()
                .Property(e => e.Nombre_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAR>()
                .Property(e => e.Nombre_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAR>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Importe_Real)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.PerCont)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.No_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.No_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART>()
                .Property(e => e.No_Fact)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Importe_Real)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.PerCont)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.No_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.No_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCART_HISTO>()
                .Property(e => e.No_Fact)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Nombre_Comercial)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Tipo_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Cuenta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Poblacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.CP)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.No_Fax)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.E_Mail)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Pag_Web)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Contacto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Descuento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Procede)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_Mes_Actual)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_Vencer)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_30)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_60)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_90)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Saldo_120)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Pais)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Color)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Limite)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Calle)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.NoExterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.NoInterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Localidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Municipio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.Estado)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCAT>()
                .Property(e => e.CodigoPostal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCDF>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCDF>()
                .Property(e => e.Tipo_Cargo)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCDF>()
                .Property(e => e.Nombre_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCDF>()
                .Property(e => e.Nombre_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCDF>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Monto)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Baja)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Cabo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Ixtapa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Manzanillo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Tapatia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCOB>()
                .Property(e => e.Total)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.CargoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCCTASDEP>()
                .Property(e => e.AbonoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Importe_Real)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.PerCont)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.No_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCDEPOS>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Codigo_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Cta_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Fecha_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Cantidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Cantidad_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAI>()
                .Property(e => e.Dolar)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Sub_Factura)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Total_Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAIG>()
                .Property(e => e.Total_Ish)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Codigo_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.No_Linea)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.No_Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Codigo_Serv)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAII>()
                .Property(e => e.Libre_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Tipo_Cuarto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.PPlan)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFAIL>()
                .Property(e => e.Total)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.No_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Sub_Factura)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Total_Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Total_Ish)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCG>()
                .Property(e => e.Impuestos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.No_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Tipo_Cuarto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.PPlan)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCFCL>()
                .Property(e => e.Total)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCFOLIADOR>()
                .Property(e => e.Id)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGFAC>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPAGOS>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPARAM>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPARAM>()
                .Property(e => e.AlimAdulto)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPARAM>()
                .Property(e => e.AlimMenor)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPARAM>()
                .Property(e => e.PropMesero)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPARAM>()
                .Property(e => e.PropCamarista)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.TARIFA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.L_CREDITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.DEPOSITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.SALDO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.TARIFA_RACK)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.TARIFA_CENTRAL)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.TARIFA_TOUR_OPERADOR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCPREVIA>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.TARIFA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.L_CREDITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.DEPOSITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.SALDO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.TARIFA_RACK)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.TARIFA_CENTRAL)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.TARIFA_TOUR_OPERADOR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCSALIDAS>()
                .Property(e => e.Pesos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCTEMPO>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCTIP>()
                .Property(e => e.Codigo_Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCTIP>()
                .Property(e => e.Nombre_Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCTIP>()
                .Property(e => e.Nombre_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCTIP>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISDEP>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCVISLLEG>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Codigo_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Nombre_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Numero_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Tipo_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPBAN>()
                .Property(e => e.Cta_Entregado)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Cod_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Num_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Codigo_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Num_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Libre_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAR>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Cuenta_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCASA>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Cuenta_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCASA_ANT>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Codigo_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Poblacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CP)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.No_Fax)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.E_Mail)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Pag_Web)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Contacto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Cta_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Forma_Pago)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tiempo_Entrega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Descuento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_Mes_Actual)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_Vencer)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_30)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_60)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_90)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_120)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CURP)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Comercial)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Pais)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CodigoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.TipoTercero)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.TipoOperacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.IDFiscal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nacionalidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nombre_Plaza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_CW)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_Plaza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_Sucursal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nombre_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001COMCOTI)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.CodProv)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001COMPRECIOS)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Codigo_Prov)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasOptional(e => e.C001CXPINTBAN)
                .WithRequired(e => e.C001CXPCAT);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Prov_1)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001INVART1)
                .WithRequired(e => e.C001CXPCAT1)
                .HasForeignKey(e => e.Prov_2)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001INVGEN)
                .WithOptional(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Cod_Prov);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.AF_ART)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Prov_1)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.AF_ART1)
                .WithRequired(e => e.C001CXPCAT1)
                .HasForeignKey(e => e.Prov_2)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.AF_GEN)
                .WithOptional(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Cod_Prov);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.CON_FACGEN)
                .WithOptional(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Cod_Prov);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Consec)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHAU>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.No_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.No_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Cod_Prov)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Beneficiario)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Tipo_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Ope_Captura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Ope_Cancela)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.Motivo_Cancel)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.ImpuestoPagado)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCHEQUES>()
                .Property(e => e.CuentaProv)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Codigo_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.No_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Codigo_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Fecha)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Beneficiario)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Anticipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Cta_Gastos)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPCHMA>()
                .Property(e => e.Impreso)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCOD>()
                .Property(e => e.Numero_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCOD>()
                .Property(e => e.Tipo_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCOD>()
                .Property(e => e.Nombre_Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTAS>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTAS>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTAS>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTAS>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Cuenta_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPFACMAN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Seccion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Campo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.X)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Y)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Tamano)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Texto_Mascara)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Longitud)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Justifica)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPFORCH>()
                .Property(e => e.Valor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Cod_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Num_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Codigo_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Num_Cheque)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Libre_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPHPEDO>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.CtaBanco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.Clabe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.IdEstado)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.IdCiudad)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.IdBanco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.Plaza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.Sucursal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPINTBAN>()
                .Property(e => e.IdProv)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Cuenta_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Cargo_Pesos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPPAGOS>()
                .Property(e => e.Abono_Pesos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPSAL>()
                .Property(e => e.Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPSAL>()
                .Property(e => e.Factura)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPSAL>()
                .Property(e => e.Saldo_1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPSAL>()
                .Property(e => e.Saldio_2)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPSAL>()
                .Property(e => e.Pago)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Codigo_Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Nombre_Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Cta_Anticipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Cta_Contable_Dol)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPTIP>()
                .Property(e => e.Cta_Anticipo_Dol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Importe_Real)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.PerCont)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.No_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCART>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Tipo_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Num_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Concepto_PolG)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOG>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Tipo_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Num_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Concepto_PolL)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCOL>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.CargoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPCTASDEP>()
                .Property(e => e.AbonoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISLLEG>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001DEPVISTA>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.FOLIO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.APELLIDO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.NOMBRE)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_TIPO_CUARTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.TARIFA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.DIRECCION)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CIUDAD)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_EMPRESA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.PROC_RVA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.GRUPO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.AGENCIA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.PLAN)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.F_PAGO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.NO_TARJETA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.L_CREDITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_SRC)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_SRC_VENTAS)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_CRO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_VIP)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_GARANTIA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.FECHA_LIMITE)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_CTE_FRECUENTE)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.FOLIO_MAESTRA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.SW)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.EMAIL)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CONTACTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_CONTRATO_TC)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CVE_CUARTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.NOTAS)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.DEPOSITO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.SALDO)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.ESTATUS)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.TARIFA_RACK)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.LLEGADA_ORIGINAL)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.SALIDA_ORIGINAL)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CXC)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.BANDA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CUPON)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.GALA_100)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.TARIFA_CENTRAL)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.TARIFA_TOUR_OPERADOR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.ARCHIVO_FIRMA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.TOTAL_ESTANCIA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.MEDIO)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.COMISION)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.ENVIADA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.AFECTA_ALLOTMENT_GALA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CALCULO_TARIFA)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_61)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_62)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_63)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_64)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_65)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_66)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_67)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_68)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_69)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_70)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_71)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_72)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_73)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_74)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_75)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_76)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_77)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_78)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_79)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.CAMPO_80)
                .IsUnicode(false);

            modelBuilder.Entity<C001FOLIOSPASO>()
                .Property(e => e.COMPROBANTE)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Codigo_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .HasMany(e => e.C001INVSUB)
                .WithRequired(e => e.C001INVALM)
                .HasForeignKey(e => e.Cod_Almacen)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Cod_Barras)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Alm)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Sub_Alm)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Prov_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Prov_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Maximo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Minimo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Reorden)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Uni_Ent)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Uni_Sal)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Conver)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVART>()
                .HasMany(e => e.C001COMPRECIOS)
                .WithRequired(e => e.C001INVART)
                .HasForeignKey(e => e.Codigo_Articulo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVART>()
                .HasOptional(e => e.C001INVEST)
                .WithRequired(e => e.C001INVART);

            modelBuilder.Entity<C001INVART>()
                .HasMany(e => e.C001INVLIN)
                .WithRequired(e => e.C001INVART)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cta_Mayor)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cta_Nivel)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.BD)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001INVDEP)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Alma)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Sub)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_UE)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_Prom)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_Ant)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UE)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_US)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UA)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UDP)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UDD)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVFISICO>()
                .Property(e => e.Costo_Promedio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVFISICO>()
                .Property(e => e.Iniciales)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.No_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Ope_Aplica)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.ISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.IVAR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.RET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.PISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.PRET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Flete)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Porc_Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Monto_XML)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Anticipo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .HasMany(e => e.C001INVLIN)
                .WithRequired(e => e.C001INVGEN)
                .HasForeignKey(e => e.Indice)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVHISCOS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVHISCOS>()
                .Property(e => e.CostoPromedio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVHISTORICO>()
                .Property(e => e.Cos_Prom)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVHISTORICO>()
                .Property(e => e.Cos_UE)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVHISTORICO>()
                .Property(e => e.Cos_Ant)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Costo)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Cta_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Codigo_Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001COMRQL)
                .WithRequired(e => e.C001INVMED)
                .HasForeignKey(e => e.Cod_Med)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001INVMED)
                .HasForeignKey(e => e.Uni_Ent)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001INVART1)
                .WithRequired(e => e.C001INVMED1)
                .HasForeignKey(e => e.Uni_Sal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVPER>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVREC_TEMPO>()
                .Property(e => e.Costo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cod_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cod_Subalmacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Cargo1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Cargo2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001INVSUB)
                .HasForeignKey(e => new { e.Alm, e.Sub_Alm })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVSUB>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001INVSUB)
                .HasForeignKey(e => new { e.Cod_Alma, e.Cod_Sub })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .Property(e => e.Cod_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .Property(e => e.Desc_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .HasMany(e => e.C001INVGEN)
                .WithRequired(e => e.C001INVTIPOS)
                .HasForeignKey(e => e.Tipo_Mov)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .HasMany(e => e.CON_FACGEN)
                .WithRequired(e => e.C001INVTIPOS)
                .HasForeignKey(e => e.Tipo_Mov)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMAREAS>()
                .Property(e => e.Nom_Area)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMAREAS>()
                .HasMany(e => e.C001NOMDEPTOS)
                .WithRequired(e => e.C001NOMAREAS)
                .HasForeignKey(e => e.AREA)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMBAJAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMBAJAS>()
                .HasMany(e => e.C001NOMBAJMOT)
                .WithRequired(e => e.C001NOMBAJAS)
                .HasForeignKey(e => e.NoMotivo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMBAJMOT>()
                .Property(e => e.Motivo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCAM>()
                .Property(e => e.Tipo_Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCAM>()
                .Property(e => e.SDI_Anterior)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCAM>()
                .Property(e => e.SDI_Nuevo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCAM>()
                .Property(e => e.SD_Anterior)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCAM>()
                .Property(e => e.SD_Nuevo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCAMBIOS>()
                .Property(e => e.DatoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCAMBIOS>()
                .Property(e => e.DatoNuevo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCAMBIOS>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCAMBIOS>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCIA>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCIA>()
                .Property(e => e.NombreCia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCIA>()
                .HasMany(e => e.C001RHEMP)
                .WithRequired(e => e.C001NOMCIA)
                .HasForeignKey(e => e.Empresa)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.NombreConcepto)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.Formula)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.CtaMayor)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.SubCta)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.CtaProv)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .Property(e => e.CFDI)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCON>()
                .HasMany(e => e.C001NOMPREST)
                .WithRequired(e => e.C001NOMCON)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteSindicato)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteConfianza)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteEjecutivo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteSindicato1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteConfianza1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONCAUT>()
                .Property(e => e.ImporteEjecutivo1)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMCONT>()
                .Property(e => e.TipoEmpleado)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCONT>()
                .Property(e => e.TipoContrato)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMCONT>()
                .Property(e => e.Contrato)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDEPTOS>()
                .Property(e => e.NOM_DEPTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDEPTOS>()
                .Property(e => e.CTA_DEPTO)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDEPTOS>()
                .HasMany(e => e.C001RHEMP)
                .WithRequired(e => e.C001NOMDEPTOS)
                .HasForeignKey(e => e.Depto)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMDESC>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDOCS>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDOCS>()
                .Property(e => e.Documento)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMDOCS>()
                .Property(e => e.Temporal)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.TipoNomina)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.Gravable)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMENQ>()
                .Property(e => e.Exento)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escuela1)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escuela2)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escuela3)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escuela4)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escuela5)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Carrera1)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Carrera2)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Carrera3)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Carrera4)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Per1)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Per2)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Per3)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Per4)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Per5)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Hablado)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Leido)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Escrito)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Excel)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Word)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Internet)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.OtroSoftware)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Especialidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMESC>()
                .Property(e => e.Horario)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHISTVAC>()
                .Property(e => e.Ejercicio)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHORA>()
                .Property(e => e.Numero_Horario)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHORA>()
                .Property(e => e.Hra_Entrada)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHORA>()
                .Property(e => e.Hra_S_Comida)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHORA>()
                .Property(e => e.Hra_E_Comida)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMHORA>()
                .Property(e => e.Hra_Salida)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMIMSS>()
                .Property(e => e.Rama)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMIMSS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC_RELOJ>()
                .Property(e => e.Fecha)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC_RELOJ>()
                .Property(e => e.Incidencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMINC_RELOJ>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINF>()
                .Property(e => e.Porcentaje)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINF>()
                .Property(e => e.Prestamo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINF>()
                .Property(e => e.Retencion)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINF>()
                .Property(e => e.Saldo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Sueldo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Aguinaldo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Prima)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Despensa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Comedor)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.Variables)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMINTEGRADOS>()
                .Property(e => e.SueldoIntegrado)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMISPT>()
                .Property(e => e.Conse)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMISPT>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.RazonSocial)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Entidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Municipio)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.CP)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.ImssPatronal)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Infonavit)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.ClaveMunicipio)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.ClaveEntidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.OficinaHacienda)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Representante)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.RFCRep)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.SMDF)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.Factor)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.PorcSind)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.SeguroVida)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.FondoSeguro)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.PorcAlimentos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.CuentaSueldos)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.TopeComedor)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.CuentaCargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMMAE>()
                .Property(e => e.AlimImporte)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPARAM>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPARM>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPARM>()
                .Property(e => e.Tope)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPENSIONES>()
                .Property(e => e.Porcentaje)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPER>()
                .Property(e => e.Tipo_Per)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPER>()
                .Property(e => e.TipoNomina)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPER>()
                .Property(e => e.No_Per)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPER>()
                .Property(e => e.Tabla_Ispt)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPER>()
                .Property(e => e.Salario_Minimo_Region)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPOSIC>()
                .Property(e => e.Nom_Pos)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPOSIC>()
                .Property(e => e.Sdo_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPOSIC>()
                .Property(e => e.Fac_Sdo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPOSIC>()
                .Property(e => e.Nivel)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPOSIC>()
                .HasMany(e => e.C001RHEMP)
                .WithRequired(e => e.C001NOMPOSIC)
                .HasForeignKey(e => e.Puesto)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.PeriodoInicio)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.Prestamo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.Monto)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.Descontado)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPREST>()
                .Property(e => e.Saldo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.Repartir)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.Garantia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.TopeSueldo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMPTUDATOS>()
                .Property(e => e.MayorSindicalizado)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSDIHISTO>()
                .Property(e => e.SD)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSDIHISTO>()
                .Property(e => e.SDI)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSDIHISTO>()
                .Property(e => e.Variable)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSDIHISTO>()
                .Property(e => e.Promedio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSDIHISTO>()
                .Property(e => e.NSDI)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001NOMSUAMOV>()
                .Property(e => e.NoEmp)
                .HasPrecision(18, 0);

            modelBuilder.Entity<C001NOMSUAMOV>()
                .Property(e => e.CodMov)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMSUAMOV>()
                .Property(e => e.FolioIncapacidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMSUAMOV>()
                .Property(e => e.DiasIncidencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTABGEN>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTABI>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTABI>()
                .Property(e => e.Tabla)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPCONT>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPCONT>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPEMP>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPEMP>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPFAL>()
                .Property(e => e.Nom_Falta)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPNOM>()
                .Property(e => e.TipoNomina)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPNOM>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPPER>()
                .Property(e => e.Tipo_Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMTIPPER>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMVAR>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMVAR>()
                .Property(e => e.Abreviatura)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Importe_Real)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Tipo_Cam)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Ope_Cap)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.PerCont)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.No_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECART>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoTpoDeposito)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoTpoDepositoDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.CargoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoTpoLlega)
                .IsUnicode(false);

            modelBuilder.Entity<C001PRECTASDEP>()
                .Property(e => e.AbonoTpoLlegaDol)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISLLEG>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Abonos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Apellido)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.CodCxc)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Cupon)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Tarifa)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Estancia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001PREVISTA>()
                .Property(e => e.Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCHECA>()
                .Property(e => e.E_S)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCOMP>()
                .Property(e => e.Regimen)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCOMP>()
                .Property(e => e.RiesgoPuesto)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCOMP>()
                .Property(e => e.Calle)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCOMP>()
                .Property(e => e.TipoContrato)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHCOMP>()
                .Property(e => e.TipoJornada)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Paterno)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Materno)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.CURP)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.IMSS)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Calle)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Municipio)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Ciudad)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Estado)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.CodigoPostal)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Empresa)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.SD)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.SDA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.SDI)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.SDIA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.CuentaBancaria)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Nacionalidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Padre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Madre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_5)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_6)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_7)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_8)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_9)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Hijo_10)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.LugarNacimiento)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Esposa)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.TipoCuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Escolaridad)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.TIPOCONTRATO)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.CuentaVales)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMP>()
                .Property(e => e.Vales)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMP>()
                .HasMany(e => e.C001NOMBAJMOT)
                .WithRequired(e => e.C001RHEMP)
                .HasForeignKey(e => e.Empleado)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001RHEMP>()
                .HasMany(e => e.C001NOMPREST)
                .WithRequired(e => e.C001RHEMP)
                .HasForeignKey(e => e.Empleado)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Paterno)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Materno)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.CURP)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.IMSS)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Calle)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Municipio)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Ciudad)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Estado)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.CodigoPostal)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Empresa)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.SD)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.SDA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.SDI)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.SDIA)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.CuentaBancaria)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Nacionalidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Padre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Madre)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_5)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_6)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_7)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_8)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_9)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Hijo_10)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.LugarNacimiento)
                .IsUnicode(false);

            modelBuilder.Entity<C001RHEMPHISTO>()
                .Property(e => e.Esposa)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .Property(e => e.Codigo_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ALM>()
                .HasMany(e => e.AF_SUB)
                .WithRequired(e => e.AF_ALM)
                .HasForeignKey(e => e.Cod_Almacen)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Cod_Barras)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Alm)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Sub_Alm)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Prov_1)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Prov_2)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Maximo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Minimo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Reorden)
                .HasPrecision(19, 0);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Uni_Ent)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Uni_Sal)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .Property(e => e.Conver)
                .IsUnicode(false);

            modelBuilder.Entity<AF_ART>()
                .HasOptional(e => e.AF_EST)
                .WithRequired(e => e.AF_ART);

            modelBuilder.Entity<AF_ART>()
                .HasMany(e => e.AF_LIN)
                .WithRequired(e => e.AF_ART)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Cos_UE)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Cos_Prom)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Cos_Ant)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Req_UE)
                .IsUnicode(false);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Req_US)
                .IsUnicode(false);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Req_UA)
                .IsUnicode(false);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Req_UDP)
                .IsUnicode(false);

            modelBuilder.Entity<AF_EST>()
                .Property(e => e.Req_UDD)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.No_Req)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .Property(e => e.Ope_Aplica)
                .IsUnicode(false);

            modelBuilder.Entity<AF_GEN>()
                .HasMany(e => e.AF_LIN)
                .WithRequired(e => e.AF_GEN)
                .HasForeignKey(e => e.Indice)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_LIN>()
                .Property(e => e.Costo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AF_LIN>()
                .Property(e => e.Cta_Con)
                .IsUnicode(false);

            modelBuilder.Entity<AF_MED>()
                .Property(e => e.Codigo_Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<AF_MED>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<AF_MED>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<AF_MED>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<AF_MED>()
                .HasMany(e => e.AF_ART)
                .WithRequired(e => e.AF_MED)
                .HasForeignKey(e => e.Uni_Ent)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_MED>()
                .HasMany(e => e.AF_ART1)
                .WithRequired(e => e.AF_MED1)
                .HasForeignKey(e => e.Uni_Sal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Cod_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Cod_Subalmacen)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Cuenta_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Cuenta_Cargo1)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Cuenta_Cargo2)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<AF_SUB>()
                .HasMany(e => e.AF_ART)
                .WithRequired(e => e.AF_SUB)
                .HasForeignKey(e => new { e.Alm, e.Sub_Alm })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AF_TIPOS>()
                .Property(e => e.Cod_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<AF_TIPOS>()
                .Property(e => e.Desc_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.No_de_Menu)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Nombre_programa)
                .IsUnicode(false);

            modelBuilder.Entity<ARPMENUS>()
                .Property(e => e.Maestro)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Tipo_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Num_Pol)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Bitacora>()
                .Property(e => e.Equipo)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.No_Emp)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.Fecha_Ini)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.Fecha_Fin)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.Horario_Ant)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.Horario_New)
                .IsUnicode(false);

            modelBuilder.Entity<CAMBIOHORA>()
                .Property(e => e.Tipo_Hor)
                .IsUnicode(false);

            modelBuilder.Entity<CAPPERM>()
                .Property(e => e.No_Emp)
                .IsUnicode(false);

            modelBuilder.Entity<CAPPERM>()
                .Property(e => e.Fecha_Ini)
                .IsUnicode(false);

            modelBuilder.Entity<CAPPERM>()
                .Property(e => e.Fecha_Fin)
                .IsUnicode(false);

            modelBuilder.Entity<CAPPERM>()
                .Property(e => e.No_Perm)
                .IsUnicode(false);

            modelBuilder.Entity<CAPPERM>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<Categorias>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<Categorias>()
                .Property(e => e.Categoria)
                .IsUnicode(false);

            modelBuilder.Entity<Categorias>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<Categorias>()
                .HasMany(e => e.CategoriasMovtos)
                .WithRequired(e => e.Categorias)
                .HasForeignKey(e => new { e.Nivel_1, e.Nivel_2, e.Nivel_3 })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Categorias_Fijas>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Categorias_Fijas>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<CategoriasMovtos>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<CategoriasMovtos>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CategoriasMovtos>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Rubro)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Secuencia)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<CHECK_BOOK>()
                .Property(e => e.Operacion)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.No_Req)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Ope_Aplica)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.ISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.IVAR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.RET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.PISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.PRET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Porc_Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .Property(e => e.Monto_XML)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACGEN>()
                .HasMany(e => e.CON_FACLIN)
                .WithRequired(e => e.CON_FACGEN)
                .HasForeignKey(e => e.Indice)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CON_FACLIN>()
                .Property(e => e.Total)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACLIN>()
                .Property(e => e.Cta_Con)
                .IsUnicode(false);

            modelBuilder.Entity<CON_FACLIN>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CON_FACLIN>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Cod_Barras)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Alm)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Sub_Alm)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Prov_1)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Prov_2)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Maximo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Minimo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Reorden)
                .HasPrecision(19, 0);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Uni_Ent)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Uni_Sal)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Conver)
                .IsUnicode(false);

            modelBuilder.Entity<CON_SERV>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<CONCEPTOREPS>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<CONCILIA_FECHAS>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<CONCILIA_FECHAS>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CONCILIACION_ULTIMA>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<CONCILIACION_ULTIMA>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ConfiguraReporte>()
                .Property(e => e.Reporte)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguraReporte>()
                .Property(e => e.TipoLetra)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguraReporte>()
                .Property(e => e.Tamano)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Codigo_Cia)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Entidad_Federativa)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Municipio_Delegacion)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Codigo_Postal)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Periodo)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Resultado)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Fecha_Proceso)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Nombre_Base)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Directorio_Trabajo)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cadena_Conn)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Proveedores)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Clientes)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Cuenta_Iva)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Consecutivo_Factura)
                .IsUnicode(false);

            modelBuilder.Entity<CONMAESTRO>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CONTAB_DIVISAS>()
                .Property(e => e.Codigo_Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<CONTAB_DIVISAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<CONTAB_DIVISAS>()
                .HasMany(e => e.CONTAB_TIPO_CAMBIO)
                .WithRequired(e => e.CONTAB_DIVISAS)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CONTAB_TIPO_CAMBIO>()
                .Property(e => e.Codigo_Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<CONTAB_TIPO_CAMBIO>()
                .Property(e => e.Tipo_Cambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ConversionCtas>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<ConversionCtas>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<ConversionCtas>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<ConversionCtas>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<ConversionCtas>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre10)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre15)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre10Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre15Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaRet)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaISRRet)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaRetEfec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaISRRetEfec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaUtilidad)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaPerdida)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre11)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre16)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre11Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre16Efec)
                .IsUnicode(false);

            modelBuilder.Entity<CuentasVarias>()
                .Property(e => e.CtaIvaAcre21IEPS)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasa>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCasaCartera>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CXCCONSE>()
                .Property(e => e.Serie)
                .IsUnicode(false);

            modelBuilder.Entity<CXCCONSE>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<dtproperties>()
                .Property(e => e.property)
                .IsUnicode(false);

            modelBuilder.Entity<dtproperties>()
                .Property(e => e.value)
                .IsUnicode(false);

            modelBuilder.Entity<GraficasGeneral>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<GraficasLineas>()
                .Property(e => e.CuentaInicial)
                .IsUnicode(false);

            modelBuilder.Entity<GraficasLineas>()
                .Property(e => e.CuentaFinal)
                .IsUnicode(false);

            modelBuilder.Entity<Inc_Control>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Inc_Ramas>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Inc_Retardos>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Inc_Secuelas>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Inc_Tipos>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPLINEAS>()
                .Property(e => e.Opcion)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPLINEAS>()
                .Property(e => e.Nombre_de_Opcion)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPLINEAS>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPLINEAS>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.No_de_Menu)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.Servidor)
                .IsUnicode(false);

            modelBuilder.Entity<LLARPMENUS>()
                .Property(e => e.Visible)
                .IsUnicode(false);

            modelBuilder.Entity<NOM_JEFE_DEPTO>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<NomExpBitacora>()
                .Property(e => e.DatoNuevo)
                .IsUnicode(false);

            modelBuilder.Entity<NomExpBitacora>()
                .Property(e => e.DatoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<NomExpBitacora>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<NomExpediente>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS>()
                .Property(e => e.Parametro)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS>()
                .Property(e => e.Valor)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS_BACK>()
                .Property(e => e.Parametro)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS_BACK>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<PARAMETROS_BACK>()
                .Property(e => e.Valor)
                .IsUnicode(false);

            modelBuilder.Entity<PERFILES>()
                .Property(e => e.Cod_Perfil)
                .IsUnicode(false);

            modelBuilder.Entity<PERFILES>()
                .Property(e => e.Descripcion_Perfil)
                .IsUnicode(false);

            modelBuilder.Entity<PERFILES>()
                .Property(e => e.Menus_Acceso)
                .IsUnicode(false);

            modelBuilder.Entity<PERFILES>()
                .Property(e => e.Programa_Default)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_CHEQUES>()
                .Property(e => e.No_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_CHEQUES>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_CHEQUES>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_CHEQUES>()
                .Property(e => e.Texto)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_FACTURAS>()
                .Property(e => e.No_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_FACTURAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_FACTURAS>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_FACTURAS>()
                .Property(e => e.Texto)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_RECIBOS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_RECIBOS>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<POSICION_RECIBOS>()
                .Property(e => e.Texto)
                .IsUnicode(false);

            modelBuilder.Entity<POSICIONES>()
                .Property(e => e.Posicion)
                .IsUnicode(false);

            modelBuilder.Entity<POSICIONES>()
                .Property(e => e.menus)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Query)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_01)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_02)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_03)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_04)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_05)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_06)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_07)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_08)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_09)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_10)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_11)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_12)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_13)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_14)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_15)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_16)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_17)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_18)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_19)
                .IsUnicode(false);

            modelBuilder.Entity<QueryTemporal>()
                .Property(e => e.Tempo_20)
                .IsUnicode(false);

            modelBuilder.Entity<RelacionCodigoCliente>()
                .Property(e => e.CodigoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<RELOJHORARIOS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<RELOJHORARIOS>()
                .Property(e => e.TipoHorario)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Reporte)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Campo)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Titulo)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Mascara)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Texto_Mascara)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Justifica)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Tamano)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Rayap1)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Rayap2)
                .IsUnicode(false);

            modelBuilder.Entity<REPCAMPOS>()
                .Property(e => e.Conversion)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Reporte)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Linea)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Query_Inicial)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Titulo)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Query_Totales)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Con_Subtotal)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Query_Final)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.DB_Folio)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Imp_Llegadas)
                .IsUnicode(false);

            modelBuilder.Entity<REPGENERALES>()
                .Property(e => e.Imp_Salidas)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Linea)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_1)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_2)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_3)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_4)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_5)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_6)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_7)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_8)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_9)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_10)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_11)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_12)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_13)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_14)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_15)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_16)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_17)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_18)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_19)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_20)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_21)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_22)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_23)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_24)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_25)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_26)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_27)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_28)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_29)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_30)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_31)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_32)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_33)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_34)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_35)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_36)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_37)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_38)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_39)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_40)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_41)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_42)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_43)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_44)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_45)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_46)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_47)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_48)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_49)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_50)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_51)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_52)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_53)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_54)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_55)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_56)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_57)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_58)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_59)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_60)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_61)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_62)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_63)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_64)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_65)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Campo_66)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTE>()
                .Property(e => e.Reporte1)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Tipo_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Numero_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Reporte_Diot>()
                .Property(e => e.Impuesto)
                .HasPrecision(19, 4);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Linea)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_1)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_2)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_3)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_4)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_5)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_6)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_7)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_8)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_9)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_10)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_11)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_12)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_13)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_14)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_15)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_16)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_17)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_18)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_19)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_20)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_21)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_22)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_23)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_24)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_25)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_26)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_27)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_28)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_29)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_30)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_31)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_32)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_33)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_34)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Campo_35)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<REPORTECXC>()
                .Property(e => e.Reporte)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Titulo)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Texto)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Font)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Size)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<REPTITULOS>()
                .Property(e => e.Reporte)
                .IsUnicode(false);

            modelBuilder.Entity<SORTCOTI>()
                .Property(e => e.Ope)
                .IsUnicode(false);

            modelBuilder.Entity<SORTCOTI>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<SORTCOTI>()
                .Property(e => e.Nombre_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Desc_cta)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Sal_Ant)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.sal_act)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Sal_Car)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPAUX>()
                .Property(e => e.Sal_Abo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.No_Req)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.Departamento)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.Operador)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.OpeAut)
                .IsUnicode(false);

            modelBuilder.Entity<Tempo_Autorizaciones>()
                .Property(e => e.Total)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Consecutivo)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Receta)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.NomReceta)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Articulo)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.SubReceta)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.NomUnidad)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Costo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPO_EXPLOCION_RECETAS>()
                .Property(e => e.Folio)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Depto)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPPOLIZAS>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Terminal1)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Clave_Cia)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Ubicacion)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Programa)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Operador)
                .IsUnicode(false);

            modelBuilder.Entity<TERMINAL>()
                .Property(e => e.Ruta)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Tipo_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_CONCILIA>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_FECHAS>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_LINEAS>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_LINEAS>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_LINEAS>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_LINEAS>()
                .Property(e => e.Importe)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Tipo_Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Cargo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Abono)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Categoria)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.ConceptoGral)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Poliza)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Proveedor)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.Usuario)
                .IsUnicode(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.TipoCambio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.CargoIETU)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.AbonoIETU)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.ImporteIva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.PorcIva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.PorcISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.ImporteISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .Property(e => e.ImporteRet)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .HasMany(e => e.CategoriasMovtos)
                .WithRequired(e => e.TESORERIA_TABLA)
                .HasForeignKey(e => new { e.Banco, e.Indice })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TESORERIA_TABLA>()
                .HasMany(e => e.TESORERIA_LINEAS)
                .WithRequired(e => e.TESORERIA_TABLA)
                .HasForeignKey(e => new { e.Banco, e.Indice })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Perfil)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Puesto)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Cia_Default)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Reservado4)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Idioma)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Mes)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Ano)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Mes)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Ano)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Reservado5)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Color_Sel)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Agencia)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Consecutivo)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Fecha)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Hora)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Codigo)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Comprobante)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Cargos)
                .HasPrecision(19, 4);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Operador)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Estatus)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Folio_Huesped)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Cve_Tpo_Cuarto)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Tarifa_por_noche)
                .HasPrecision(19, 4);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Plan)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Fecha_Salida)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Fecha_Ref)
                .IsUnicode(false);

            modelBuilder.Entity<X30_CXC>()
                .Property(e => e.Estatus_Ref)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMREGISTRO>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Cta_contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.No_Fact)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDO>()
                .Property(e => e.No_Billing)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Cta_contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXCEDODEP>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTA>()
                .Property(e => e.Cia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTA>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTA>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTA>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCTA>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCURR>()
                .Property(e => e.Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCURR>()
                .Property(e => e.FontSize)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCURR>()
                .Property(e => e.FontName)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Cta_contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001DEPESTADO>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.Cta_Mayor)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.Cta_Nivel)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPASO>()
                .Property(e => e.BD)
                .IsUnicode(false);

            modelBuilder.Entity<C001NOMVARSEL>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Terminal)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Cod_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Docto)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Codigo_Cargo)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Cargo_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Cta_contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Importe)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Movto)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.TipoCam)
                .IsUnicode(false);

            modelBuilder.Entity<C001PREESTADO>()
                .Property(e => e.Libre_4)
                .IsUnicode(false);

            modelBuilder.Entity<ACTUALIZASEVILLA>()
                .Property(e => e.CUENTA)
                .IsFixedLength();

            modelBuilder.Entity<InterfaseCxcFront>()
                .Property(e => e.Cia)
                .IsFixedLength();

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Codigo_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Nombre_Comercial)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Tipo_Cliente)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Cuenta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Poblacion)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.CP)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.No_Fax)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.E_Mail)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Pag_Web)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Contacto)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Descuento)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Procede)
                .IsUnicode(false);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_Mes_Actual)
                .HasPrecision(19, 4);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_Vencer)
                .HasPrecision(19, 4);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_30)
                .HasPrecision(19, 4);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_60)
                .HasPrecision(19, 4);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_90)
                .HasPrecision(19, 4);

            modelBuilder.Entity<NUEVA>()
                .Property(e => e.Saldo_120)
                .HasPrecision(19, 4);

            modelBuilder.Entity<RelacionCodigoProv>()
                .Property(e => e.CodigoProveedor)
                .IsUnicode(false);

            modelBuilder.Entity<RelacionCodigoProv>()
                .Property(e => e.CodigoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<SaldoConciliaciones>()
                .Property(e => e.Saldo_Inicial)
                .HasPrecision(19, 4);

            modelBuilder.Entity<SaldoConciliaciones>()
                .Property(e => e.Inversiones)
                .HasPrecision(19, 4);

            modelBuilder.Entity<TEMPORAL_EARLY_BIRD>()
                .Property(e => e.EQUIPO)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPORAL_EARLY_BIRD>()
                .Property(e => e.CUENTA_1)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPORAL_EARLY_BIRD>()
                .Property(e => e.CUENTA_2)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPORAL_EARLY_BIRD>()
                .Property(e => e.CUENTA_3)
                .IsUnicode(false);

            modelBuilder.Entity<TEMPORAL_EARLY_BIRD>()
                .Property(e => e.CUENTA_4)
                .IsUnicode(false);
        }
    }
}
