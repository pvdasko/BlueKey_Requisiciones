namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSRECINST")]
    public partial class C001COSRECINST
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(10)]
        public string Receta { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Instruccion { get; set; }

        [Required]
        public string Descripcion { get; set; }
    }
}
