namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONCILIACION_ULTIMA
    {
        [Key]
        [StringLength(4)]
        public string Banco { get; set; }

        public DateTime Fecha { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }
    }
}
