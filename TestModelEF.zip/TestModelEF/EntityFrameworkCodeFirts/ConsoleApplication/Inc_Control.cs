namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Inc_Control
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Control { get; set; }

        [Required]
        [StringLength(250)]
        public string Descripcion { get; set; }

        public int Rama { get; set; }
    }
}
