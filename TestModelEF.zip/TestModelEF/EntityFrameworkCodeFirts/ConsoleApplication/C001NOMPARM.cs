namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMPARM")]
    public partial class C001NOMPARM
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Registro { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        public int Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal Tope { get; set; }
    }
}
