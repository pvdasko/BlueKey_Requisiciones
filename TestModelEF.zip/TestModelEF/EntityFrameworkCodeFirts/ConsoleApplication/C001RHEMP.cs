namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001RHEMP")]
    public partial class C001RHEMP
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001RHEMP()
        {
            C001NOMBAJMOT = new HashSet<C001NOMBAJMOT>();
            C001NOMPREST = new HashSet<C001NOMPREST>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Required]
        [StringLength(50)]
        public string Paterno { get; set; }

        [Required]
        [StringLength(50)]
        public string Materno { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombre { get; set; }

        [Required]
        [StringLength(15)]
        public string RFC { get; set; }

        [Required]
        [StringLength(50)]
        public string CURP { get; set; }

        [Required]
        [StringLength(11)]
        public string IMSS { get; set; }

        [Required]
        [StringLength(100)]
        public string Calle { get; set; }

        [Required]
        [StringLength(50)]
        public string Colonia { get; set; }

        [Required]
        [StringLength(50)]
        public string Municipio { get; set; }

        [Required]
        [StringLength(30)]
        public string Ciudad { get; set; }

        [Required]
        [StringLength(30)]
        public string Estado { get; set; }

        [Required]
        [StringLength(8)]
        public string CodigoPostal { get; set; }

        [Required]
        [StringLength(30)]
        public string Telefono { get; set; }

        public DateTime Alta { get; set; }

        public DateTime? Baja { get; set; }

        public DateTime? UltimoContrato { get; set; }

        public DateTime? CambioSueldo { get; set; }

        [Required]
        [StringLength(3)]
        public string Empresa { get; set; }

        public int Depto { get; set; }

        public short TablaIntegra { get; set; }

        public int Puesto { get; set; }

        [Column(TypeName = "money")]
        public decimal SD { get; set; }

        [Column(TypeName = "money")]
        public decimal SDA { get; set; }

        [Column(TypeName = "money")]
        public decimal SDI { get; set; }

        [Column(TypeName = "money")]
        public decimal SDIA { get; set; }

        [Required]
        [StringLength(20)]
        public string CuentaBancaria { get; set; }

        [Required]
        [StringLength(50)]
        public string Nacionalidad { get; set; }

        [Required]
        [StringLength(100)]
        public string Padre { get; set; }

        [Required]
        [StringLength(100)]
        public string Madre { get; set; }

        public bool ChecaTarjeta { get; set; }

        public bool Masculino { get; set; }

        public bool Femenino { get; set; }

        public bool Planta { get; set; }

        public bool Eventual { get; set; }

        public bool Obra { get; set; }

        public bool Casado { get; set; }

        public bool Soltero { get; set; }

        public bool Divorciado { get; set; }

        public bool Viudo { get; set; }

        public bool UnionLibre { get; set; }

        public bool Sindicato { get; set; }

        public bool Confianza { get; set; }

        public bool Ejecutivo { get; set; }

        public bool Quincenal { get; set; }

        public bool Semanal { get; set; }

        public bool Viajar { get; set; }

        public bool Residencia { get; set; }

        public bool Compartir { get; set; }

        [Required]
        [StringLength(50)]
        public string Email { get; set; }

        public bool RegNomina { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_1 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_2 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_3 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_4 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_5 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_6 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_7 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_8 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_9 { get; set; }

        [Required]
        [StringLength(100)]
        public string Hijo_10 { get; set; }

        public DateTime? Nac_Hijo_1 { get; set; }

        public DateTime? Nac_Hijo_2 { get; set; }

        public DateTime? Nac_Hijo_3 { get; set; }

        public DateTime? Nac_Hijo_4 { get; set; }

        public DateTime? Nac_Hijo_5 { get; set; }

        public DateTime? Nac_Hijo_6 { get; set; }

        public DateTime? Nac_Hijo_7 { get; set; }

        public DateTime? Nac_Hijo_8 { get; set; }

        public DateTime? Nac_Hijo_9 { get; set; }

        public DateTime? Nac_Hijo_10 { get; set; }

        [Required]
        [StringLength(100)]
        public string LugarNacimiento { get; set; }

        [Required]
        [StringLength(100)]
        public string Esposa { get; set; }

        public int CodigoHorario { get; set; }

        public bool Certificado { get; set; }

        [Required]
        [StringLength(2)]
        public string TipoCuenta { get; set; }

        [Required]
        [StringLength(50)]
        public string Escolaridad { get; set; }

        public DateTime? Vencimiento { get; set; }

        [StringLength(100)]
        public string TIPOCONTRATO { get; set; }

        public int DiasContrato { get; set; }

        public bool EnvioBanco { get; set; }

        public bool EnvioImss { get; set; }

        public DateTime? Antiguedad { get; set; }

        public DateTime? CambioIntegrado { get; set; }

        [Required]
        [StringLength(50)]
        public string CuentaVales { get; set; }

        public bool Comida { get; set; }

        [Column(TypeName = "money")]
        public decimal Vales { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001NOMBAJMOT> C001NOMBAJMOT { get; set; }

        public virtual C001NOMCIA C001NOMCIA { get; set; }

        public virtual C001NOMDEPTOS C001NOMDEPTOS { get; set; }

        public virtual C001NOMPOSIC C001NOMPOSIC { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001NOMPREST> C001NOMPREST { get; set; }
    }
}
