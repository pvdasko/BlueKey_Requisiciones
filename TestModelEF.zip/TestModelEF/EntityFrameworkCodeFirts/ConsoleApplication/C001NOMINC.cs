namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMINC")]
    public partial class C001NOMINC
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string Folio { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Ramo { get; set; }

        public int TipoRiesgo { get; set; }

        public int Secuela { get; set; }

        public int Control { get; set; }

        [Key]
        [Column(Order = 4)]
        public DateTime FechaInicio { get; set; }

        public DateTime? FechaFin { get; set; }

        public int Dias { get; set; }

        public double Porcentaje { get; set; }

        public int? Id_Retardo { get; set; }

        [StringLength(1)]
        public string Tipo { get; set; }

        [StringLength(240)]
        public string Notas { get; set; }

        public bool Aut { get; set; }

        [StringLength(3)]
        public string Ope_Cap { get; set; }

        [StringLength(3)]
        public string Ope_Aut { get; set; }

        public bool Enviado { get; set; }
    }
}
