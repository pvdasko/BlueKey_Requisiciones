namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class SaldoConciliaciones
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1, TypeName = "money")]
        public decimal Saldo_Inicial { get; set; }

        [Key]
        [Column(Order = 2, TypeName = "money")]
        public decimal Inversiones { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(4)]
        public string Periodo { get; set; }
    }
}
