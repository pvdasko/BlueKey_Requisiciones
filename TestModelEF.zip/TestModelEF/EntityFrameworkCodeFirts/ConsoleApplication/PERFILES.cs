namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class PERFILES
    {
        [Key]
        [StringLength(4)]
        public string Cod_Perfil { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion_Perfil { get; set; }

        public bool? Reservado1 { get; set; }

        public bool? Reservado2 { get; set; }

        public bool? Reservado3 { get; set; }

        public bool? Reservado4 { get; set; }

        public bool? Reservado5 { get; set; }

        public bool? Reservado6 { get; set; }

        public bool? Reservado7 { get; set; }

        public bool? Reservado8 { get; set; }

        public bool? Reservado9 { get; set; }

        [StringLength(50)]
        public string Menus_Acceso { get; set; }

        [StringLength(50)]
        public string Programa_Default { get; set; }
    }
}
