namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVHISCOS")]
    public partial class C001INVHISCOS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Articulo { get; set; }

        [Column(TypeName = "money")]
        public decimal CostoPromedio { get; set; }

        public double Existencia { get; set; }
    }
}
