namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSTRANS")]
    public partial class C001COSTRANS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long MOVIMIENTO { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string TIPO_MOV { get; set; }

        public DateTime FECHA_HORA { get; set; }

        [Required]
        [StringLength(4)]
        public string DEPTO { get; set; }

        [Required]
        [StringLength(100)]
        public string NOTAS { get; set; }

        [Required]
        [StringLength(3)]
        public string OPERADOR { get; set; }

        public DateTime FECHA_HORA_REAL { get; set; }

        public DateTime FechaReg { get; set; }

        [Required]
        [StringLength(50)]
        public string Documento { get; set; }

        [Key]
        [Column(Order = 2)]
        public long Ind { get; set; }
    }
}
