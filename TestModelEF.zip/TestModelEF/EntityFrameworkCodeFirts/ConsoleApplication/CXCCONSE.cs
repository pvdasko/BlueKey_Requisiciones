namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CXCCONSE")]
    public partial class CXCCONSE
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Serie { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string Cia { get; set; }

        public long ConFac { get; set; }
    }
}
