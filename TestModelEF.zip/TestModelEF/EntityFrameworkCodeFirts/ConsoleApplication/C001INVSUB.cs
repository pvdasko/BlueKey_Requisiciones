namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVSUB")]
    public partial class C001INVSUB
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVSUB()
        {
            C001INVART = new HashSet<C001INVART>();
            C001INVDEPCTAS = new HashSet<C001INVDEPCTAS>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cod_Almacen { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cod_Subalmacen { get; set; }

        [StringLength(40)]
        public string Descripcion_Espanol { get; set; }

        [StringLength(40)]
        public string Descripcion_Ingles { get; set; }

        [StringLength(16)]
        public string Cuenta_Abono { get; set; }

        [StringLength(16)]
        public string Cuenta_Cargo1 { get; set; }

        [StringLength(16)]
        public string Cuenta_Cargo2 { get; set; }

        [StringLength(50)]
        public string Libre { get; set; }

        public virtual C001INVALM C001INVALM { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVART> C001INVART { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVDEPCTAS> C001INVDEPCTAS { get; set; }
    }
}
