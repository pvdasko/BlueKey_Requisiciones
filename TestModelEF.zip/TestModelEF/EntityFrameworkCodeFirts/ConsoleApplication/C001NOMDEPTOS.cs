namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMDEPTOS")]
    public partial class C001NOMDEPTOS
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001NOMDEPTOS()
        {
            C001RHEMP = new HashSet<C001RHEMP>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int NUM_DEPTO { get; set; }

        [StringLength(80)]
        public string NOM_DEPTO { get; set; }

        [StringLength(20)]
        public string CTA_DEPTO { get; set; }

        public int AREA { get; set; }

        public bool? PRIM_VAC { get; set; }

        public bool? CUOT_SIND { get; set; }

        public bool? FONDO_AHO { get; set; }

        public bool? VAL_DES { get; set; }

        public double PROPINA { get; set; }

        public virtual C001NOMAREAS C001NOMAREAS { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001RHEMP> C001RHEMP { get; set; }
    }
}
