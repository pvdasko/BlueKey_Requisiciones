namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONFLUJO")]
    public partial class C001CONFLUJO
    {
        [Key]
        [StringLength(2)]
        public string Rubro { get; set; }

        [Required]
        [StringLength(100)]
        public string Concepto { get; set; }

        [Required]
        [StringLength(100)]
        public string Ingles { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo { get; set; }
    }
}
