namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001DEPCOL")]
    public partial class C001DEPCOL
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Cia { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Tipo_PolL { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(8)]
        public string Num_PolL { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }

        public DateTime Fecha_PolL { get; set; }

        [Required]
        [StringLength(50)]
        public string Concepto_PolL { get; set; }

        [Column(TypeName = "money")]
        public decimal Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal Abono { get; set; }

        [Required]
        [StringLength(10)]
        public string Documento { get; set; }

        [Required]
        [StringLength(12)]
        public string Referencia { get; set; }

        public long Caza { get; set; }

        public DateTime Fecha_Cap { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Cap { get; set; }
    }
}
