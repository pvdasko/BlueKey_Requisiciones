namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSINVFIS")]
    public partial class C001COSINVFIS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Depto { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string Codigo_Articulo { get; set; }

        [StringLength(50)]
        public string Unidad_Medida { get; set; }

        public double? Costo_Real { get; set; }

        public double? Conteo { get; set; }

        [StringLength(50)]
        public string Iniciales { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Fecha { get; set; }
    }
}
