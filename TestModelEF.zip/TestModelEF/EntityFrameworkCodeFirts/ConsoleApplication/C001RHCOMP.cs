namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001RHCOMP")]
    public partial class C001RHCOMP
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Required]
        [StringLength(50)]
        public string Regimen { get; set; }

        [Required]
        [StringLength(50)]
        public string RiesgoPuesto { get; set; }

        [Required]
        [StringLength(100)]
        public string Calle { get; set; }

        [Required]
        [StringLength(20)]
        public string NoExterior { get; set; }

        [Required]
        [StringLength(20)]
        public string NoInterior { get; set; }

        [Required]
        [StringLength(50)]
        public string TipoContrato { get; set; }

        [Required]
        [StringLength(50)]
        public string TipoJornada { get; set; }
    }
}
