namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NUEVA")]
    public partial class NUEVA
    {
        [Key]
        [StringLength(20)]
        public string Codigo_Cliente { get; set; }

        [StringLength(70)]
        public string Razon_Social { get; set; }

        [StringLength(70)]
        public string Nombre_Comercial { get; set; }

        [StringLength(2)]
        public string Tipo_Cliente { get; set; }

        [StringLength(19)]
        public string Cuenta_Contable { get; set; }

        [StringLength(70)]
        public string Direccion { get; set; }

        [StringLength(70)]
        public string Colonia { get; set; }

        [StringLength(50)]
        public string Poblacion { get; set; }

        [StringLength(7)]
        public string CP { get; set; }

        [StringLength(15)]
        public string Telefono { get; set; }

        [StringLength(15)]
        public string No_Fax { get; set; }

        [StringLength(70)]
        public string E_Mail { get; set; }

        [StringLength(70)]
        public string Pag_Web { get; set; }

        [StringLength(20)]
        public string RFC { get; set; }

        [StringLength(70)]
        public string Contacto { get; set; }

        [StringLength(15)]
        public string Descuento { get; set; }

        [StringLength(25)]
        public string Procede { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_Mes_Actual { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_Vencer { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_30 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_60 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_90 { get; set; }

        [Column(TypeName = "money")]
        public decimal? Saldo_120 { get; set; }
    }
}
