namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class REPGENERALES
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Reporte { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        public string Linea { get; set; }

        [Column("Query Inicial")]
        [Required]
        [StringLength(50)]
        public string Query_Inicial { get; set; }

        public double Lineas { get; set; }

        [Required]
        [StringLength(50)]
        public string Titulo { get; set; }

        public double Orientacion { get; set; }

        [Column("Ancho Impresion")]
        public double Ancho_Impresion { get; set; }

        [Column("Campo Gran Total")]
        public double Campo_Gran_Total { get; set; }

        [Column("Query Totales")]
        [Required]
        [StringLength(100)]
        public string Query_Totales { get; set; }

        [Column("Con Subtotal")]
        [Required]
        [StringLength(100)]
        public string Con_Subtotal { get; set; }

        [Column("Query Final")]
        [Required]
        [StringLength(100)]
        public string Query_Final { get; set; }

        [Column("DB Folio")]
        [Required]
        [StringLength(100)]
        public string DB_Folio { get; set; }

        [Column("Imp Llegadas")]
        [Required]
        [StringLength(100)]
        public string Imp_Llegadas { get; set; }

        [Column("Imp Salidas")]
        [Required]
        [StringLength(100)]
        public string Imp_Salidas { get; set; }
    }
}
