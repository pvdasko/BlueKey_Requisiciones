namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMSUAMOV")]
    public partial class C001NOMSUAMOV
    {
        [Key]
        [Column(Order = 0, TypeName = "numeric")]
        public decimal NoEmp { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string CodMov { get; set; }

        public DateTime FechaMov { get; set; }

        [Required]
        [StringLength(8)]
        public string FolioIncapacidad { get; set; }

        [Required]
        [StringLength(2)]
        public string DiasIncidencia { get; set; }

        public double SDAV { get; set; }
    }
}
