namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCLA")]
    public partial class C001CONCLA
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CONCLA()
        {
            C001CONSUB = new HashSet<C001CONSUB>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(1)]
        public string Tipo_Cuenta { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string Clasificacion { get; set; }

        [Required]
        [StringLength(30)]
        public string Descripcion_1 { get; set; }

        [StringLength(30)]
        public string Descripcion_2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONSUB> C001CONSUB { get; set; }
    }
}
