namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVHISTORICO")]
    public partial class C001INVHISTORICO
    {
        [Key]
        [Column(Order = 0)]
        public DateTime Fecha { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        public double Existencia { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Prom { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_UE { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Ant { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? TotalDia { get; set; }
    }
}
