namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class RELOJHORARIOS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CodigoHorario { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Dia { get; set; }

        [Required]
        [StringLength(100)]
        public string Descripcion { get; set; }

        public bool DiaOk { get; set; }

        [Required]
        [StringLength(1)]
        public string TipoHorario { get; set; }

        public DateTime? Entrada { get; set; }

        public DateTime? Salida { get; set; }

        public bool Comida { get; set; }

        public DateTime? SalidaComida { get; set; }

        public DateTime? EntradaComida { get; set; }

        public double TotalHoras { get; set; }
    }
}
