namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TERMINAL")]
    public partial class TERMINAL
    {
        [Key]
        [Column("Terminal")]
        [StringLength(50)]
        public string Terminal1 { get; set; }

        [Required]
        [StringLength(2)]
        public string Clave_Cia { get; set; }

        [StringLength(30)]
        public string Ubicacion { get; set; }

        [StringLength(20)]
        public string Programa { get; set; }

        [StringLength(3)]
        public string Operador { get; set; }

        [StringLength(50)]
        public string Ruta { get; set; }
    }
}
