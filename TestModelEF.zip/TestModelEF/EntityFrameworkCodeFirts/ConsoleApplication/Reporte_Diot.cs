namespace ConsoleApplication
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Reporte_Diot
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Usuario { get; set; }

        [Key]
        [Column(Order = 1)]
        public double Consecutivo { get; set; }

        [StringLength(2)]
        public string Tipo_Poliza { get; set; }

        [StringLength(50)]
        public string Numero_Poliza { get; set; }

        public DateTime? Fecha { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(20)]
        public string RFC { get; set; }

        [StringLength(250)]
        public string Nombre { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        [Column(TypeName = "money")]
        public decimal Impuesto { get; set; }
    }
}
