namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCHMA")]
    public partial class C001CXPCHMA
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Codigo_Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string No_Cheque { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(6)]
        public string Codigo_Prov { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(4)]
        public string Poliza { get; set; }

        [StringLength(1)]
        public string Codigo { get; set; }

        [StringLength(8)]
        public string Fecha { get; set; }

        [StringLength(70)]
        public string Beneficiario { get; set; }

        [StringLength(70)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal? Importe { get; set; }

        [StringLength(1)]
        public string Anticipo { get; set; }

        [StringLength(6)]
        public string Factura { get; set; }

        [StringLength(20)]
        public string Cta_Gastos { get; set; }

        [Column(TypeName = "money")]
        public decimal? Tipo_Cam { get; set; }

        [StringLength(1)]
        public string Impreso { get; set; }
    }
}
