namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Bitacora")]
    public partial class Bitacora
    {
        [Key]
        public long Indice { get; set; }

        [StringLength(50)]
        public string Tipo_Mov { get; set; }

        [StringLength(50)]
        public string Usuario { get; set; }

        public DateTime? FechaHora { get; set; }

        [StringLength(4)]
        public string Periodo { get; set; }

        [StringLength(2)]
        public string Tipo_Pol { get; set; }

        [StringLength(8)]
        public string Num_Pol { get; set; }

        public int? Linea { get; set; }

        [StringLength(16)]
        public string Cuenta { get; set; }

        [StringLength(100)]
        public string Concepto { get; set; }

        [Column(TypeName = "money")]
        public decimal? Cargo { get; set; }

        [Column(TypeName = "money")]
        public decimal? Abono { get; set; }

        [StringLength(50)]
        public string Equipo { get; set; }
    }
}
