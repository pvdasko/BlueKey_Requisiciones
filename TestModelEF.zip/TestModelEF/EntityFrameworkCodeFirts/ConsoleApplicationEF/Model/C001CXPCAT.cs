namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCAT")]
    public partial class C001CXPCAT
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CXPCAT()
        {
            C001COMCOTI = new HashSet<C001COMCOTI>();
            C001COMPRECIOS = new HashSet<C001COMPRECIOS>();
            C001INVART = new HashSet<C001INVART>();
            C001INVART1 = new HashSet<C001INVART>();
            C001INVGEN = new HashSet<C001INVGEN>();
            AF_ART = new HashSet<AF_ART>();
            AF_ART1 = new HashSet<AF_ART>();
            AF_GEN = new HashSet<AF_GEN>();
            CON_FACGEN = new HashSet<CON_FACGEN>();
        }

        [Key]
        [StringLength(6)]
        public string Codigo_Provedor { get; set; }

        [Required]
        [StringLength(100)]
        public string Razon_Social { get; set; }

        [StringLength(2)]
        public string Tipo_Provedor { get; set; }

        [StringLength(20)]
        public string Cuenta { get; set; }

        [StringLength(100)]
        public string Direccion { get; set; }

        [StringLength(70)]
        public string Colonia { get; set; }

        [StringLength(50)]
        public string Poblacion { get; set; }

        [StringLength(7)]
        public string CP { get; set; }

        [StringLength(20)]
        public string Telefono { get; set; }

        [StringLength(20)]
        public string No_Fax { get; set; }

        [StringLength(70)]
        public string E_Mail { get; set; }

        [StringLength(70)]
        public string Pag_Web { get; set; }

        [StringLength(20)]
        public string RFC { get; set; }

        [StringLength(70)]
        public string Contacto { get; set; }

        [StringLength(30)]
        public string Cta_Banco { get; set; }

        [StringLength(70)]
        public string Forma_Pago { get; set; }

        [StringLength(25)]
        public string Tiempo_Entrega { get; set; }

        [StringLength(10)]
        public string Descuento { get; set; }

        public double Procede { get; set; }

        public double Iva { get; set; }

        [StringLength(15)]
        public string Saldo_Mes_Actual { get; set; }

        [StringLength(15)]
        public string Saldo_Vencer { get; set; }

        [StringLength(15)]
        public string Saldo_30 { get; set; }

        [StringLength(15)]
        public string Saldo_60 { get; set; }

        [StringLength(15)]
        public string Saldo_90 { get; set; }

        [StringLength(15)]
        public string Saldo_120 { get; set; }

        [StringLength(50)]
        public string CURP { get; set; }

        [StringLength(2)]
        public string Tipo2 { get; set; }

        [StringLength(2)]
        public string Tipo3 { get; set; }

        [StringLength(2)]
        public string Tipo4 { get; set; }

        [StringLength(100)]
        public string Comercial { get; set; }

        [StringLength(100)]
        public string Pais { get; set; }

        [StringLength(20)]
        public string CodigoAnterior { get; set; }

        [StringLength(50)]
        public string TipoTercero { get; set; }

        [StringLength(50)]
        public string TipoOperacion { get; set; }

        [StringLength(40)]
        public string IDFiscal { get; set; }

        [StringLength(40)]
        public string Nacionalidad { get; set; }

        [StringLength(50)]
        public string TipoServicio { get; set; }

        [StringLength(20)]
        public string Nombre_Plaza { get; set; }

        [StringLength(4)]
        public string Numero_CW { get; set; }

        [StringLength(4)]
        public string Numero_Plaza { get; set; }

        [StringLength(4)]
        public string Numero_Sucursal { get; set; }

        [StringLength(30)]
        public string Nombre_Banco { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMCOTI> C001COMCOTI { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMPRECIOS> C001COMPRECIOS { get; set; }

        public virtual C001CXPINTBAN C001CXPINTBAN { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVART> C001INVART { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVART> C001INVART1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVGEN> C001INVGEN { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_ART> AF_ART { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_ART> AF_ART1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_GEN> AF_GEN { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CON_FACGEN> CON_FACGEN { get; set; }
    }
}
