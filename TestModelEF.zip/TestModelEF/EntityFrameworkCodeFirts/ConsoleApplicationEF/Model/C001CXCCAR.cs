namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCCAR")]
    public partial class C001CXCCAR
    {
        [Key]
        [StringLength(2)]
        public string Numero_Codigo { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo_Codigo { get; set; }

        [Required]
        [StringLength(100)]
        public string Nombre_Codigo { get; set; }

        [StringLength(100)]
        public string Nombre_Ingles { get; set; }

        public bool? Folio { get; set; }

        public bool? Iva { get; set; }

        public bool? Ish { get; set; }

        [StringLength(16)]
        public string Cuenta { get; set; }
    }
}
