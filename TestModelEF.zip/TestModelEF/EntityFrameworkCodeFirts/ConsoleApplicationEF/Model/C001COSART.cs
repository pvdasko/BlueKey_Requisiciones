namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSART")]
    public partial class C001COSART
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Codigo_Articulo { get; set; }

        [Column(TypeName = "money")]
        public decimal Costo_Prom { get; set; }

        public double Cant_Articulo { get; set; }

        [Required]
        [StringLength(2)]
        public string Unidad_Medida { get; set; }

        public double Cant_Util { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Costo_Real { get; set; }

        public long Codigo_Inventario { get; set; }

        [Required]
        [StringLength(250)]
        public string Desc_Esp { get; set; }

        public double Porc_Merma { get; set; }

        public bool Presentacion { get; set; }

        public bool Excluir { get; set; }
    }
}
