namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONCTOS")]
    public partial class C001CONCTOS
    {
        [Key]
        [StringLength(2)]
        public string Periodo { get; set; }

        public double Mes_1 { get; set; }

        public double Mes_2 { get; set; }

        public double Mes_3 { get; set; }

        public double Mes_4 { get; set; }

        public double Mes_5 { get; set; }

        public double Mes_6 { get; set; }

        public double Mes_7 { get; set; }

        public double Mes_8 { get; set; }

        public double Mes_9 { get; set; }

        public double Mes_10 { get; set; }

        public double Mes_11 { get; set; }

        public double Mes_12 { get; set; }
    }
}
