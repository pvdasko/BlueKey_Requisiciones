namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCOD")]
    public partial class C001CXPCOD
    {
        [Key]
        [StringLength(2)]
        public string Numero_Codigo { get; set; }

        [Required]
        [StringLength(1)]
        public string Tipo_Codigo { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombre_Codigo { get; set; }
    }
}
