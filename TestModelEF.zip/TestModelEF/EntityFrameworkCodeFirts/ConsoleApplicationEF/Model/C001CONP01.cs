namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONP01")]
    public partial class C001CONP01
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001CONP01()
        {
            C001CONP02 = new HashSet<C001CONP02>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Rubro { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Secuencia { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Esp { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Ing { get; set; }

        [Required]
        [StringLength(1)]
        public string Cod { get; set; }

        [StringLength(7)]
        public string Calculo_Porcentaje { get; set; }

        public bool CambioSigno { get; set; }

        [StringLength(100)]
        public string Operacion { get; set; }

        public bool Variacion { get; set; }

        public bool MesAnt { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001CONP02> C001CONP02 { get; set; }
    }
}
