namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONSUB")]
    public partial class C001CONSUB
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(1)]
        public string Tipo_Cuenta { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string Clasificacion { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Subclasificacion { get; set; }

        [Required]
        [StringLength(30)]
        public string Descripcion_1 { get; set; }

        [StringLength(30)]
        public string Descripcion_2 { get; set; }

        public virtual C001CONCLA C001CONCLA { get; set; }
    }
}
