namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMRQG")]
    public partial class C001COMRQG
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001COMRQG()
        {
            C001COMRQL = new HashSet<C001COMRQL>();
        }

        [Key]
        public long No_Req { get; set; }

        [Required]
        [StringLength(1)]
        public string Tip_Req { get; set; }

        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [Required]
        [StringLength(1)]
        public string Cod_Prio { get; set; }

        [StringLength(200)]
        public string Notas_Req { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [StringLength(200)]
        public string Notas_Auto { get; set; }

        public DateTime Fecha_Req { get; set; }

        public DateTime Hora_Req { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Req { get; set; }

        public DateTime? Fecha_Aut { get; set; }

        public DateTime? Hora_Aut { get; set; }

        [StringLength(50)]
        public string Ope_Aut { get; set; }

        public bool Status_Req { get; set; }

        public bool Status_Cot { get; set; }

        public bool Status_Ped { get; set; }

        public bool Dolares { get; set; }

        public DateTime? OPE_HORA_AUT { get; set; }

        public bool? TIPO_SM { get; set; }

        public bool? AUT_CONT { get; set; }

        [StringLength(3)]
        public string OPE_AUT_CONT { get; set; }

        public DateTime? FECHA_AUT_CONT { get; set; }

        public bool? AUT_GER { get; set; }

        [StringLength(3)]
        public string OPE_AUT_GER { get; set; }

        public DateTime? FECHA_AUT_GER { get; set; }

        [Required]
        [StringLength(50)]
        public string Origen { get; set; }

        public bool Sel { get; set; }

        public virtual C001COMPRI C001COMPRI { get; set; }

        public virtual C001COMTIP C001COMTIP { get; set; }

        public virtual C001INVDEP C001INVDEP { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMRQL> C001COMRQL { get; set; }
    }
}
