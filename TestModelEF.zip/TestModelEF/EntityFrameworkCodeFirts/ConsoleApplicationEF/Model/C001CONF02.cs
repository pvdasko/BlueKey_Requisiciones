namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONF02")]
    public partial class C001CONF02
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Rubro { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Secuencia { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(16)]
        public string Cuenta_Inicial { get; set; }

        [Required]
        [StringLength(16)]
        public string Cuenta_Final { get; set; }

        public virtual C001CONF01 C001CONF01 { get; set; }
    }
}
