namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSRCG")]
    public partial class C001COSRCG
    {
        [Key]
        [StringLength(50)]
        public string Codigo_Receta { get; set; }

        [Required]
        [StringLength(50)]
        public string Nom_RecEsp { get; set; }

        [StringLength(50)]
        public string Nom_RecIng { get; set; }

        public double Porciones { get; set; }

        [Column(TypeName = "money")]
        public decimal? Precio_Venta { get; set; }

        [Required]
        [StringLength(2)]
        public string Unidad { get; set; }

        public double Porc_Improd { get; set; }

        public bool SubReceta { get; set; }

        [Required]
        [StringLength(5)]
        public string Cla { get; set; }

        [Required]
        [StringLength(5)]
        public string Grup { get; set; }

        public virtual C001COSUNI C001COSUNI { get; set; }
    }
}
