namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPRQG")]
    public partial class C001COMPRQG
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Required]
        [StringLength(1)]
        public string Tip_Req { get; set; }

        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [Required]
        [StringLength(1)]
        public string Cod_Prio { get; set; }

        [StringLength(200)]
        public string Notas_Req { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [StringLength(200)]
        public string Notas_Auto { get; set; }

        public DateTime Fecha_Req { get; set; }

        public DateTime Hora_Req { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Req { get; set; }

        public DateTime? Fecha_Aut { get; set; }

        public DateTime? Hora_Aut { get; set; }

        [StringLength(50)]
        public string Ope_Aut { get; set; }

        public bool Status_Req { get; set; }

        public bool Status_Cot { get; set; }

        public bool Status_Ped { get; set; }

        public bool Dolares { get; set; }
    }
}
