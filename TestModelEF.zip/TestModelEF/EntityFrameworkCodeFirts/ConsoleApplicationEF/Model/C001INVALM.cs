namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVALM")]
    public partial class C001INVALM
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVALM()
        {
            C001INVSUB = new HashSet<C001INVSUB>();
        }

        [Key]
        [StringLength(4)]
        public string Codigo_Almacen { get; set; }

        [Required]
        [StringLength(40)]
        public string Descripcion_Espanol { get; set; }

        [StringLength(40)]
        public string Descripcion_Ingles { get; set; }

        [StringLength(19)]
        public string Cta_Contable { get; set; }

        [StringLength(50)]
        public string Libre { get; set; }

        public bool Consignacion { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVSUB> C001INVSUB { get; set; }
    }
}
