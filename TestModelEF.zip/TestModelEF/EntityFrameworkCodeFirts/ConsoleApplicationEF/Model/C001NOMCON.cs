namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCON")]
    public partial class C001NOMCON
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001NOMCON()
        {
            C001NOMPREST = new HashSet<C001NOMPREST>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Concepto { get; set; }

        [Required]
        [StringLength(50)]
        public string NombreConcepto { get; set; }

        public bool Percepcion { get; set; }

        public bool Deduccion { get; set; }

        public bool Gravable { get; set; }

        public bool Sumariza { get; set; }

        [Required]
        [StringLength(50)]
        public string Formula { get; set; }

        public bool SueldosVariables { get; set; }

        public bool Infonavit { get; set; }

        public bool Sar { get; set; }

        public bool ConceptoSueldo { get; set; }

        public int SAT { get; set; }

        public bool Prenomina { get; set; }

        public bool DiasImss { get; set; }

        public bool CuotaSind { get; set; }

        public bool SeguroVida { get; set; }

        public bool FondoSeguro { get; set; }

        public bool DiasTrab { get; set; }

        [Required]
        [StringLength(4)]
        public string CtaMayor { get; set; }

        [Required]
        [StringLength(16)]
        public string SubCta { get; set; }

        public bool Fecha { get; set; }

        [Required]
        [StringLength(16)]
        public string CtaProv { get; set; }

        public bool Incapacidad { get; set; }

        public bool PTU { get; set; }

        public bool Retardo { get; set; }

        public bool Falta { get; set; }

        public bool HoraE { get; set; }

        public bool CamaE { get; set; }

        public bool PTU_Dias { get; set; }

        public bool Complemento { get; set; }

        public bool Fiscal { get; set; }

        [Required]
        [StringLength(3)]
        public string CFDI { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001NOMPREST> C001NOMPREST { get; set; }
    }
}
