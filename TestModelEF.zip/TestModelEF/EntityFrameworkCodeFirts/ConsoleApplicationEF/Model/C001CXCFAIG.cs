namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCFAIG")]
    public partial class C001CXCFAIG
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Factura { get; set; }

        [Required]
        [StringLength(6)]
        public string Cod_Cliente { get; set; }

        public DateTime Fecha_Fac { get; set; }

        [StringLength(100)]
        public string Comentarios { get; set; }

        [Required]
        [StringLength(3)]
        public string Cod_Ope { get; set; }

        public bool Dolares { get; set; }

        public bool Status { get; set; }

        public bool Impresa { get; set; }

        public bool Cancelada { get; set; }

        public DateTime Fecha_Sis { get; set; }

        [Column(TypeName = "money")]
        public decimal Tipo_Cambio { get; set; }

        [Column(TypeName = "money")]
        public decimal Sub_Factura { get; set; }

        [Column(TypeName = "money")]
        public decimal? Total_Iva { get; set; }

        [Column(TypeName = "money")]
        public decimal Total_Ish { get; set; }

        public bool Ley_1 { get; set; }

        public bool Ley_2 { get; set; }

        public bool Ley_3 { get; set; }

        public bool otros { get; set; }
    }
}
