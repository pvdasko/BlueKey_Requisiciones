namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCCART_HISTO")]
    public partial class C001CXCCART_HISTO
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Periodo { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Cliente { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string Docto { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(2)]
        public string Codigo_Cargo { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(20)]
        public string Referencia { get; set; }

        [Required]
        [StringLength(1)]
        public string Cargo_Abono { get; set; }

        [Required]
        [StringLength(150)]
        public string Descripcion { get; set; }

        [StringLength(16)]
        public string Cta_Contable { get; set; }

        public DateTime Fecha_Doc { get; set; }

        public DateTime Fecha_Mov { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe_Real { get; set; }

        [StringLength(25)]
        public string Libre_1 { get; set; }

        [StringLength(6)]
        public string Movto { get; set; }

        [Column(TypeName = "money")]
        public decimal Tipo_Cam { get; set; }

        [StringLength(15)]
        public string Libre_4 { get; set; }

        public DateTime Fecha_Cap { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Cap { get; set; }

        public bool Status { get; set; }

        [StringLength(4)]
        public string PerCont { get; set; }

        [StringLength(8)]
        public string No_Pol { get; set; }

        public long No_Billing { get; set; }

        [Column(TypeName = "money")]
        public decimal Tipo_Cambio { get; set; }

        [StringLength(2)]
        public string No_Banco { get; set; }

        [StringLength(8)]
        public string No_Fact { get; set; }
    }
}
