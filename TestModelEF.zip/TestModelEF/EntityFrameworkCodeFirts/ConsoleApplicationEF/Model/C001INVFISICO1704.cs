namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVFISICO1704")]
    public partial class C001INVFISICO1704
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        public float? Inv_Fisico { get; set; }

        [Column(TypeName = "money")]
        public decimal? Costo_Promedio { get; set; }

        [StringLength(3)]
        public string Iniciales { get; set; }

        public DateTime? Fecha_Captura { get; set; }
    }
}
