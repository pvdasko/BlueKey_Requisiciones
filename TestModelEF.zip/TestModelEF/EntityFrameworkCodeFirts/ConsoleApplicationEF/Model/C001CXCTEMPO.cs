namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCTEMPO")]
    public partial class C001CXCTEMPO
    {
        [Key]
        [StringLength(10)]
        public string Documento { get; set; }
    }
}
