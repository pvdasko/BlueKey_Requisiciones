namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCAR")]
    public partial class C001CXPCAR
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(6)]
        public string Cod_Provedor { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(6)]
        public string Num_Factura { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Codigo_Cargo { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(2)]
        public string Codigo_Banco { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(10)]
        public string Num_Cheque { get; set; }

        public DateTime? Fecha_Fec { get; set; }

        public DateTime? Fecha_Ven { get; set; }

        public DateTime? Fecha_Mov { get; set; }

        [StringLength(50)]
        public string Comentarios { get; set; }

        [Column(TypeName = "money")]
        public decimal Importe { get; set; }

        [StringLength(25)]
        public string Libre_1 { get; set; }

        [StringLength(15)]
        public string Libre_2 { get; set; }

        [StringLength(25)]
        public string Libre_3 { get; set; }

        [StringLength(15)]
        public string Libre_4 { get; set; }
    }
}
