namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONESTA17")]
    public partial class C001CONESTA17
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string Rubro { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Secuencia { get; set; }

        public double Mes_1 { get; set; }

        public double Mes_2 { get; set; }

        public double Mes_3 { get; set; }

        public double Mes_4 { get; set; }

        public double Mes_5 { get; set; }

        public double Mes_6 { get; set; }

        public double Mes_7 { get; set; }

        public double Mes_8 { get; set; }

        public double Mes_9 { get; set; }

        public double Mes_10 { get; set; }

        public double Mes_11 { get; set; }

        public double Mes_12 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_1 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_2 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_3 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_4 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_5 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_6 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_7 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_8 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_9 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_10 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_11 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double Sal_12 { get; set; }

        public double Pres_1 { get; set; }

        public double Pres_2 { get; set; }

        public double Pres_3 { get; set; }

        public double Pres_4 { get; set; }

        public double Pres_5 { get; set; }

        public double Pres_6 { get; set; }

        public double Pres_7 { get; set; }

        public double Pres_8 { get; set; }

        public double Pres_9 { get; set; }

        public double Pres_10 { get; set; }

        public double Pres_11 { get; set; }

        public double Pres_12 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_1 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_2 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_3 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_4 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_5 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_6 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_7 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_8 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_9 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_10 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_11 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double APres_12 { get; set; }

        public virtual C001CONF01 C001CONF01 { get; set; }
    }
}
