namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCAMBIOS")]
    public partial class C001NOMCAMBIOS
    {
        [Key]
        public long Consecutivo { get; set; }

        public long NoEmpleado { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime Hora { get; set; }

        public int Campo { get; set; }

        [Required]
        [StringLength(150)]
        public string DatoAnterior { get; set; }

        [Required]
        [StringLength(150)]
        public string DatoNuevo { get; set; }

        [Required]
        [StringLength(350)]
        public string Notas { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope { get; set; }
    }
}
