namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVFABR")]
    public partial class C001INVFABR
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long codigoFab { get; set; }

        [Required]
        [StringLength(250)]
        public string nombre { get; set; }
    }
}
