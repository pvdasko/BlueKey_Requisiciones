namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPDG")]
    public partial class C001COMPDG
    {
        [Key]
        public long No_Ped { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(300)]
        public string Notas { get; set; }

        public DateTime Fecha_Ped { get; set; }

        public DateTime Fecha_Entrega { get; set; }

        [Required]
        [StringLength(4)]
        public string Cod_Depto { get; set; }

        public bool Autoriza { get; set; }

        public bool Autoriza2 { get; set; }

        public bool Impresa { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Genera { get; set; }

        [StringLength(3)]
        public string Ope_Autoriza { get; set; }

        [StringLength(3)]
        public string Ope_Autoriza2 { get; set; }

        [StringLength(3)]
        public string Ope_Imprime { get; set; }

        public bool Entrada_1 { get; set; }

        public bool Entrada_2 { get; set; }

        public bool Entrada_3 { get; set; }

        public bool Entrada_4 { get; set; }

        public DateTime? Fecha_1 { get; set; }

        public DateTime? Fecha_2 { get; set; }

        public DateTime? Fecha_3 { get; set; }

        public DateTime? Fecha_4 { get; set; }

        public bool Dolares { get; set; }

        [StringLength(100)]
        public string Condiciones { get; set; }

        public long Requisicion { get; set; }

        public bool Imagen1 { get; set; }

        public bool Imagen2 { get; set; }

        public bool? Status { get; set; }

        public bool Autoriza_JefeAlmacen { get; set; }

        public bool Autoriza_JefeCompras { get; set; }

        public bool Autoriza_Contralor { get; set; }

        public bool Autoriza_Gerente { get; set; }

        [StringLength(3)]
        public string Ope_JefeAlmacen { get; set; }

        [StringLength(3)]
        public string Ope_JefeCompras { get; set; }

        [StringLength(3)]
        public string Ope_Contralor { get; set; }

        [StringLength(3)]
        public string Ope_Gerente { get; set; }

        public DateTime? Hora_JefeAlmacen { get; set; }

        public DateTime? Hora_JefeCompras { get; set; }

        public DateTime? Hora_Contralor { get; set; }

        public DateTime? Hora_Gerente { get; set; }

        public bool Operacion { get; set; }

        public bool Firmas { get; set; }

        [StringLength(50)]
        public string Tiempo_Entrega { get; set; }

        [StringLength(300)]
        public string Notas_1 { get; set; }

        [StringLength(300)]
        public string Notas_2 { get; set; }

        public bool Autoriza_Director { get; set; }

        [StringLength(3)]
        public string Ope_Director { get; set; }

        public DateTime? Hora_Director { get; set; }

        public bool SOE { get; set; }

        public bool FFE { get; set; }

        [Required]
        [StringLength(1)]
        public string Proceso { get; set; }

        [Required]
        [StringLength(300)]
        public string Observaciones { get; set; }

        [Required]
        [StringLength(50)]
        public string comentarios { get; set; }
    }
}
