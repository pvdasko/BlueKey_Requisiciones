namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXCCOB")]
    public partial class C001CXCCOB
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cliente { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        public string Cheque { get; set; }

        public DateTime Fecha { get; set; }

        public DateTime FechaAplica { get; set; }

        [Required]
        [StringLength(100)]
        public string Referencia { get; set; }

        [Required]
        [StringLength(100)]
        public string Documento { get; set; }

        public bool TiempoCompartido { get; set; }

        [Column(TypeName = "money")]
        public decimal Monto { get; set; }

        [Column(TypeName = "money")]
        public decimal Baja { get; set; }

        [Column(TypeName = "money")]
        public decimal Cabo { get; set; }

        [Column(TypeName = "money")]
        public decimal Ixtapa { get; set; }

        [Column(TypeName = "money")]
        public decimal Manzanillo { get; set; }

        [Column(TypeName = "money")]
        public decimal Tapatia { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Total { get; set; }
    }
}
