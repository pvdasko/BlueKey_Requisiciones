namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONTC")]
    public partial class C001CONTC
    {
        [Key]
        public DateTime Fecha { get; set; }

        [Column(TypeName = "money")]
        public decimal TipoCambio { get; set; }
    }
}
