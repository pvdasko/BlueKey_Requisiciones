namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CONPRE15")]
    public partial class C001CONPRE15
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_1 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_2 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_3 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_4 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_5 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_6 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_7 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_8 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_9 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_10 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_11 { get; set; }

        [Column(TypeName = "money")]
        public decimal Mes_12 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal Sal_1 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_2 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_3 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_4 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_5 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_6 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_7 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_8 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_9 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_10 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_11 { get; set; }

        [Column(TypeName = "money")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public decimal? Sal_12 { get; set; }

        public virtual C001CONCTA C001CONCTA { get; set; }
    }
}
