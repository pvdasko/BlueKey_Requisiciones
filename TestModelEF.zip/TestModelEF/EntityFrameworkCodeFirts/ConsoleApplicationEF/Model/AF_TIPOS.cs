namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_TIPOS
    {
        [Key]
        [StringLength(3)]
        public string Cod_Tip { get; set; }

        [Required]
        [StringLength(50)]
        public string Desc_Tip { get; set; }
    }
}
