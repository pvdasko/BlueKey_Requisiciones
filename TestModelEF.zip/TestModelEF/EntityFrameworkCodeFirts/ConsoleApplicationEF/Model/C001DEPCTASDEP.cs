namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001DEPCTASDEP")]
    public partial class C001DEPCTASDEP
    {
        [Key]
        [StringLength(3)]
        public string Cia { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoDeposito { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoDepositoDol { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoDeposito { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoDepositoDol { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoLlega { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoLlegaDol { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoLlega { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoLlegaDol { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoTpoDeposito { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoTpoDepositoDol { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoTpoDeposito { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoTpoDepositoDol { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoTpoLlega { get; set; }

        [Required]
        [StringLength(16)]
        public string CargoTpoLlegaDol { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoTpoLlega { get; set; }

        [Required]
        [StringLength(16)]
        public string AbonoTpoLlegaDol { get; set; }
    }
}
