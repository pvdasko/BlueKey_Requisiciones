namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVART1611")]
    public partial class C001INVART1611
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        [Required]
        [StringLength(50)]
        public string Cod_Barras { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Esp { get; set; }

        [StringLength(100)]
        public string Desc_Ing { get; set; }

        [Required]
        [StringLength(4)]
        public string Alm { get; set; }

        [Required]
        [StringLength(4)]
        public string Sub_Alm { get; set; }

        public double IVA { get; set; }

        [StringLength(50)]
        public string Notas { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_1 { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_2 { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Maximo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Minimo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Reorden { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Ent { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Sal { get; set; }

        [Required]
        [StringLength(3)]
        public string Conver { get; set; }
    }
}
