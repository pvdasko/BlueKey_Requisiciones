namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPCURR")]
    public partial class C001CXPCURR
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Banco { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string FontSize { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string FontName { get; set; }

        [Key]
        [Column(Order = 3)]
        public bool FontBold { get; set; }
    }
}
