namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVPER")]
    public partial class C001INVPER
    {
        [Key]
        [StringLength(4)]
        public string Periodo { get; set; }

        public bool Cerrado { get; set; }
    }
}
