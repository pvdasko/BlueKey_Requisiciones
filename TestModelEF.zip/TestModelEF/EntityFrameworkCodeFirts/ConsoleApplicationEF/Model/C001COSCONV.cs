namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSCONV")]
    public partial class C001COSCONV
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string Uni_Pricipal { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string Uni_Conv { get; set; }

        public double Conv { get; set; }

        public virtual C001COSUNI C001COSUNI { get; set; }

        public virtual C001COSUNI C001COSUNI1 { get; set; }
    }
}
