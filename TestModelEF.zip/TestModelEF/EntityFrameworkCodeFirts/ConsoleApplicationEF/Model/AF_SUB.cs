namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_SUB
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AF_SUB()
        {
            AF_ART = new HashSet<AF_ART>();
        }

        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cod_Almacen { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cod_Subalmacen { get; set; }

        [StringLength(40)]
        public string Descripcion_Espanol { get; set; }

        [StringLength(40)]
        public string Descripcion_Ingles { get; set; }

        [StringLength(16)]
        public string Cuenta_Abono { get; set; }

        [StringLength(16)]
        public string Cuenta_Cargo1 { get; set; }

        [StringLength(16)]
        public string Cuenta_Cargo2 { get; set; }

        [StringLength(50)]
        public string Libre { get; set; }

        public virtual AF_ALM AF_ALM { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AF_ART> AF_ART { get; set; }
    }
}
