namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPRQL")]
    public partial class C001COMPRQL
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Lin { get; set; }

        public long Cod_Art { get; set; }

        [Required]
        [StringLength(200)]
        public string Desc_Art { get; set; }

        public double Cantidad { get; set; }

        [Required]
        [StringLength(10)]
        public string Cod_Med { get; set; }

        [StringLength(200)]
        public string Notas { get; set; }

        public bool Status_Cot { get; set; }
    }
}
