namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COSCLA")]
    public partial class C001COSCLA
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cla { get; set; }

        [Required]
        [StringLength(50)]
        public string Descripcion { get; set; }

        public int? Cod_Grupo { get; set; }

        public virtual C001COSCLA C001COSCLA1 { get; set; }

        public virtual C001COSCLA C001COSCLA2 { get; set; }
    }
}
