namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001CXPBAN")]
    public partial class C001CXPBAN
    {
        [Key]
        [StringLength(2)]
        public string Codigo_Banco { get; set; }

        [Required]
        [StringLength(70)]
        public string Nombre_Banco { get; set; }

        [Required]
        [StringLength(10)]
        public string Numero_Cheque { get; set; }

        [Required]
        [StringLength(20)]
        public string Cta_Contable { get; set; }

        [Required]
        [StringLength(2)]
        public string Tipo_Poliza { get; set; }

        public bool Dolares { get; set; }

        [StringLength(20)]
        public string Cta_Entregado { get; set; }

        [Required]
        [StringLength(50)]
        public string Archivo { get; set; }

        public virtual C001CONTIPOL C001CONTIPOL { get; set; }
    }
}
