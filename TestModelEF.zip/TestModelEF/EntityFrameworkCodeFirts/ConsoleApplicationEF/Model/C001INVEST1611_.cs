namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVEST1611 ")]
    public partial class C001INVEST1611_
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Cod_Art { get; set; }

        public double Exis_Dia { get; set; }

        public double Exis_Mes { get; set; }

        public double Exis_Per { get; set; }

        public double Ent_Dia { get; set; }

        public double Ent_Mes { get; set; }

        public double Ent_Per { get; set; }

        public double Sal_Dia { get; set; }

        public double Sal_Mes { get; set; }

        public double Sal_Per { get; set; }

        public double Devpro_Dia { get; set; }

        public double Devpro_Mes { get; set; }

        public double Devpro_Per { get; set; }

        public double Devalm_Dia { get; set; }

        public double Devalm_Mes { get; set; }

        public double Devalm_Per { get; set; }

        public double Ajus_Dia { get; set; }

        public double? Ajus_Mes { get; set; }

        public double Ajus_Per { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_UE { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Prom { get; set; }

        [Column(TypeName = "money")]
        public decimal Cos_Ant { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? TotalActual { get; set; }

        public DateTime? Fecha_UE { get; set; }

        public DateTime? Fecha_US { get; set; }

        public DateTime? Fecha_UA { get; set; }

        public DateTime? Fecha_UDP { get; set; }

        public DateTime? Fecha_UDD { get; set; }

        [StringLength(10)]
        public string Req_UE { get; set; }

        [StringLength(10)]
        public string Req_US { get; set; }

        [StringLength(10)]
        public string Req_UA { get; set; }

        [StringLength(10)]
        public string Req_UDP { get; set; }

        [StringLength(10)]
        public string Req_UDD { get; set; }
    }
}
