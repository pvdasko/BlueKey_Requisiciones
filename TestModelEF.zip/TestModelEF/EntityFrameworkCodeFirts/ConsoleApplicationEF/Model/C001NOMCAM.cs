namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMCAM")]
    public partial class C001NOMCAM
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long NoEmpleado { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(1)]
        public string Tipo_Movto { get; set; }

        [Key]
        [Column(Order = 2)]
        public DateTime Fecha { get; set; }

        [Column(TypeName = "money")]
        public decimal SDI_Anterior { get; set; }

        [Column(TypeName = "money")]
        public decimal SDI_Nuevo { get; set; }

        [Column(TypeName = "money")]
        public decimal SD_Anterior { get; set; }

        [Column(TypeName = "money")]
        public decimal SD_Nuevo { get; set; }
    }
}
