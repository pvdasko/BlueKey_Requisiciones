namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001NOMBAJMOT")]
    public partial class C001NOMBAJMOT
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Empleado { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Fecha { get; set; }

        public int NoMotivo { get; set; }

        [StringLength(300)]
        public string Motivo { get; set; }

        public virtual C001NOMBAJAS C001NOMBAJAS { get; set; }

        public virtual C001RHEMP C001RHEMP { get; set; }
    }
}
