namespace ConsoleApplicationEF.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AF_LIN
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Indice { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public long Cod_Art { get; set; }

        public double Can { get; set; }

        [Column(TypeName = "money")]
        public decimal Costo { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total { get; set; }

        [StringLength(16)]
        public string Cta_Con { get; set; }

        public virtual AF_ART AF_ART { get; set; }

        public virtual AF_GEN AF_GEN { get; set; }
    }
}
