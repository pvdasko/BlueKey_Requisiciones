﻿namespace WebRequsiciones.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public class OrdenesDetalle
    {

        [Key, Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int NoOrden { get; set; }

       [Key, Column(Order = 1)]
       [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Linea { get; set; }

        public int IdProducto { get; set; }

        [DisplayFormat(DataFormatString = "{0:N0}")]
        public double Cantidad { get; set; }

        [DataType(DataType.Currency)]
        public double Precio { get; set; }

        [NotMapped]
        [DataType(DataType.Currency)]
        public double TotalLinea
        {
            get { return Cantidad  * Precio; }
        }

        public virtual Ordenes Ordenes { get; set; }
        public virtual Producto  Productos { get; set; }
                
    }
}