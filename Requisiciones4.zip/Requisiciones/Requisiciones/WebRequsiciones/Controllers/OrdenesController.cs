﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models;
using PagedList;
using System.Data.Entity.Infrastructure;


namespace WebRequsiciones.Controllers
{
    public class OrdenesController : Controller
    {
        // GET: Ordenes
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)     
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            RequisionesModel db = new RequisionesModel(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoOrdenParm = String.IsNullOrEmpty(sortOrder) ? "NoOrden_desc" : "";
            ViewBag.ProveedorParm = String.IsNullOrEmpty(sortOrder) ? "Proveedor" : "Proveedor_desc";
            ViewBag.DepartamentoParm = String.IsNullOrEmpty(sortOrder) ? "Departamento" : "Departamento_desc";
            ViewBag.FechaOrdenParm = sortOrder == "FechaOrden" ? "FechaOrden_desc" : "FechaOrden";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from o in db.Ordenes //db.Ordenes.OrderBy(x => x.NoOrden).ToList();
                            select o;

            if (!String.IsNullOrEmpty(searchString))
            {
                int orden;
                if (int.TryParse (searchString , out  orden))
                {
                    viewModel = viewModel.Where (x => x.NoOrden == orden );

                }
                else
                {
                    viewModel = viewModel.Where(x => x.Departamento.Contains(searchString)
                                              || x.Proveedor.Contains(searchString));

                }
                
            }

            switch (sortOrder)
            {
                case "NoOrden_desc":
                    viewModel = viewModel.OrderByDescending(s => s.NoOrden);
                    break;
                case "Proveedor":
                    viewModel = viewModel.OrderBy(s => s.Proveedor);
                    break;
                case "Proveedor_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Proveedor);
                    break;
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.Departamento);
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Departamento);
                    break;
                case "FechaOrden":
                    viewModel = viewModel.OrderBy(s => s.FechaOrden );
                    break;
                case "FechaOrden_desc":
                    viewModel = viewModel.OrderByDescending(s => s.FechaOrden);
                    break;  
                default :
                     viewModel = viewModel.OrderBy(s => s.NoOrden);
                    break;
            }
            
            LoadSessionObject();

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList (pageNumber , pageSize ));
        }

        [HttpPost]
        public ActionResult Index( List<WebRequsiciones.Models.Ordene> orden, string command)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            RequisionesModel db = new RequisionesModel(connectionStringName);
                       
            try
            {               

                foreach (var i in orden )
                {
                    Ordene orderExist = db.Ordenes.Find(i.NoOrden);
                    orderExist.Aut_1 = i.Aut_1;
                    orderExist.Aut_1_User = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
                    orderExist.Aut_2 = i.Aut_2;
                    orderExist.Aut_2_User = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;



                }

                db.SaveChanges();

            }
            catch (RetryLimitExceededException /* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            
           return View();
        }

        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Ordenes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ordenes/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ordenes/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Ordenes/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ordenes/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }

        public void Aprobar(Ordene ordenes)
        { 
        
        }
    }
}
