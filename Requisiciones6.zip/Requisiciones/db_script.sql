--proyecto agregar las referecnias ed PagedList en 
-- Visual Studio

CREATE DATABASE Sitios
GO
USE Sitios
GO
CREATE TABLE Cias 
(
	IdCia INT NOT NULL, 
	[Razon Social] nvarchar (100),
	dbContext nvarchar(50)
	primary key (IdCia)
)

INSERT INTO Cias VALUES (1 , 'Compa�ia Uno' , 'ContextRequisiones')
INSERT INTO Cias VALUES (2 , 'Compa�ia Dos' , 'ContextRequisiones2')
INSERT INTO Cias VALUES (3 , 'Compa�ia Tres', 'ContextRequisiones3')

GO


SELECT * FROM Cias

CREATE DATABASE Requisiciones

GO


USE Requisiciones

GO
DROP TABLE Usuarios
GO

CREATE TABLE Usuarios
(
	Usuario nvarchar(8) not null, 
	Contrasena nvarchar(8) not null,
	Nombre nvarchar(100), 
	Rol int, 
	primary key (Usuario)
)

GO
Select * from Usuarios

GO

INSERT INTO  Usuarios VALUES ('nromero', '12345', 'Noe Romero', 1)
INSERT INTO  Usuarios VALUES ('jcedillo', '54321', 'Jorge Cedillo', 2)
INSERT INTO  Usuarios VALUES ('mmiranda', '98765', 'Mauricio Miranda', 3)

GO


CREATE TABLE Ordenes
(
	NoOrden int not null, 	
	Proveedor nvarchar (20),
	Departamento nvarchar (20) ,
	FechaOrden datetime,
	Aut_1 bit,
	Aut_1_User nvarchar(8),
	Aut_2 bit,
	Aut_2_User nvarchar(8),

	Primary key(NoOrden)
	
)

INSERT INTO Ordenes VALUES (1, 'Patito SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (3, 'Patito SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (4, 'Patito SA', 'Recursos Humanos', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (5, 'Patito SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (6, 'Patito SA', 'Calidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (7, 'Patito SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (8, 'Patito SA', 'Logistica', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (9, 'Patito SA', 'Almacen', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (10, 'Patito SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (11, 'Patito SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (12, 'Patito SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (13, 'Patito SA', 'Almacen', getdate(), 0, null, 0, null)

Select * from Ordenes 

DROP TABLE OrdenesDetalle

CREATE TABLE OrdenesDetalle
(
	NoOrden int not null, 	
	Linea int not null, 	
	IdProducto int not null,
	Cantidad float,
	Precio float, 
	Primary key(NoOrden, Linea )
	
)

INSERT INTO OrdenesDetalle VALUES (1,1,1,10,500)
INSERT INTO OrdenesDetalle VALUES (1,2,3,5,550)
INSERT INTO OrdenesDetalle VALUES (1,3,5,3,650)

INSERT INTO OrdenesDetalle VALUES (2,1,1,6,600)
INSERT INTO OrdenesDetalle VALUES (2,2,3,7,650)
INSERT INTO OrdenesDetalle VALUES (2,3,5,8,750)

INSERT INTO OrdenesDetalle VALUES (3,1,4,10,500)
INSERT INTO OrdenesDetalle VALUES (3,2,5,5,550)
INSERT INTO OrdenesDetalle VALUES (3,3,6,3,650)

SELECT * FROM OrdenesDetalle


CREATE TABLE [dbo].[Producto](
	[IdProducto] [int] NOT NULL,
	[Descripcion] [nvarchar](50) NULL,
	[CodigoBarras] [nvarchar](50) NULL,
	Primary key(IdProducto)
)


INSERT INTO Producto Values (1, 'Iphone 6', '123456')
INSERT INTO Producto Values (2, 'Iphone 6s', '123457')
INSERT INTO Producto Values (3, 'Iphone 6 plus', '123458')
INSERT INTO Producto Values (4, 'Iphone 7', '123460')
INSERT INTO Producto Values (5, 'Iphone 7s', '123461')
INSERT INTO Producto Values (6, 'Iphone 7 plus', '123462')
INSERT INTO Producto Values (7, 'Iphone 8', '123470')
INSERT INTO Producto Values (8, 'Iphone 8 plus', '123471')

GO
SELECT * from Producto

GO

CREATE TABLE Companias
(
	Cia int, 	
	Nombre nvarchar(100), 	
	primary key (Cia)
)

insert into Companias values (1, 'Microsoft')
insert into Companias values (2, 'Apple')
insert into Companias values (3, 'Google Inc')

select * from Companias


CREATE TABLE Requisiciones
(
	NoReq int not null, 	
	Proveedor nvarchar (20),
	Departamento nvarchar (20) ,
	FechaOrden datetime,
	Aut_1 bit,
	Aut_1_User nvarchar(8),
	Aut_2 bit,
	Aut_2_User nvarchar(8),

	Primary key(NoReq)
	
)


INSERT INTO Requisiciones VALUES (21, 'Oxxo SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (22, 'Seven SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (23, 'Oxxo SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (24, 'Seven SA', 'Recursos Humanos', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (25, 'Oxxo SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (26, 'Seven SA', 'Calidad', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (27, 'Oxxo SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (28, 'Seven SA', 'Logistica', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (29, 'Oxxo SA', 'Almacen', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (30, 'Femsa SA', 'Contabilidad', getdate(), 0, null, 0, null)

select * from Requisiciones


------------------------------------
CREATE DATABASE Requisiciones2

GO

USE Requisiciones2

GO
DROP TABLE Usuarios
GO

CREATE TABLE Usuarios
(
	Usuario nvarchar(8) not null, 
	Contrasena nvarchar(8) not null,
	Nombre nvarchar(100), 
	Rol int, 
	primary key (Usuario)
)

GO
Select * from Usuarios

GO

INSERT INTO  Usuarios VALUES ('nromero', '12345', 'Noe Romero', 1)
INSERT INTO  Usuarios VALUES ('jcedillo', '54321', 'Jorge Cedillo', 2)
INSERT INTO  Usuarios VALUES ('mmiranda', '98765', 'Mauricio Miranda', 3)

GO


CREATE TABLE Ordenes
(
	NoOrden int not null, 	
	Proveedor nvarchar (20),
	Departamento nvarchar (20) ,
	FechaOrden datetime,
	Aut_1 bit,
	Aut_1_User nvarchar(8),
	Aut_2 bit,
	Aut_2_User nvarchar(8),

	Primary key(NoOrden)
	
)


INSERT INTO Ordenes VALUES (1, 'Femsa SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (3, 'Nestle SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (4, 'Femsa SA', 'Recursos Humanos', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (5, 'Nestle SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (6, 'Femsa SA', 'Calidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (7, 'Nestle SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (8, 'Femsa SA', 'Logistica', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (9, 'Nestle SA', 'Almacen', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (10, 'Femsa SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (11, 'Nestle SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (12, 'Femsa SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (13, 'Nestle SA', 'Almacen', getdate(), 0, null, 0, null)

Select * from Ordenes 


CREATE TABLE Companias
(
	Cia int, 	
	Nombre nvarchar(100), 	
	primary key (Cia)
)

insert into Companias values (1, 'Microsoft')
insert into Companias values (2, 'Apple')
insert into Companias values (3, 'Google Inc')

select * from Companias


CREATE TABLE Requisiciones
(
	NoReq int not null, 	
	Proveedor nvarchar (20),
	Departamento nvarchar (20) ,
	FechaOrden datetime,
	Aut_1 bit,
	Aut_1_User nvarchar(8),
	Aut_2 bit,
	Aut_2_User nvarchar(8),

	Primary key(NoReq)
	
)


INSERT INTO Requisiciones VALUES (21, 'Oxxo SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (22, 'Seven SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (23, 'Oxxo SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (24, 'Seven SA', 'Recursos Humanos', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (25, 'Oxxo SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (26, 'Seven SA', 'Calidad', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (27, 'Oxxo SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (28, 'Seven SA', 'Logistica', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (29, 'Oxxo SA', 'Almacen', getdate(), 0, null, 0, null)
INSERT INTO Requisiciones VALUES (30, 'Femsa SA', 'Contabilidad', getdate(), 0, null, 0, null)

select * from Requisiciones