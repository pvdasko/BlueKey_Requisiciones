namespace WebRequsiciones.Models.Sitios
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class SitiosModel : DbContext
    {

        

        public SitiosModel()
            : base("name=ContextSitios")
        {
        }


        public virtual DbSet<Cias> Cias { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
