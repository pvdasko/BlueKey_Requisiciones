﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;


namespace Autorizaciones.Controllers
{
    public class PedidosController : BaseController
    {
        // GET: Pedidos
        public ActionResult Pedidos(string sortOrder, string currentFilter, string searchString, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "Pedido_desc" : "";
            //ViewBag.TipoParm = sortOrder == "Tipo" ? "Tipo_desc" : "Tipo";
            //ViewBag.DepartamentoParm = sortOrder == "Departamento" ? "Departamento_desc" : "Departamento";
            //ViewBag.NotasParm = sortOrder == "Notas" ? "Notas_desc" : "Notas";
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001COMPDG
                            where r.Status == false
                            select r;

            if (!String.IsNullOrEmpty(searchString))
            {
                int orden;
                if (int.TryParse(searchString, out  orden))
                {
                    viewModel = viewModel.Where(x => x.No_Ped == orden
                                                   && x.Status == false);

                }
                else
                {

                    viewModel = viewModel.Where(x => x.Notas.Contains(searchString)
                                                  && x.Status == false);
                }

            }

            switch (sortOrder)
            {
                case "Pedido_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Ped);
                    break;
                //case "Tipo":
                //    viewModel = viewModel.OrderBy(s => s.C001COMTIP.DescTip_Esp);
                //    break;
                //case "Tipo_desc":
                //    viewModel = viewModel.OrderByDescending(s => s.C001COMTIP.DescTip_Esp);
                //    break;
                //case "Departamento":
                //    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp);
                //    break;
                //case "Departamento_desc":
                //    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                //    break;
                //case "Notas":
                //    viewModel = viewModel.OrderBy(s => s.Notas);
                //    break;
                //case "Notas_desc":
                //    viewModel = viewModel.OrderByDescending(s => s.Notas);
                //    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fecha_Ped);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fecha_Ped);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Ped);
                    break;
            }

            LoadSessionObject();

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false).Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }
    }
}