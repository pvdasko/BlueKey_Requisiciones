﻿namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMTIP")]
    public partial class C001COMTIP
    {
        [Key]
        [StringLength(1)]
        public string Tipo { get; set; }

        [Required]
        [StringLength(30)]
        public string DescTip_Esp { get; set; }

        [StringLength(30)]
        public string DescTip_Ing { get; set; }

        //public bool BQT { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMRQG> C001COMRQG { get; set; }
    }
}