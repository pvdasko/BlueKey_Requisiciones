﻿namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    public partial class USUARIOS
    {
        [Key]
        [StringLength(3)]
        [Display(Name = "Usuario")]
        [Required(ErrorMessage = "Ingrese un usuario")]
        public string Codigo { get; set; }
             
        [StringLength(50)]
        public string Nombre { get; set; }

        [StringLength(3)]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        [Required(ErrorMessage = "Ingrese una comtraseña")]
        public string Password { get; set; }
             
        [StringLength(4)]
        public string Perfil { get; set; }

        public bool Autoriza_Requisicion { get; set; }

        public bool Autoriza_Pedido { get; set; }

        public bool Desintegra_Poliza { get; set; }

        public bool Abre_Periodos { get; set; }

        [StringLength(30)]
        public string Cod_Depto { get; set; }

        [StringLength(100)]
        public string Puesto { get; set; }

        public long? Id_UserId_1 { get; set; }

        public long? Id_Finger_1 { get; set; }

        public long? SampleNumber_1 { get; set; }

        public long? Id_UserId_2 { get; set; }

        public long? Id_Finger_2 { get; set; }

        public long? SampleNumber_2 { get; set; }

        [StringLength(10)]
        public string Cia_Default { get; set; }

        public bool Reservado2 { get; set; }

        public bool Reservado3 { get; set; }

        [StringLength(30)]
        public string Reservado4 { get; set; }
           
        [StringLength(1)]
        public string Idioma { get; set; }

        public long Mesas_Dia { get; set; }

        public long Mesas_Mes { get; set; }

        public long Mesas_Ano { get; set; }

        public long Pers_Dia { get; set; }

        public long Pers_Mes { get; set; }

        public long Pers_Ano { get; set; }

        [Column(TypeName = "money")]
        public decimal Pro_Dia { get; set; }

        [Column(TypeName = "money")]
        public decimal Pro_Mes { get; set; }

        [Column(TypeName = "money")]
        public decimal Pro_Ano { get; set; }

        [Column(TypeName = "money")]
        public decimal Ing_Dia { get; set; }

        [Column(TypeName = "money")]
        public decimal Ing_Mes { get; set; }

        [Column(TypeName = "money")]
        public decimal Ing_Ano { get; set; }

        [StringLength(50)]
        public string Reservado5 { get; set; }

        public bool Autoriza_JefeAlmacen { get; set; }

        public bool Autoriza_JefeCompras { get; set; }

        public bool Autoriza_Contralor { get; set; }

        public bool Autoriza_Gerente { get; set; }

        public bool Surte_Req { get; set; }

        public bool Autoriza_Director { get; set; }

        public bool Modifica_Proveedor { get; set; }

        //public bool Aut_Inc { get; set; }
              
        //[StringLength(30)]
        //public string Color_Sel { get; set; }


        public bool IsValid(string _username, string _password)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            USUARIOS acceso = db.USUARIOS
                             .Where(i => i.Codigo == _username && i.Password == _password)
                             .FirstOrDefault();
            if (acceso == null)
            {
                return false;
            }
            else
            {
                return true;
            }


        }
    }
}
