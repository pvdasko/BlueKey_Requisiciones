﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class ComprasController : BaseController
    {
        // GET: Compras
        public ActionResult ReqCompras(string sortOrder, string currentFilter, string searchString, int? page, string autfilter)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "NoReq_desc" : "";
            ViewBag.TipoParm =  sortOrder == "Tipo" ? "Tipo_desc" : "Tipo";
            ViewBag.DepartamentoParm =  sortOrder ==  "Departamento" ? "Departamento_desc" : "Departamento";
            ViewBag.NotasParm = sortOrder == "Notas" ? "Notas_desc" : "Notas";            
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001COMRQG
                            where  r.Cod_Dep != ""
                            && r.Cod_Prio != ""
                            && r.Status_Req == false
                            select r;

            if (autfilter != null){ 
                 System.Web.HttpContext.Current.Session["sessionFilter"] = autfilter;}
             else if (System.Web.HttpContext.Current.Session["sessionFilter"] != null){
                 autfilter = System.Web.HttpContext.Current.Session["sessionFilter"] as string;}

             if (autfilter == "Carrito" )
             {
                 viewModel = viewModel.Where(x => x.Carrito == true
                                                 && x.Cod_Dep != ""
                                                 && x.Cod_Prio != "");
                 ViewBag.checkedFilter = "Carrito";
             }
             else if (autfilter == "SinCarrito" || autfilter == null)
             {
                 viewModel = viewModel.Where(x => x.Carrito == false
                                                && x.Cod_Dep != ""
                                                && x.Cod_Prio != "");
                 ViewBag.checkedFilter = "SinCarrito";
             }
             else
             {
                 ViewBag.checkedFilter = "Todas";
             }


            if (!String.IsNullOrEmpty(searchString))
            {
                 int orden;
                 if (int.TryParse(searchString, out  orden))
                 {
                     viewModel = viewModel.Where(x => x.No_Req == orden);
                 }
                 else
                 {
                     viewModel = viewModel.Where(x => x.C001COMTIP.DescTip_Esp.Contains(searchString)
                                                   || x.C001INVDEP.Desc_Esp.Contains(searchString)
                                                   || x.Notas_Req.Contains(searchString));
                 }
                
            }

            switch (sortOrder)
            {
                case "NoReq_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Req);
                    break;
                case "Tipo":
                    viewModel = viewModel.OrderBy(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Tipo_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Notas":
                    viewModel = viewModel.OrderBy(s => s.Notas_Req );
                    break;
                case "Notas_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Notas_Req);
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fecha_Req);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fecha_Req);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Req);
                    break;
            }

            LoadSessionObject();

            int pageSize = 10;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));

        }

        [HttpPost]
        public ActionResult ReqCompras(List<C001COMRQG> orden, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string ordenesAprobadas = "";
            string ordenesCarrito = "";
            string ordenesSinCarrito = "";
            String mensajeStr = "";
            bool cambio_carrito = false;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    foreach (var i in orden)
                    {
                        var ordqupd = db.C001COMRQG.Where(x => x.No_Req == i.No_Req).FirstOrDefault();
                        if (ordqupd != null)
                        {
                            if (ordqupd.Ope_Aut == null)
                                ordqupd.Status_Req = Convert.ToBoolean(i.Status_Req);

                            if (Convert.ToBoolean(i.Status_Req) == true && Convert.ToString(i.Ope_Aut) == null)
                            {
                                ordqupd.Ope_Aut = userAut;
                                ordqupd.Hora_Aut = DateTime.Now;
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Req;
                            }

                            if (ordqupd.Carrito != Convert.ToBoolean(i.Carrito)){
                                ordqupd.Carrito = Convert.ToBoolean(i.Carrito);
                                cambio_carrito = true;}

                            if (Convert.ToBoolean(i.Carrito) == true)
                            {
                                ordqupd.Usuario_Carrito = userAut;
                                ordqupd.Fecha_Carrito = DateTime.Now;
                                if (cambio_carrito ==true )
                                    ordenesCarrito = ordenesCarrito + " " + i.No_Req;
                            }
                            else
                            {
                                ordqupd.Usuario_No_Carrito = userAut;
                                ordqupd.Fecha_No_Carrito = DateTime.Now;
                                if (cambio_carrito == true)
                                    ordenesSinCarrito = ordenesSinCarrito + " " + i.No_Req;
                            }

                            

                        }
                    }
                    db.SaveChanges();
                }
                ViewBag.Message = "Ordenes Aprobadas.";
                if (ordenesAprobadas != "" ){
                     mensajeStr = "Se aprobaron las ordenes: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b>";
                }
                else if (ordenesCarrito != ""){
                    mensajeStr += "Se enviaron al carrito las ordenes: <b>" + ordenesCarrito + "</b> por el usuario: <b>{0}</b>";
                }
                else if (ordenesSinCarrito != "")
                {
                    mensajeStr += "Se quitaron del carrito las ordenes: <b>" + ordenesSinCarrito + "</b> por el usuario: <b>{0}</b>";
                }
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqCompras");
            }
            catch (Exception ex)
            {                
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqCompras");
                throw;
            }

        }
        
        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return RedirectToAction("ReqComprasDet", "ComprasDetalle", new { @id = id });
        }


        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string noReq = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    var viewModel3 = db.C001COMCOTI.Where(x => x.No_Requisicion == id);
                    foreach (var item in viewModel3.ToList())
                    {
                        db.C001COMCOTI.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel = db.C001COMRQL.Where(x => x.No_Req == id);
                    foreach (var item in viewModel.ToList())
                    {
                        db.C001COMRQL.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel2 = db.C001COMRQG.Where(x => x.No_Req == id).FirstOrDefault();
                    noReq = viewModel2.No_Req.ToString();
                    db.C001COMRQG.Remove(viewModel2);
                    db.SaveChanges();
                }
                ViewBag.Message = "Orden borrada.";
                String mensajeStr = "Se borro la requisición: <b>" + noReq + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqCompras");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqCompras");
                throw;
            }
        }

        public ActionResult Sumariza(string total, string status)
        {
            double total_aut;
            if (System.Web.HttpContext.Current.Session["TotalAut"] == null)
            { total_aut = 0; }
            else { total_aut = double.Parse(System.Web.HttpContext.Current.Session["TotalAut"].ToString()); }

            if (status == "true")
            { total_aut = total_aut + double.Parse(total.ToString()); }
            else { total_aut = total_aut - double.Parse(total.ToString()); }
            System.Web.HttpContext.Current.Session["TotalAut"] = total_aut;
            return Content(total_aut.ToString("C2"));

        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false 
                                                  && x.Cod_Dep != ""
                                                  && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;

            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}