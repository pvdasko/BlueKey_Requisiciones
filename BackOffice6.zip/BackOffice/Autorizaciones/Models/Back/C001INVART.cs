namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVART")]
    public partial class C001INVART
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVART()
        {
            C001INVLIN = new HashSet<C001INVLIN>();
        }

        [Key]
        public long Cod_Art { get; set; }

        [Required]
        [StringLength(50)]
        public string Cod_Barras { get; set; }

        [Required]
        [StringLength(100)]
        public string Desc_Esp { get; set; }

        [StringLength(100)]
        public string Desc_Ing { get; set; }

        [Required]
        [StringLength(4)]
        public string Alm { get; set; }

        [Required]
        [StringLength(4)]
        public string Sub_Alm { get; set; }

        public double IVA { get; set; }

        [StringLength(50)]
        public string Notas { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_1 { get; set; }

        [Required]
        [StringLength(6)]
        public string Prov_2 { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Maximo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Minimo { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Reorden { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Ent { get; set; }

        [Required]
        [StringLength(10)]
        public string Uni_Sal { get; set; }

        [Required]
        [StringLength(3)]
        public string Conver { get; set; }

        public bool Consignacion { get; set; }

        public bool? Taza0 { get; set; }

        [StringLength(19)]
        public string Cuenta { get; set; }

        public long? Cod_Tienda { get; set; }

        public bool NoUtilizar { get; set; }

        public bool PrecioLista { get; set; }

        [Required]
        [StringLength(20)]
        public string CodigoFab { get; set; }

        [Column(TypeName = "money")]
        public decimal IEPS { get; set; }

        [StringLength(1)]
        public string TReq { get; set; }

        public virtual C001CXPCAT C001CXPCAT { get; set; }

        public virtual C001CXPCAT C001CXPCAT1 { get; set; }

        public virtual C001INVMED C001INVMED { get; set; }

        public virtual C001INVMED C001INVMED1 { get; set; }

        public virtual C001INVSUB C001INVSUB { get; set; }

        public virtual C001INVEST C001INVEST { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVLIN> C001INVLIN { get; set; }
    }
}
