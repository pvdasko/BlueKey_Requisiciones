﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class ComprasController : BaseController
    {
        // GET: Compras
        public ActionResult ReqCompras(string sortOrder, string currentFilter, string searchString, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "NoReq_desc" : "";
            ViewBag.TipoParm = String.IsNullOrEmpty(sortOrder) ? "Tipo" : "Tipo_desc";
            ViewBag.DepartamentoParm = String.IsNullOrEmpty(sortOrder) ? "Departamento" : "Departamento_desc";
            ViewBag.NotasParm = String.IsNullOrEmpty(sortOrder) ? "Notas" : "Notas_desc";            
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001COMRQG
                            where  r.Status_Req == false 
                            select r;

            if (!String.IsNullOrEmpty(searchString))
            {
                 int orden;
                 if (int.TryParse(searchString, out  orden))
                 {
                     viewModel = viewModel.Where(x => x.No_Req == orden
                                                    && x.Status_Req == false);

                 }
                 else
                 {

                     viewModel = viewModel.Where(x => x.C001COMTIP.DescTip_Esp.Contains(searchString)
                                                   || x.C001INVDEP.Desc_Esp.Contains(searchString)
                                                   || x.Notas_Req.Contains(searchString)
                                                   && x.Status_Req == false);
                 }
                
            }

            switch (sortOrder)
            {
                case "NoReq_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Req);
                    break;
                case "Tipo":
                    viewModel = viewModel.OrderBy(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Tipo_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Notas":
                    viewModel = viewModel.OrderBy(s => s.Notas_Req );
                    break;
                case "Notas_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Notas_Req);
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fecha_Req);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fecha_Req);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Req);
                    break;
            }

            LoadSessionObject();

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));

        }


        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false).Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }
    }
}