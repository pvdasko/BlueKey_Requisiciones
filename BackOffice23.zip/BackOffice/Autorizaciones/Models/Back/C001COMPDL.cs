namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("001COMPDL")]
    public partial class C001COMPDL
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Ped { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long No_Req { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int No_Lin { get; set; }

        public long No_Art { get; set; }

        public double Cantidad { get; set; }

        [DataType(DataType.Currency)]
        public decimal Precio { get; set; }

        [Column(TypeName = "money")]
        public decimal Descuento { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [DataType(DataType.Currency)]
        public double Total { get; set; }

        public double Entregada_1 { get; set; }

        public double Entregada_2 { get; set; }

        public double Entregada_3 { get; set; }

        public double Entregada_4 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Falta { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_1 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_2 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_3 { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double? Total_4 { get; set; }

        //[Column(TypeName = "money")]
        //public decimal IEPS { get; set; }



        [NotMapped]
        public string Unidad
        {
            get
            {
                return UnidadArticulo(this.No_Art );
            }
        }

        [NotMapped]
        public string Descripcion
        {
            get
            {
                return DescripcionArticulo(this.No_Art);
            }
        }

        [NotMapped]
        public double IVA 
        { 
            get
            {
                return IvaArticulo(this.No_Art);
            } 
        }

        public string UnidadArticulo(long no_art)
        {
            string desc_unidad = "";
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            desc_unidad = db.C001INVART 
                            .Where(x => x.Cod_Art==no_art)
                            .Select(x => x.C001INVMED.Descripcion_Espanol )
                            .FirstOrDefault();
          

            return desc_unidad;
        }

        public string DescripcionArticulo(long no_art)
        {
            string desc_articulo = "";
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            desc_articulo = db.C001INVART
                            .Where(x => x.Cod_Art == no_art)
                            .Select(x => x.Desc_Esp)
                            .FirstOrDefault();


            return desc_articulo;
        }

        public double IvaArticulo(long no_art)
        {
            double iva_articulo = 0;
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            iva_articulo = db.C001INVART
                            .Where(x => x.Cod_Art == no_art)
                            .Select(x => x.IVA)
                            .FirstOrDefault();


            return iva_articulo;
        }
    }
}
