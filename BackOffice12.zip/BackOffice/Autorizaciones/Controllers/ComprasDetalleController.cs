﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;


namespace Autorizaciones.Controllers
{
    public class ComprasDetalleController : BaseController
    {
        // GET: ComprasDetalle
        public ActionResult ReqComprasDet(int id)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);
            var modelordenes = db.C001COMRQG.Where(x => x.No_Req == id).FirstOrDefault();

            ViewBag.lblNoOrden = modelordenes.No_Req;         
            ViewBag.lblDepartamento = modelordenes.C001INVDEP.Desc_Esp;
            ViewBag.lblTipo = modelordenes.C001COMTIP.DescTip_Esp; 
            ViewBag.lblFecha = modelordenes.Fecha_Req.ToString("yyyy-MM-dd");
            ViewBag.lblComentarios = modelordenes.Notas_Req;
            ViewBag.lblPrioridad = modelordenes.C001COMPRI.Desc_Esp;

            var viewModel = db.C001COMRQL.Where(x => x.No_Req == id).ToList();

            LoadSessionObject();

            return View(viewModel);
        }

        public ActionResult Delete(int id, int lin)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, int lin, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    var viewModel = db.C001COMRQL.Where(x => x.No_Req == id && x.No_Lin == lin).FirstOrDefault();
                    db.C001COMRQL.Remove(viewModel);
                    db.SaveChanges();
                }

                ViewBag.Message = "Linea borrada.";
                String mensajeStr = "Se borro la linea: <b>" + lin.ToString() + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqComprasDet");

            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqComprasDet");
                throw;
            }

        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false).Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}