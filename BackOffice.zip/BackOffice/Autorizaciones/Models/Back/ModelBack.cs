namespace Autorizaciones.Models.Back
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelBack : DbContext
    {
        public ModelBack(string connStringName)
            : base("name=" +  connStringName )
        {
        }
        public ModelBack()
            : base("name=ContextBack")
        {
        }

        public virtual DbSet<C001COMCOTI> C001COMCOTI { get; set; }
        public virtual DbSet<C001COMPDG> C001COMPDG { get; set; }
        public virtual DbSet<C001COMPDL> C001COMPDL { get; set; }
        public virtual DbSet<C001COMPRI> C001COMPRI { get; set; }
        public virtual DbSet<C001COMRQG> C001COMRQG { get; set; }
        public virtual DbSet<C001COMRQL> C001COMRQL { get; set; }
        public virtual DbSet<C001COMTIP> C001COMTIP { get; set; }
        public virtual DbSet<C001CONCTA> C001CONCTA { get; set; }
        public virtual DbSet<C001CXPCAT> C001CXPCAT { get; set; }
        public virtual DbSet<C001INVALM> C001INVALM { get; set; }
        public virtual DbSet<C001INVART> C001INVART { get; set; }
        public virtual DbSet<C001INVDEP> C001INVDEP { get; set; }
        public virtual DbSet<C001INVGEN> C001INVGEN { get; set; }
        public virtual DbSet<C001INVLIN> C001INVLIN { get; set; }
        public virtual DbSet<C001INVDEPCTAS> C001INVDEPCTAS { get; set; }
        public virtual DbSet<C001INVEST> C001INVEST { get; set; }
        public virtual DbSet<C001INVMED> C001INVMED { get; set; }
        public virtual DbSet<C001INVSUB> C001INVSUB { get; set; }
        public virtual DbSet<C001INVTIPOS> C001INVTIPOS { get; set; }
        public virtual DbSet<USUARIOS> USUARIOS { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<C001COMCOTI>()
                .Property(e => e.CodProv)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMCOTI>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Genera)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Autoriza)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Autoriza2)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Imprime)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Condiciones)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_JefeAlmacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_JefeCompras)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Contralor)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Gerente)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Tiempo_Entrega)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Notas_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDG>()
                .Property(e => e.Ope_Director)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.Precio)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.Descuento)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPDL>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Tip_Prio)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMPRI>()
                .HasMany(e => e.C001COMRQG)
                .WithRequired(e => e.C001COMPRI)
                .HasForeignKey(e => e.Cod_Prio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Tip_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Cod_Prio)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Notas_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Notas_Auto)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Ope_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQG>()
                .HasMany(e => e.C001COMRQL)
                .WithRequired(e => e.C001COMRQG)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Desc_Art)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Cod_Med)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMRQL>()
                .HasMany(e => e.C001COMCOTI)
                .WithRequired(e => e.C001COMRQL)
                .HasForeignKey(e => new { e.No_Requisicion, e.No_Linea })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001COMTIP>()
             .Property(e => e.Tipo)
             .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .Property(e => e.DescTip_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001COMTIP>()
                .Property(e => e.DescTip_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Tipo_Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Clasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Subclasificacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Descripcion_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Complementaria)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Libre_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Libre_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Comentarios)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.TipoAD)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.Codigo_Divisa)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.AgrupadorSAT)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .Property(e => e.SubAgrupadorSAT)
                .IsUnicode(false);

            modelBuilder.Entity<C001CONCTA>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001CONCTA)
                .HasForeignKey(e => new { e.Cuenta_1, e.Cuenta_2, e.Cuenta_3, e.Cuenta_4 })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Codigo_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Razon_Social)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo_Provedor)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Colonia)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Poblacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CP)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.No_Fax)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.E_Mail)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Pag_Web)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.RFC)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Contacto)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Cta_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Forma_Pago)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tiempo_Entrega)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Descuento)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_Mes_Actual)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_Vencer)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_30)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_60)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_90)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Saldo_120)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CURP)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo2)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo3)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Tipo4)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Comercial)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Pais)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.CodigoAnterior)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.TipoTercero)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.TipoOperacion)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.IDFiscal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nacionalidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nombre_Plaza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_CW)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_Plaza)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Numero_Sucursal)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .Property(e => e.Nombre_Banco)
                .IsUnicode(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001COMCOTI)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.CodProv)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001CXPCAT)
                .HasForeignKey(e => e.Prov_1)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001CXPCAT>()
                .HasMany(e => e.C001INVART1)
                .WithRequired(e => e.C001CXPCAT1)
                .HasForeignKey(e => e.Prov_2)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Codigo_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Cta_Contable)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVALM>()
                .HasMany(e => e.C001INVSUB)
                .WithRequired(e => e.C001INVALM)
                .HasForeignKey(e => e.Cod_Almacen)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Cod_Barras)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Alm)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Sub_Alm)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Prov_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Prov_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Maximo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Minimo)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Reorden)
                .HasPrecision(19, 0);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Uni_Ent)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Uni_Sal)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Conver)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.Cuenta)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVART>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVART>()
                .HasOptional(e => e.C001INVEST)
                .WithRequired(e => e.C001INVART);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Desc_Esp)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Desc_Ing)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cta_Mayor)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.Cta_Nivel)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .Property(e => e.BD)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEP>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001INVDEP)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Alma)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cod_Sub)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_3)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVDEPCTAS>()
                .Property(e => e.Cuenta_4)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_UE)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_Prom)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Cos_Ant)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UE)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_US)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UA)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UDP)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVEST>()
                .Property(e => e.Req_UDD)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Codigo_Unidad)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Tipo)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001COMRQL)
                .WithRequired(e => e.C001INVMED)
                .HasForeignKey(e => e.Cod_Med)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001INVMED)
                .HasForeignKey(e => e.Uni_Ent)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVMED>()
                .HasMany(e => e.C001INVART1)
                .WithRequired(e => e.C001INVMED1)
                .HasForeignKey(e => e.Uni_Sal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cod_Almacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cod_Subalmacen)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Descripcion_Espanol)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Descripcion_Ingles)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Abono)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Cargo1)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Cuenta_Cargo2)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .Property(e => e.Libre)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVSUB>()
                .HasMany(e => e.C001INVART)
                .WithRequired(e => e.C001INVSUB)
                .HasForeignKey(e => new { e.Alm, e.Sub_Alm })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVSUB>()
                .HasMany(e => e.C001INVDEPCTAS)
                .WithRequired(e => e.C001INVSUB)
                .HasForeignKey(e => new { e.Cod_Alma, e.Cod_Sub })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .Property(e => e.Cod_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVTIPOS>()
                .Property(e => e.Desc_Tip)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.No_Req)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Tipo_Mov)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Prov)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Dep)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Notas)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Cod_Ope)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Ope_Aut)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Referencia)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Ope_Aplica)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.ISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.IVAR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.RET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.PISR)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.PRET)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Flete)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Porc_Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Monto_XML)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.Anticipo)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .Property(e => e.IEPS)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVGEN>()
                .HasMany(e => e.C001INVLIN)
                .WithRequired(e => e.C001INVGEN)
                .HasForeignKey(e => e.Indice)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Costo)
                .HasPrecision(18, 6);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Cta_Con)
                .IsUnicode(false);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Iva)
                .HasPrecision(19, 4);

            modelBuilder.Entity<C001INVLIN>()
                .Property(e => e.Concepto)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
               .Property(e => e.Codigo)
               .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Perfil)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Cod_Depto)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Puesto)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Cia_Default)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Reservado4)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Idioma)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Mes)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Pro_Ano)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Dia)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Mes)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Ing_Ano)
                .HasPrecision(19, 4);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Reservado5)
                .IsUnicode(false);

            modelBuilder.Entity<USUARIOS>()
                .Property(e => e.Color_Sel)
                .IsUnicode(false);
        }
    }
}
