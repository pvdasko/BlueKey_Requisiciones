﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class AlmacenController : BaseController
    {
        // GET: Almacen
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page , string autfilter)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "NoReq_desc" : "";
            ViewBag.DepartamentoParm = sortOrder == "Departamento" ? "Departamento_desc" : "Departamento";
            ViewBag.NotasParm = sortOrder == "Notas" ? "Notas_desc" : "Notas";            
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";
            System.Web.HttpContext.Current.Session["TotalAut"] = null;

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

             var viewModel = from r in db.C001INVGEN 
                             where r.Tipo_Mov == "SAL" 
                             select r;

             if (autfilter != null){ 
                 System.Web.HttpContext.Current.Session["sessionFilter"] = autfilter;}             
             else if (System.Web.HttpContext.Current.Session["sessionFilter"] != null)
             {
                 autfilter = System.Web.HttpContext.Current.Session["sessionFilter"] as string;
             }
             

             if (autfilter == "Pendientes" || autfilter == null)
             {
                 viewModel = viewModel.Where(x => x.Stat_Aut == false);
                 ViewBag.checkedFilter = "Pendientes";
                 autfilter = System.Web.HttpContext.Current.Session["sessionFilter"] as string;
             }
             else
             {
                 ViewBag.checkedFilter = "Todas";
             }
                                                         
            
            if (!String.IsNullOrEmpty(searchString))
            {
                
                viewModel = viewModel.Where(x => x.No_Req.Contains (searchString)
                                              || x.C001INVDEP.Desc_Esp.Contains(searchString)
                                              || x.Notas.Contains(searchString));
                

            }

            switch (sortOrder)
            {
                case "NoReq_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Req);
                    break;               
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp );
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Notas":
                    viewModel = viewModel.OrderBy(s => s.Notas);
                    break;
                case "Notas_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Notas);
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fech_Mov);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fech_Mov);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Req);
                    break;
            }

            LoadSessionObject();


            int pageSize = 10;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }

        [HttpPost]
        public ActionResult Index(List<C001INVGEN> orden, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string ordenesAprobadas = "";
            try
            {
                using (ModelBack  db = new ModelBack(connectionStringName))
                {

                    foreach (var i in orden)
                    {
                        var ordqupd = db.C001INVGEN.Where(x => x.Ind_Mov == i.Ind_Mov).FirstOrDefault();
                        if (ordqupd != null)
                        {
                            if (ordqupd.Ope_Aut == null)
                                ordqupd.Stat_Aut = Convert.ToBoolean(i.Stat_Aut);

                            if (Convert.ToBoolean(i.Stat_Aut) == true && Convert.ToString(i.Ope_Aut) == null)
                            {
                                ordqupd.Ope_Aut = userAut;
                                ordqupd.Hora_Autoriza = DateTime.Now; 
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Req;
                            }
                           
                            //if (ordqupd.Aut_2_User == null)
                            //    ordqupd.Aut_2 = Convert.ToBoolean(i.Aut_2);

                            //if (Convert.ToBoolean(i.Aut_2) == true && Convert.ToString(i.Aut_2_User) == null)
                            //{
                            //    ordqupd.Aut_2_User = userAut;
                            //    ordenesAprobadas = ordenesAprobadas + " " + i.NoOrden.ToString();
                            //}

                        }
                    }
                    db.SaveChanges();
                }
                ViewBag.Message = "Ordenes Aprobadas.";

                //int pageSize = 5;
                //int pageNumber = (page ?? 1);
                //return View(orden.ToPagedList(pageNumber, pageSize));
                String mensajeStr = "Se aprobaron las ordenes: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b> ";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("Index");
            }
            catch (Exception  ex)
            {
                //catch (DbEntityValidationException e)

                //foreach (var eve in e.EntityValidationErrors)
                //{
                //    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                //        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                //    foreach (var ve in eve.ValidationErrors)
                //    {
                //        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                //            ve.PropertyName, ve.ErrorMessage);
                //    }
                //}
                //throw;
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("Index");
                throw;
            }

        }

       
        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return RedirectToAction("Index", "AlmacenDetalle", new { @id = id });
        }

        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string noReq = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    var viewModel = db.C001INVLIN.Where(x => x.Indice == id);
                    foreach (var item in viewModel.ToList () )
                    {
                        db.C001INVLIN.Remove(item); 
                    }
                    db.SaveChanges();   

                    var viewModel2 = db.C001INVGEN.Where(x => x.Ind_Mov == id ).FirstOrDefault();
                    noReq = viewModel2.No_Req.ToString();  
                    db.C001INVGEN.Remove(viewModel2);
                    db.SaveChanges();            
                }
                ViewBag.Message = "Orden borrada.";
                String mensajeStr = "Se borro la requisición: <b>" + noReq + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format( mensajeStr, userAut), true);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("Index");
                throw;
            }
        }

        public ActionResult Sumariza(string total, string status)
        {
            double  total_aut;
            if (System.Web.HttpContext.Current.Session["TotalAut"] == null)
            {  total_aut = 0;}
            else { total_aut = double.Parse(System.Web.HttpContext.Current.Session["TotalAut"].ToString()); }

            if (status == "true")
            {  total_aut = total_aut + double.Parse (total.ToString ()) ;}
            else { total_aut = total_aut - double.Parse(total.ToString()); }
            System.Web.HttpContext.Current.Session["TotalAut"] = total_aut;
            return Content(total_aut.ToString("C2"));
           
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false
                                               && x.Cod_Dep != ""
                                               && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;

            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
    }
}