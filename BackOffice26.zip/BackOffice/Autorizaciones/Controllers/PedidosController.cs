﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class PedidosController : BaseController
    {
        // GET: Pedidos
        public ActionResult Pedidos(string sortOrder, string currentFilter, string searchString, int? page, string autfilter)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.PedidoParm = String.IsNullOrEmpty(sortOrder) ? "Pedido_desc" : "";
            //ViewBag.NoReqParm = sortOrder == "NoReq" ? "NoReq_desc" : "NoReq";
            ViewBag.ProveedorParm = sortOrder == "Proveedor" ? "Proveedor_desc" : "Proveedor";
            ViewBag.DepartamentoParm = sortOrder == "Departamento" ? "Departamento_desc" : "Departamento";
            //ViewBag.NotasParm = sortOrder == "Notas" ? "Notas_desc" : "Notas";
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";
            System.Web.HttpContext.Current.Session["TotalAut"] = null;


            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001COMPDG
                            where r.Autoriza == false
                            || r.Autoriza2 == false 
                            select r;

            if (autfilter != null)
            {
                System.Web.HttpContext.Current.Session["sessionFilter"] = autfilter;
            }
            else if (System.Web.HttpContext.Current.Session["sessionFilter"] != null)
            {
                autfilter = System.Web.HttpContext.Current.Session["sessionFilter"] as string;
            }

            if (autfilter == "Carrito")
            {
                viewModel = viewModel.Where(x => x.Carrito ==true);
                ViewBag.checkedFilter = "Carrito";
            }
            else if (autfilter == "SinCarrito" || autfilter == null)
            {
                viewModel = viewModel.Where(x => x.Carrito == false);
                ViewBag.checkedFilter = "SinCarrito";
            }
            else
            {
                ViewBag.checkedFilter = "Todas";
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                int orden;
                if (int.TryParse(searchString, out  orden))
                {
                    viewModel = viewModel.Where(x => x.No_Ped == orden);
                }
                else
                {
                    viewModel = viewModel.Where(x => x.Proveedor.Contains(searchString)
                                                  && x.Departamento.Contains(searchString));
                }

            }

            switch (sortOrder)
            {
                case "Pedido_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Ped);
                    break;
                //case "NoReq":
                //    viewModel = viewModel.OrderBy(s => s.Requisicion);
                //    break;
                //case "NoReq_desc":
                //    viewModel = viewModel.OrderByDescending(s => s.Requisicion);
                //    break;
                case "Departamento":                    
                    viewModel = viewModel.OrderBy(s => s.Cod_Depto);
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Cod_Depto);
                    break;
                case "Proveedor":
                    viewModel = viewModel.OrderBy(s => s.Cod_Prov);
                    break;
                case "Proveedor_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Cod_Prov );
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fecha_Ped);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fecha_Ped);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Ped);
                    break;
            }

            LoadSessionObject();

            int pageSize = 10;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }

        [HttpPost]
        public ActionResult Pedidos(List<C001COMPDG> orden, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string ordenesAprobadas = "";            
            string ordenesCarrito = "";
            string ordenesSinCarrito = "";
            String mensajeStr = "";
            bool cambio_carrito = false;

            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    foreach (var i in orden)
                    {
                        var ordqupd = db.C001COMPDG.Where(x => x.No_Ped == i.No_Ped).FirstOrDefault();
                        if (ordqupd != null)
                        {
                            if (ordqupd.Ope_Autoriza == null)
                                ordqupd.Autoriza = Convert.ToBoolean(i.Autoriza);

                            if (Convert.ToBoolean(i.Autoriza) == true && Convert.ToString(i.Ope_Autoriza) == null)
                            {
                                ordqupd.Ope_Autoriza = userAut;
                                ordqupd.Fecha_1  = DateTime.Now;
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Ped;
                            }

                            if (ordqupd.Ope_Autoriza2 == null)
                                ordqupd.Autoriza2 = Convert.ToBoolean(i.Autoriza2);

                            if (Convert.ToBoolean(i.Autoriza2 ) == true && Convert.ToString(i.Ope_Autoriza2) == null)
                            {
                                ordqupd.Ope_Autoriza = userAut;
                                ordqupd.Fecha_2 = DateTime.Now;
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Ped;
                            }

                            if (ordqupd.Carrito != Convert.ToBoolean(i.Carrito))
                            {
                                ordqupd.Carrito = Convert.ToBoolean(i.Carrito);
                                cambio_carrito = true;
                            }

                            if (cambio_carrito == true && Convert.ToBoolean(i.Carrito) == true)
                            {   
                                    ordenesCarrito = ordenesCarrito + " " + i.No_Ped;
                            }
                            else
                            {
                                ordenesSinCarrito = ordenesSinCarrito + " " + i.No_Ped;
                            }

                        }
                    }
                    db.SaveChanges();
                }
                ViewBag.Message = "Pedidos Aprobados.";         
                if (ordenesAprobadas != "")
                {
                    mensajeStr = "Se aprobaron los pedidos: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b>";
                }
                else if (ordenesCarrito != "")
                {
                    mensajeStr += "Se enviaron al carrito los pedidos: <b>" + ordenesCarrito + "</b> por el usuario: <b>{0}</b>";
                }
                else if (ordenesSinCarrito != "")
                {
                    mensajeStr += "Se quitaron del carrito los pedidos: <b>" + ordenesSinCarrito + "</b> por el usuario: <b>{0}</b>";
                }
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("Pedidos");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("Pedidos");
                throw;
            }

        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var viewModel = db.C001COMPDG.Where(x => x.No_Ped == id).FirstOrDefault();
            if (viewModel == null)
            {
                return HttpNotFound();
            }
            LoadSessionObject();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            ModelBack db = new ModelBack(connectionStringName);
            var updatePedido = db.C001COMPDG.Where(x => x.No_Ped == id).FirstOrDefault();

           if (TryUpdateModel(updatePedido) )
            {                
                db.SaveChanges();               
                
            }
           ViewBag.Message = "Pedido guardado.";
           String mensajeStr = "Se guardo el pedido: <b>" + id.ToString () + "</b> por el usuario: <b>{0}</b>";
           Success(string.Format(mensajeStr, userAut), true);
           return RedirectToAction("Edit", "Pedidos", new { @id = id });
            
        }

        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return RedirectToAction("PedidosDet", "PedidosDetalle", new { @id = id });
        }
        
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string noReq = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    var viewModel = db.C001COMPDL.Where(x => x.No_Ped == id);
                    foreach (var item in viewModel.ToList())
                    {
                        db.C001COMPDL.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel2 = db.C001COMPDG.Where(x => x.No_Ped == id).FirstOrDefault();
                    noReq = viewModel2.No_Ped.ToString();
                    db.C001COMPDG.Remove(viewModel2);
                    db.SaveChanges();
                }
                ViewBag.Message = "Pedido borrado.";
                String mensajeStr = "Se borro el pedido: <b>" + noReq + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqCompras");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("Pedidos");
                throw;
            }
        }


        public ActionResult Sumariza(string total, string status)
        {
            double total_aut;
            if (System.Web.HttpContext.Current.Session["TotalAutPed"] == null)
            { total_aut = 0; }
            else { total_aut = double.Parse(System.Web.HttpContext.Current.Session["TotalAutPed"].ToString()); }

            if (status == "true")
            { total_aut = total_aut + double.Parse(total.ToString()); }
            else { total_aut = total_aut - double.Parse(total.ToString()); }
            System.Web.HttpContext.Current.Session["TotalAutPed"] = total_aut;
            return Content(total_aut.ToString("C2"));

        }
      
        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false
                                               && x.Cod_Dep != ""
                                               && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;

            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}