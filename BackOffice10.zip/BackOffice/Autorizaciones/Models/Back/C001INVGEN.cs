﻿namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("001INVGEN")]
    public partial class C001INVGEN
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVGEN()
        {
            C001INVLIN = new HashSet<C001INVLIN>();
        }

        [Key]
        public long Ind_Mov { get; set; }

        [Required]
        [StringLength(10)]
        public string No_Req { get; set; }

        [Required]
        [Display(Name = "Tipo")]
        [StringLength(3)]
        public string Tipo_Mov { get; set; }

        [Display(Name = "Fecha")]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Fech_Mov { get; set; }

        public DateTime Fech_Sis { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [StringLength(200)]
        public string Notas { get; set; }

        [DataType(DataType.Currency)]
        public double Total_Fac { get; set; }

        public double Iva_Fac { get; set; }

        [Required]
        [StringLength(3)]
        public string Cod_Ope { get; set; }

        public bool Stat_Mov { get; set; }

        [StringLength(3)]
        public string Ope_Aut { get; set; }

        public bool Stat_Aut { get; set; }

        public bool Entrada_Directa { get; set; }

        public long No_Pedido { get; set; }

        [StringLength(10)]
        public string Referencia { get; set; }

        public bool Aplicado { get; set; }
               
        [StringLength(3)]
        public string Ope_Aplica { get; set; }

         [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime? Hora_Captura { get; set; }

        public DateTime? Hora_Autoriza { get; set; }

        public DateTime? Hora_Surte { get; set; }

        [Column(TypeName = "money")]
        public decimal ISR { get; set; }

        [Column(TypeName = "money")]
        public decimal IVAR { get; set; }

        public bool Status { get; set; }

        [Column(TypeName = "money")]
        public decimal RET { get; set; }

        [Column(TypeName = "money")]
        public decimal PISR { get; set; }

        [Column(TypeName = "money")]
        public decimal PRET { get; set; }

        public bool RetIva { get; set; }

        public bool Dolares { get; set; }

        public DateTime? Fecha_Factura { get; set; }

        [Column(TypeName = "money")]
        public decimal Flete { get; set; }

        public bool Reproceso { get; set; }

        [Column(TypeName = "money")]
        public decimal Porc_Iva { get; set; }

        [StringLength(50)]
        public string UUID_XML { get; set; }

        [Column(TypeName = "money")]
        public decimal Monto_XML { get; set; }

        [StringLength(50)]
        public string RFC_XML { get; set; }

        [StringLength(300)]
        public string NOM_XML { get; set; }

        [Column(TypeName = "money")]
        public decimal Anticipo { get; set; }

        [Column(TypeName = "money")]
        public decimal IEPS { get; set; }

        [StringLength(50)]
        public string Evento { get; set; }

        [NotMapped]
        [DataType(DataType.Currency)]
        public double TotalFactura 
        {
             get {
                 return C001INVLIN.Sum(l => l.Total );
            }
        }

        //db.pruchasemasters.GroupBy(o => o.membername)
        //.Select(g => new { membername = g.Key, total = g.Sum(i => i.cost) });

        public virtual C001CXPCAT C001CXPCAT { get; set; }

        public virtual C001INVDEP C001INVDEP { get; set; }

        public virtual C001INVTIPOS C001INVTIPOS { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVLIN> C001INVLIN { get; set; }
    }

}