﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Autorizaciones.Controllers
{
    public class ComprasController : BaseController
    {
        // GET: Compras
        public ActionResult ReqCompras(string sortOrder, string currentFilter, string searchString, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack  db = new ModelBack(connectionStringName);

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NoReqParm = String.IsNullOrEmpty(sortOrder) ? "NoReq_desc" : "";
            ViewBag.TipoParm =  sortOrder == "Tipo" ? "Tipo_desc" : "Tipo";
            ViewBag.DepartamentoParm =  sortOrder ==  "Departamento" ? "Departamento_desc" : "Departamento";
            ViewBag.NotasParm = sortOrder == "Notas" ? "Notas_desc" : "Notas";            
            ViewBag.FechaParm = sortOrder == "Fecha" ? "Fecha_desc" : "Fecha";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from r in db.C001COMRQG
                            where  r.Status_Req == false 
                            select r;

            if (!String.IsNullOrEmpty(searchString))
            {
                 int orden;
                 if (int.TryParse(searchString, out  orden))
                 {
                     viewModel = viewModel.Where(x => x.No_Req == orden
                                                    && x.Status_Req == false);

                 }
                 else
                 {

                     viewModel = viewModel.Where(x => x.C001COMTIP.DescTip_Esp.Contains(searchString)
                                                   || x.C001INVDEP.Desc_Esp.Contains(searchString)
                                                   || x.Notas_Req.Contains(searchString)
                                                   && x.Status_Req == false);
                 }
                
            }

            switch (sortOrder)
            {
                case "NoReq_desc":
                    viewModel = viewModel.OrderByDescending(s => s.No_Req);
                    break;
                case "Tipo":
                    viewModel = viewModel.OrderBy(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Tipo_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001COMTIP.DescTip_Esp);
                    break;
                case "Departamento":
                    viewModel = viewModel.OrderBy(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Departamento_desc":
                    viewModel = viewModel.OrderByDescending(s => s.C001INVDEP.Desc_Esp);
                    break;
                case "Notas":
                    viewModel = viewModel.OrderBy(s => s.Notas_Req );
                    break;
                case "Notas_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Notas_Req);
                    break;
                case "Fecha":
                    viewModel = viewModel.OrderBy(s => s.Fecha_Req);
                    break;
                case "Fecha_desc":
                    viewModel = viewModel.OrderByDescending(s => s.Fecha_Req);
                    break;
                default:
                    viewModel = viewModel.OrderBy(s => s.No_Req);
                    break;
            }

            LoadSessionObject();

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));

        }

        [HttpPost]
        public ActionResult ReqCompras(List<C001COMRQG> orden, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string ordenesAprobadas = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    foreach (var i in orden)
                    {
                        var ordqupd = db.C001COMRQG.Where(x => x.No_Req == i.No_Req).FirstOrDefault();
                        if (ordqupd != null)
                        {
                            if (ordqupd.Ope_Aut == null)
                                ordqupd.Status_Req = Convert.ToBoolean(i.Status_Req);

                            if (Convert.ToBoolean(i.Status_Req) == true && Convert.ToString(i.Ope_Aut) == null)
                            {
                                ordqupd.Ope_Aut = userAut;
                                ordqupd.Hora_Aut = DateTime.Now;
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Req;
                            }

                        }
                    }
                    db.SaveChanges();
                }
                ViewBag.Message = "Ordenes Aprobadas.";
                String mensajeStr = "Se aprobaron las ordenes: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqCompras");
            }
            catch (Exception ex)
            {                
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqCompras");
                throw;
            }

        }
        
        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return RedirectToAction("ReqComprasDet", "ComprasDetalle", new { @id = id });
        }


        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string noReq = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {

                    var viewModel3 = db.C001COMCOTI.Where(x => x.No_Requisicion == id);
                    foreach (var item in viewModel3.ToList())
                    {
                        db.C001COMCOTI.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel = db.C001COMRQL.Where(x => x.No_Req == id);
                    foreach (var item in viewModel.ToList())
                    {
                        db.C001COMRQL.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel2 = db.C001COMRQG.Where(x => x.No_Req == id).FirstOrDefault();
                    noReq = viewModel2.No_Req.ToString();
                    db.C001COMRQG.Remove(viewModel2);
                    db.SaveChanges();
                }
                ViewBag.Message = "Orden borrada.";
                String mensajeStr = "Se borro la requisición: <b>" + noReq + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqCompras");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqCompras");
                throw;
            }
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false).Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;

            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}