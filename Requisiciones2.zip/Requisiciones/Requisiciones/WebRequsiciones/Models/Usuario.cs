namespace WebRequsiciones.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    public partial class Usuario
    {
        

        [Key]
        [Column("Usuario")]
        [StringLength(8)]
        [Display(Name = "Usuario")]
        public string Usuario1 { get; set; }

        [Required]
        [StringLength(8)]
        [DataType(DataType.Password)]
        [Display(Name = "Contrase�a")]
        public string Contrasena { get; set; }

        [StringLength(100)]
        public string Nombre { get; set; }

        public int? Rol { get; set; }


        public bool IsValid(string _username, string _password)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            RequisionesModel db = new RequisionesModel(connectionStringName);

            Usuario acceso = db.Usuarios
                             .Where(i => i.Usuario1 == _username && i.Contrasena == _password)
                             .FirstOrDefault();
            if (acceso == null)
            {
                return false;
            }
            else
            {
                return true;
            }


        }
    }
}
