﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models;
using PagedList;
using System.Data.Entity.Infrastructure;


namespace WebRequsiciones.Controllers
{
    public class OrdenesController : Controller
    {
        // GET: Ordenes
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            RequisionesModel db = new RequisionesModel(connectionStringName);

            ViewBag.CurrentSort = sortOrder;

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;


            var viewModel = from o in db.Ordenes //db.Ordenes.OrderBy(x => x.NoOrden).ToList();
                            select o;

            if (!String.IsNullOrEmpty(searchString))
            {
                viewModel = viewModel.Where(x => x.Departamento.Contains(searchString) 
                                              || x.Proveedor.Contains (searchString ));
            }

            switch (sortOrder)
            {
                case "NoOrden":
                    viewModel = viewModel.OrderByDescending(s => s.NoOrden);
                    break;
                default :
                     viewModel = viewModel.OrderByDescending(s => s.NoOrden);
                    break;
            }
            
            LoadSessionObject();

            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList (pageNumber , pageSize ));
        }

        // GET: Ordenes/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Ordenes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ordenes/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ordenes/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Ordenes/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ordenes/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }
    }
}
