namespace WebRequsiciones.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Data.Entity.ModelConfiguration.Conventions;

    public partial class RequisionesModel : DbContext
    {

        public RequisionesModel(string connStringName)
            : base("name=" + connStringName)
        {
        }


        public RequisionesModel()
            : base("name=ContextRequisiones")
        {
        }

        public virtual DbSet<Companias> Companias { get; set; }
        public virtual DbSet<Ordenes> Ordenes { get; set; }
        public virtual DbSet<OrdenesDetalle> OrdenesDetalle { get; set; }
        public virtual DbSet<Producto> Producto { get; set; }
        public virtual DbSet<Requisiciones> Requisiciones { get; set; }
        public virtual DbSet<Usuarios> Usuarios { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

       

    }
}
