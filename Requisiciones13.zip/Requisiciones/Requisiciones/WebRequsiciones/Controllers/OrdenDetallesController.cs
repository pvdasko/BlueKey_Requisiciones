﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models;

namespace WebRequsiciones.Controllers
{
    public class OrdenDetallesController : Controller
    {
        // GET: OrdenDetalles
        public ActionResult Index(int id)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            RequisionesModel db = new RequisionesModel(connectionStringName);
            var modelordenes = db.Ordenes.Where(x => x.NoOrden == id).FirstOrDefault ();

            ViewBag.lblNoOrden = modelordenes.NoOrden;
            ViewBag.lblProveedor = modelordenes.Proveedor; 
            
            var viewModel = db.OrdenesDetalle.Where(x => x.NoOrden == id).ToList();

            LoadSessionObject();

            return View(viewModel);
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }

    }
}