﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models; 

namespace WebRequsiciones.Controllers
{
    public class HomeController : Controller
    {
        private RequisionesModel db = new RequisionesModel();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Models.Usuario user)
        {
            if (ModelState.IsValid)
            {
                if (user.IsValid(user.Usuario1, user.Contrasena))
                {
                    //return RedirectToAction("Index", "Home");
                    var rol = db.Usuarios.Where (u => u.Usuario1 == user.Usuario1 )
                        .Select (u => u.Rol)
                        .FirstOrDefault ();


                    switch (rol)
                    { 
                        case 1:
                            return RedirectToAction("Index", "Ordenes");
                            
                        case 2:
                            return RedirectToAction("Index", "Requisiciones");
                           
                        default :
                              return RedirectToAction("Index", "Home"); 
                    }    


                    
                }
                else
                {
                    ModelState.AddModelError("", "Login data is incorrect!");
                }
            }

            //Models.Ordene requis = new Models.Ordene();
            return View(user);
        }
    }
}