CREATE DATABASE Requisiciones

GO


USE Requisiciones

GO
DROP TABLE Usuarios
GO

CREATE TABLE Usuarios
(
	Usuario nvarchar(8) not null, 
	Contrasena nvarchar(8) not null,
	Nombre nvarchar(100), 
	Rol int, 
	primary key (Usuario)
)

GO

INSERT INTO  Usuarios VALUES ('nromero', '12345', 'Noe Romero', 1)
INSERT INTO  Usuarios VALUES ('jcedillo', '54321', 'Jorge Cedillo', 2)
INSERT INTO  Usuarios VALUES ('mmiranda', '98765', 'Mauricio Miranda', 3)

GO


CREATE TABLE Ordenes
(
	NoOrden int not null, 	
	Proveedor nvarchar (20),
	Departamento nvarchar (20) ,
	FechaOrden datetime,
	Aut_1 bit,
	Aut_1_User nvarchar(8),
	Aut_2 bit,
	Aut_2_User nvarchar(8),

	Primary key(NoOrden)
	
)


INSERT INTO Ordenes VALUES (1, 'Patito SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (3, 'Patito SA', 'Facturacion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (4, 'Patito SA', 'Recursos Humanos', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (5, 'Patito SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (6, 'Patito SA', 'Calidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (7, 'Patito SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (8, 'Patito SA', 'Logistica', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (9, 'Patito SA', 'Almacen', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (10, 'Patito SA', 'Contabilidad', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (11, 'Patito SA', 'Produccion', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (12, 'Patito SA', 'Ingenieria', getdate(), 0, null, 0, null)
INSERT INTO Ordenes VALUES (13, 'Patito SA', 'Almacen', getdate(), 0, null, 0, null)

Select * from Ordenes 


CREATE TABLE Companias
(
	Cia int, 	
	Nombre nvarchar(100), 	
	primary key (Cia)
)

insert into Companias values (1, 'Microsoft')
insert into Companias values (2, 'Apple')
insert into Companias values (3,'Google Inc')