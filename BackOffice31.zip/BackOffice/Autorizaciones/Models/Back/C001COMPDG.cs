namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("001COMPDG")]
    public partial class C001COMPDG
    {
                
        [Key]
        public long No_Ped { get; set; }

        [StringLength(6)]
        public string Cod_Prov { get; set; }

        [StringLength(300)]
        public string Notas { get; set; }

        [Display(Name = "Fecha")]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Fecha_Ped { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Fecha_Entrega { get; set; }

        [Required]
        [StringLength(4)]
        public string Cod_Depto { get; set; }

        public bool Autoriza { get; set; }

        public bool Autoriza2 { get; set; }

        public bool Impresa { get; set; }

        [Required]
        [StringLength(3)]
        public string Ope_Genera { get; set; }

        [StringLength(3)]
        public string Ope_Autoriza { get; set; }

        [StringLength(3)]
        public string Ope_Autoriza2 { get; set; }

        [StringLength(3)]
        public string Ope_Imprime { get; set; }

        public bool Entrada_1 { get; set; }

        public bool Entrada_2 { get; set; }

        public bool Entrada_3 { get; set; }

        public bool Entrada_4 { get; set; }
               
        public DateTime? Fecha_1 { get; set; }

        public DateTime? Fecha_2 { get; set; }

        public DateTime? Fecha_3 { get; set; }
                
        public DateTime? Fecha_4 { get; set; }

        public bool Dolares { get; set; }

        [StringLength(100)]
        public string Condiciones { get; set; }

        public long Requisicion { get; set; }

        public bool Imagen1 { get; set; }

        public bool Imagen2 { get; set; }

        public bool? Status { get; set; }

        public bool Autoriza_JefeAlmacen { get; set; }

        public bool Autoriza_JefeCompras { get; set; }

        public bool Autoriza_Contralor { get; set; }

        public bool Autoriza_Gerente { get; set; }

        [StringLength(3)]
        public string Ope_JefeAlmacen { get; set; }

        [StringLength(3)]
        public string Ope_JefeCompras { get; set; }

        [StringLength(3)]
        public string Ope_Contralor { get; set; }

        [StringLength(3)]
        public string Ope_Gerente { get; set; }

        public DateTime? Hora_JefeAlmacen { get; set; }

        public DateTime? Hora_JefeCompras { get; set; }

        public DateTime? Hora_Contralor { get; set; }

        public DateTime? Hora_Gerente { get; set; }

        public bool Operacion { get; set; }

        public bool Firmas { get; set; }

        [StringLength(50)]
        public string Tiempo_Entrega { get; set; }

        [StringLength(300)]
        public string Notas_1 { get; set; }

        [StringLength(300)]
        public string Notas_2 { get; set; }

        public bool Autoriza_Director { get; set; }

        [StringLength(3)]
        public string Ope_Director { get; set; }

        public DateTime? Hora_Director { get; set; }

        public bool SOE { get; set; }

        public bool FFE { get; set; }

        public bool Carrito { get; set; }

        //[Required]
        //[StringLength(1)]
        //public string Proceso { get; set; }
               
        //[StringLength(300)]
        //public string Observaciones { get; set; }
                
        //[StringLength(50)]
        //public string comentarios { get; set; }

        [NotMapped]      
        public string Proveedor
        {
            get
            {
                return ProveedorPedido(this.Cod_Prov );
            }
        }

        [NotMapped]
        public string Departamento
        {
            get
            {
                return DepartamentoPedido(this.Cod_Depto);
            }
        }

        [NotMapped]
        [DataType(DataType.Currency)]
        public double Total_Pedido
        {
            get
            {
                return TotalPedidoDetalle(this.No_Ped);
            }
        }

        public string ProveedorPedido(string cod_prov)
        {
            string desc_proveedor = "";
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            desc_proveedor = db.C001CXPCAT
                            .Where(x => x.Codigo_Provedor.Contains(cod_prov))
                            .Select(x => x.Razon_Social)
                            .FirstOrDefault();
                    

            return desc_proveedor;
        }

        public string DepartamentoPedido(string cod_dep)
        {
            string desc_departamento = "";
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            desc_departamento = db.C001INVDEP
                            .Where(x => x.Cod_Dep.Contains(cod_dep))
                            .Select(x => x.Desc_Esp)
                            .FirstOrDefault();


            return desc_departamento;
        }


        public double TotalPedidoDetalle(double  no_ped)
        {
            double total_pedido = 0;
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            if (db.C001COMPDL.Where(x => x.No_Ped == no_ped).Count() > 0)
            {

                total_pedido = db.C001COMPDL
                                 .Where(x => x.No_Ped == no_ped)
                                 .Sum(x => x.Total);
            }
            else
            {
                total_pedido = 0;
            }


            return total_pedido;

        }
    }
}
