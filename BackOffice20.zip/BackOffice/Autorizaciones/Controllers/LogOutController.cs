﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Autorizaciones.Controllers
{
    public class LogOutController : Controller
    {
        // GET: LogOut      

        [HttpPost]
        public ActionResult Index()
        {
            Session.Abandon();
            //return Json(new { status = "done" });
            return JavaScript("window.close();");
        }
    }
}