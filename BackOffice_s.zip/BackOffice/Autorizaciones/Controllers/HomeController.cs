﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models.Cias;
using Autorizaciones.Models.Back;


namespace Autorizaciones.Controllers
{
    public class HomeController : Controller
    {
        private ModelCias  dbs = new ModelCias();
        public ActionResult Index()
        {

            return View();
        }

        [HttpGet]
        public ActionResult Login(int? SeleccionaCia)
        {
            try
            {
                //var cias = dbs.Cias.OrderBy(x => x.IdCia).ToList();
                //ViewBag.SeleccionaCia = new SelectList(cias, "IdCia", "Razon_Social", SeleccionaCia);}
                //cias.Add(new Cias { IdCia = 0, Razon_Social = "--Selecciona Compañia--" });
                //cias = cias.OrderBy(x => x.IdCia).ToList();

                List<SelectListItem> cias = new List<SelectListItem>();
                cias.Add(new SelectListItem { Text = "--Selecciona Compañia--", Value = "0" });
                foreach (var c in dbs.CONMAESTRO )
                {
                    cias.Add(new SelectListItem
                    {
                        Text = c.Razon_Social,
                        Value = Convert.ToString (int.Parse (c.Codigo_Cia ))
                    });
                }
                ViewBag.IdCia = cias;

                return View();
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "No se pudo conectar a la Base de Datos!");
                throw;
            }

        }

        [HttpPost]
        public ActionResult Login(int?IdCia, Models.Back.USUARIOS  user)
        {
            var ciaId = int.Parse (Request["IdCia"]);
            if (ciaId == 0)
            {
                List<SelectListItem> cias = new List<SelectListItem>();
                cias.Add(new SelectListItem { Text = "--Selecciona Compañia--", Value = "0" });
                foreach (var c in dbs.CONMAESTRO )
                {
                    cias.Add(new SelectListItem
                    {
                        Text = c.Razon_Social,
                        Value = Convert.ToString(int.Parse(c.Codigo_Cia))
                    });
                }
                ViewBag.IdCia = cias;
                ModelState.AddModelError("", "Debe seleccionar una compañia");
                return View();
            }

            var cod_cia= IdCia.ToString ().PadLeft(3, '0');
            string connectionStringName = dbs.CONMAESTRO.Where( x => x.Codigo_Cia == cod_cia )
                                         .Select(c => c.Nombre_Base)
                                         .FirstOrDefault();
            connectionStringName = "Context" + connectionStringName;
            System.Web.HttpContext.Current.Session["sessionString"] = connectionStringName;

            if (ModelState.IsValid)
            {

                ModelBack  db = new ModelBack(connectionStringName);

                if (user.IsValid(user.Codigo, user.Password ))
                {
                    //return RedirectToAction("Index", "Home");
                    var rolc = db.USUARIOS.Where(u => u.Codigo == user.Codigo )
                        .Select(u => u.Autoriza_Requisicion )
                        .FirstOrDefault();

                    var rolp = db.USUARIOS.Where(u => u.Codigo == user.Codigo)
                       .Select(u => u.Autoriza_Pedido)
                       .FirstOrDefault();

                    var nombreUsuario = db.USUARIOS.Where(u => u.Codigo  == user.Codigo)
                       .Select(u => u.Nombre)
                       .FirstOrDefault();

                    var usuario = db.USUARIOS.Where(u => u.Codigo == user.Codigo)
                      .Select(u => u.Codigo)
                      .FirstOrDefault();

                    System.Web.HttpContext.Current.Session["nombreUsuario"] = nombreUsuario;
                    System.Web.HttpContext.Current.Session["usuario"] = usuario;

                    int rol = 0;
                    if (rolc == true && rolp == false)
                    {
                        rol = 1; // solo requisiciones
                    }
                    else if (rolc == false  && rolp == true)
                    {
                        rol = 2; // solo pedidos
                    }
                    else if (rolc == true  && rolp == true)
                    {
                        rol = 3; // requisiciones y  pedidos
                    }

                    switch (rol)
                    {
                        case 1:
                            return RedirectToAction("Index", "Requisiciones");

                        case 2:
                            return RedirectToAction("Index", "Pedidos");

                        default:
                            return RedirectToAction("Index", "Home");
                    }



                }
                else
                {
                    ModelState.AddModelError("", "Login data is incorrect!");
                    //ViewBag.Message = ".";
                    List<SelectListItem> cias = new List<SelectListItem>();
                    cias.Add(new SelectListItem { Text = "--Selecciona Compañia--", Value = "0" });
                    foreach (var c in dbs.CONMAESTRO)
                    {
                        cias.Add(new SelectListItem
                        {
                            Text = c.Razon_Social,
                            Value = Convert.ToString(int.Parse(c.Codigo_Cia))
                        });
                    }
                    ViewBag.IdCia = cias;
                }
            }
            else
            {
                List<SelectListItem> cias = new List<SelectListItem>();
                cias.Add(new SelectListItem { Text = "--Selecciona Compañia--", Value = "0" });
                foreach (var c in dbs.CONMAESTRO)
                {
                    cias.Add(new SelectListItem
                    {
                        Text = c.Razon_Social,
                        Value = Convert.ToString(int.Parse(c.Codigo_Cia))
                    });
                }
                ViewBag.IdCia = cias;
                //ModelState.AddModelError("Usuario1", "Ingrese un usuario");
                //ModelState.AddModelError("Contrasena", "Ingrese una contraseña");
                return View(user);
            }

            //Models.Ordene requis = new Models.Ordene();
            return View(user);
        }

    }
}