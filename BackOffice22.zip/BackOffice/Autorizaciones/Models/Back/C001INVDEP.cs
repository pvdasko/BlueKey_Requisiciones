namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVDEP")]
    public partial class C001INVDEP
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001INVDEP()
        {
            C001COMRQG = new HashSet<C001COMRQG>();
            C001INVDEPCTAS = new HashSet<C001INVDEPCTAS>();
            C001INVGEN = new HashSet<C001INVGEN>();
        }

        [Key]
        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [Required]
        [StringLength(50)]
        public string Desc_Esp { get; set; }

        [StringLength(50)]
        public string Desc_Ing { get; set; }

        [StringLength(19)]
        public string Cta_Mayor { get; set; }

        [StringLength(4)]
        public string Cta_Nivel { get; set; }

        public bool Inventario { get; set; }

        [StringLength(50)]
        public string BD { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMRQG> C001COMRQG { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVDEPCTAS> C001INVDEPCTAS { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001INVGEN> C001INVGEN { get; set; }
    }
}
