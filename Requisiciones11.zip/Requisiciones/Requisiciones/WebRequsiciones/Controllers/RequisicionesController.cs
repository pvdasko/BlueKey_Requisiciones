﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models; 

namespace WebRequsiciones.Controllers
{
    public class RequisicionesController : Controller
    {

        private RequisionesModel db = new RequisionesModel();
        // GET: Requisiciones
        public ActionResult Index()
        {
            LoadSessionObject();
            var viewModel = db.Requisiciones.OrderBy(x => x.NoReq ).ToList();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Index(List<Requisiciones> req )
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            using (RequisionesModel db = new RequisionesModel(connectionStringName))
            {
                foreach (var i in req)
                {
                    var requpd = db.Requisiciones.Where(x => x.NoReq==i.NoReq).FirstOrDefault();
                    if (requpd != null)
                    {                      
                        requpd.Aut_1 = Convert.ToBoolean ( i.Aut_1);
                        //requpd.Aut_1_User = "jcedillo"; //System.Web.HttpContext.Current.Session["nombreUsuario"] as String; 
                        requpd.Aut_2 = Convert.ToBoolean ( i.Aut_2);
                        //requpd.Aut_2_User = "jcedillo";  //System.Web.HttpContext.Current.Session["nombreUsuario"] as String; 
                    
                    }                    
                }
                db.SaveChanges();                
            }
            ViewBag.Message = "Requisiciones Aprobadas.";            
            return View( req );
        }


        // GET: Requisiciones/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Requisiciones/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Requisiciones/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Requisiciones/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Requisiciones/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Requisiciones/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Requisiciones/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
        }

    }
}
