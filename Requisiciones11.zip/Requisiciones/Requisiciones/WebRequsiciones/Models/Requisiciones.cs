﻿
namespace WebRequsiciones.Models
{

    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public class Requisiciones
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int NoReq { get; set; }

        [StringLength(20)]
        public string Proveedor { get; set; }

        [StringLength(20)]
        public string Departamento { get; set; }

        public DateTime? FechaOrden { get; set; }

        public bool Aut_1 { get; set; }

        [StringLength(8)]
        public string Aut_1_User { get; set; }

        public bool Aut_2 { get; set; }

        [StringLength(8)]
        public string Aut_2_User { get; set; }

               
    }

    
}