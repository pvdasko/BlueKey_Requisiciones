﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRequsiciones.Models; 
using WebRequsiciones.Models.Sitios;

namespace WebRequsiciones.Controllers
{
    public class HomeController : Controller
    {
       
        private SitiosModel dbs = new SitiosModel();
        // GET: Home
        public ActionResult Index()
        {           

            return View();
        }

        [HttpGet]
        public ActionResult Login(int? SeleccionaCia)
        {
            try
            {                
                var cias = dbs.Cias.OrderBy(x => x.IdCia).ToList();
                ViewBag.SeleccionaCia = new SelectList(cias, "IdCia", "Razon_Social", SeleccionaCia);
                return View();
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "No se pudo conectar a la Base de Datos!");
                throw;
            }
            
        }

        [HttpPost]
        public ActionResult Login(int? SeleccionaCia, Models.Usuarios user)
        {
           string connectionStringName = dbs.Cias.Where (x => x.IdCia == SeleccionaCia)
                                         .Select (c => c.dbContext )
                                         .FirstOrDefault ();
           System.Web.HttpContext.Current.Session["sessionString"] = connectionStringName;

            if (ModelState.IsValid)
            {
                
                RequisionesModel db = new RequisionesModel(connectionStringName);

                if (user.IsValid(user.Usuario1, user.Contrasena))
                {    
                    //return RedirectToAction("Index", "Home");
                    var rol = db.Usuarios.Where (u => u.Usuario1 == user.Usuario1 )
                        .Select (u => u.Rol)
                        .FirstOrDefault ();

                    var nombreUsuario = db.Usuarios.Where(u => u.Usuario1 == user.Usuario1)
                       .Select(u => u.Nombre )
                       .FirstOrDefault();

                    var usuario = db.Usuarios.Where(u => u.Usuario1 == user.Usuario1)
                      .Select(u => u.Usuario1)
                      .FirstOrDefault();

                    System.Web.HttpContext.Current.Session["nombreUsuario"] = nombreUsuario;
                    System.Web.HttpContext.Current.Session["usuario"] = usuario;

                    switch (rol)
                    { 
                        case 1:
                            return RedirectToAction("Index", "Ordenes");
                            
                        case 2:
                            return RedirectToAction("Index", "Requisiciones");
                           
                        default :
                              return RedirectToAction("Index", "Home"); 
                    }    


                    
                }
                else
                {
                    ModelState.AddModelError("", "Login data is incorrect!");
                    ViewBag.Message = ".";
                }
            }

            //Models.Ordene requis = new Models.Ordene();
            return View(user);
        }

        
    }
}